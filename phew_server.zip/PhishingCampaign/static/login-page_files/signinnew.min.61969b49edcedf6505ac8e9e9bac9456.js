function strToBin(str) {
    return Uint8Array.from(atob(str), function(c) {
        return c.charCodeAt(0)
    })
}

function binToStr(bin) {
    return btoa(new Uint8Array(bin).reduce(function(s, byte) {
        return s + String.fromCharCode(byte)
    }, ""))
}

function isWebAuthNSupported() {
    return window.PublicKeyCredential ? !0 : !1
}

function credentialListConversion(list) {
    return list.map(function(item) {
        var cred = {
            type: item.type,
            id: strToBin(item.id)
        };
        return null != item.transports && item.transports.length && (cred.transports = item.transports), cred
    })
}

function getArrayFromObj(obj) {
    var objArr = [];
    return $(obj).each(function() {
        objArr.push(this)
    }), objArr
}

function addFlagIcon(element, country_code) {
    country_code = country_code.toLowerCase().trim();
    const paths = new Map([
        ["ac", 10],
        ["as", 6],
        ["va", 7],
        ["af", 6],
        ["ax", 4],
        ["al", 2],
        ["dz", 4],
        ["ad", 7],
        ["ao", 8],
        ["ai", 9],
        ["aq", 3],
        ["ag", 5],
        ["ar", 5],
        ["am", 4],
        ["aw", 7],
        ["au", 12],
        ["at", 3],
        ["az", 6],
        ["bs", 5],
        ["bh", 2],
        ["bd", 3],
        ["bb", 6],
        ["by", 6],
        ["be", 4],
        ["bz", 6],
        ["bj", 6],
        ["bm", 11],
        ["bt", 3],
        ["bo", 4],
        ["bq", 9],
        ["ba", 9],
        ["bw", 5],
        ["bv", 4],
        ["br", 5],
        ["io", 23],
        ["vg", 10],
        ["bn", 3],
        ["bg", 3],
        ["bf", 4],
        ["bi", 9],
        ["kh", 5],
        ["cm", 6],
        ["ca", 4],
        ["cv", 6],
        ["ky", 10],
        ["cf", 6],
        ["td", 4],
        ["cl", 4],
        ["cn", 4],
        ["cx", 10],
        ["cc", 10],
        ["co", 6],
        ["km", 6],
        ["cg", 3],
        ["cd", 5],
        ["caf", 4],
        ["cas", 3],
        ["coc", 3],
        ["ceu", 4],
        ["cna", 3],
        ["csa", 3],
        ["ck", 7],
        ["cr", 4],
        ["ci", 3],
        ["hr", 6],
        ["cu", 6],
        ["cw", 4],
        ["cy", 5],
        ["cz", 3],
        ["dk", 2],
        ["dj", 5],
        ["domain", 3],
        ["do", 9],
        ["dm", 9],
        ["ec", 7],
        ["eg", 5],
        ["sv", 5],
        ["gq", 5],
        ["er", 12],
        ["ee", 3],
        ["et", 6],
        ["eu", 3],
        ["fk", 29],
        ["fo", 3],
        ["fj", 10],
        ["fi", 2],
        ["fr", 3],
        ["gf", 3],
        ["pf", 41],
        ["tf", 14],
        ["gm", 5],
        ["ge", 6],
        ["de", 6],
        ["gh", 5],
        ["gi", 13],
        ["ga", 4],
        ["gr", 2],
        ["gl", 4],
        ["gd", 7],
        ["gp", 25],
        ["gu", 20],
        ["gt", 5],
        ["gg", 9],
        ["gn", 4],
        ["gw", 5],
        ["gy", 5],
        ["ht", 10],
        ["hm", 12],
        ["hn", 8],
        ["hk", 3],
        ["hu", 3],
        ["is", 4],
        ["in", 6],
        ["id", 2],
        ["ir", 7],
        ["iq", 8],
        ["ie", 3],
        ["im", 36],
        ["il", 5],
        ["it", 3],
        ["jm", 5],
        ["jp", 2],
        ["je", 8],
        ["jo", 5],
        ["kz", 5],
        ["ke", 10],
        ["ki", 14],
        ["xk", 8],
        ["kw", 4],
        ["kg", 4],
        ["la", 5],
        ["lv", 3],
        ["lb", 4],
        ["ls", 5],
        ["lr", 4],
        ["ly", 7],
        ["li", 3],
        ["lt", 4],
        ["lu", 3],
        ["mo", 4],
        ["mg", 3],
        ["mw", 5],
        ["my", 4],
        ["mv", 4],
        ["ml", 4],
        ["mt", 5],
        ["mh", 4],
        ["mq", 7],
        ["mr", 3],
        ["mu", 5],
        ["yt", 4],
        ["mx", 5],
        ["fm", 3],
        ["md", 5],
        ["mc", 2],
        ["mn", 5],
        ["me", 5],
        ["ms", 9],
        ["ma", 3],
        ["mz", 7],
        ["mm", 5],
        ["na", 4],
        ["nr", 3],
        ["np", 5],
        ["nl", 3],
        ["an", 8],
        ["nc", 7],
        ["nz", 10],
        ["ni", 5],
        ["ne", 4],
        ["ng", 3],
        ["nu", 7],
        ["nf", 3],
        ["kp", 6],
        ["mk", 8],
        ["mp", 145],
        ["no", 3],
        ["om", 4],
        ["pk", 3],
        ["pw", 3],
        ["ps", 5],
        ["pa", 5],
        ["pg", 8],
        ["py", 5],
        ["pe", 3],
        ["ph", 4],
        ["pn", 38],
        ["pl", 2],
        ["pt", 6],
        ["pr", 5],
        ["qa", 2],
        ["re", 4],
        ["ro", 4],
        ["ru", 3],
        ["rw", 6],
        ["bq-1", 4],
        ["bl", 117],
        ["mf", 4],
        ["ws", 7],
        ["sm", 4],
        ["st", 7],
        ["sa", 6],
        ["sn", 5],
        ["rs", 6],
        ["sc", 6],
        ["sl", 3],
        ["sg", 3],
        ["bq-2", 8],
        ["sx", 11],
        ["sk", 7],
        ["si", 4],
        ["sb", 8],
        ["so", 3],
        ["za", 7],
        ["gs", 32],
        ["kr", 4],
        ["ss", 7],
        ["es", 10],
        ["lk", 7],
        ["sh", 11],
        ["kn", 6],
        ["lc", 6],
        ["pm", 4],
        ["vc", 5],
        ["sd", 4],
        ["sr", 5],
        ["sj", 4],
        ["sz", 9],
        ["se", 3],
        ["ch", 3],
        ["sy", 5],
        ["tw", 4],
        ["tj", 4],
        ["tz", 6],
        ["th", 4],
        ["tl", 5],
        ["tg", 5],
        ["tk", 7],
        ["to", 3],
        ["tt", 6],
        ["tn", 3],
        ["tr", 4],
        ["tm", 20],
        ["tc", 12],
        ["tv", 23],
        ["ug", 9],
        ["ua", 3],
        ["ae", 4],
        ["gb", 13],
        ["us", 5],
        ["um", 5],
        ["uy", 3],
        ["vi", 18],
        ["uz", 4],
        ["vu", 9],
        ["ve", 5],
        ["vn", 3],
        ["wf", 4],
        ["eh", 6],
        ["ye", 3],
        ["zm", 18],
        ["zw", 11]
    ]);
    if ("undefined" != typeof hideUVFlag && hideUVFlag) return !1;
    var no_of_paths = paths.get(country_code),
        root = document.createElement("span");
    root.classList.add("flag-" + country_code), element.append(root);
    for (var i = 1; no_of_paths >= i; i++) {
        var path = document.createElement("span");
        path.classList.add("path" + i), root.append(path)
    }
}

function validateConfirmPassword(pass_ele) {
    var confirm_ele;
    confirm_ele = 0 == $(".signup_container").length || $(pass_ele).parent().hasClass("idp_infomation_card") ? $(pass_ele).parent().next().next().children("input") : $(pass_ele).parent().next().children("input");
    var newPassword = $(pass_ele).val(),
        confPassword = $(confirm_ele).val();
    return "" != newPassword && "" != confPassword ? newPassword == confPassword && $(pass_ele).siblings(".pass_allow_indi").hasClass("show_pass_allow_indi") ? ($(confirm_ele).siblings(".pass_allow_indi").addClass("show_pass_allow_indi"), !0) : ($(confirm_ele).siblings(".pass_allow_indi").removeClass("show_pass_allow_indi"), !1) : void 0
}

function changePasswordCheckIndicator(ele, changePositive) {
    return changePositive ? ($(ele).addClass("grn_tick"), !0) : ($(ele).removeClass("grn_tick"), !1)
}

function validatePassword(pass_ele) {
    var ppCheckValue = !0,
        password = $(pass_ele).val();
    return $(".password_indicator span").addClass("grn_tick"), PasswordPolicy.isHaveMinLength(password) || 0 == PasswordPolicy.data.min_length || (changePasswordCheckIndicator("#char_check", !1), ppCheckValue = !1), PasswordPolicy.isHavingSpecialChars(password) || 0 == PasswordPolicy.data.min_spl_chars || (changePasswordCheckIndicator("#spcl_char_check", !1), ppCheckValue = !1), PasswordPolicy.isHavingNumber(password) || 0 == PasswordPolicy.data.min_numeric_chars || (changePasswordCheckIndicator("#num_check", !1), ppCheckValue = !1), JSON.parse(PasswordPolicy.data.mixed_case) && (PasswordPolicy.isHavingUpperCase(password) || (changePasswordCheckIndicator("#uppercase_check", !1), ppCheckValue = !1), PasswordPolicy.isHavingLowerCase(password) || (changePasswordCheckIndicator("#lowercase_check", !1), ppCheckValue = !1)), validPasswordChanges(ppCheckValue, pass_ele), ppCheckValue
}

function validPasswordChanges(isValidPass, ele) {
    $(ele).val().length <= 0 && ($(".password_indicator").slideUp(300), $(".pass_allow_indi").removeClass("show_pass_allow_indi")), $(".password_indicator").is(":visible") || isValidPass || $(".password_indicator").slideDown(300), isValidPass ? ($(".password_indicator").slideUp(300), $(ele + "~.pass_allow_indi").addClass("show_pass_allow_indi")) : $(ele + "~.pass_allow_indi").removeClass("show_pass_allow_indi"), validateConfirmPassword(ele)
}

function setFooterPosition() {
    var top_value = window.innerHeight - 60;
    $(".container")[0] && $(".container")[0].offsetHeight + $(".container")[0].offsetTop < top_value ? $("#footer").css("top", top_value + "px") : $("#footer").css("top", $(".container")[0] && $(".container")[0].offsetHeight + $(".container")[0].offsetTop + "px")
}

function hideLoadinginButton() {
    $("#loadingImg").is(":visible") && $("#loadingImg").hide()
}

function isEmailId(str) {
    if (!str) return !1;
    str = str.trim();
    var objRegExp = new XRegExp("^[\\p{L}\\p{N}\\p{M}\\_]([\\p{L}\\p{N}\\p{M}\\_\\+\\-\\.\\'\\&\\!\\*]*)@(?=.{4,256}$)(([\\p{L}\\p{N}\\p{M}]+)(([\\-\\_]*[\\p{L}\\p{N}\\p{M}])*)[\\.])+[\\p{L}\\p{M}]{2,22}$", "i");
    return XRegExp.test(str, objRegExp)
}

function isEmailIdSignin(str) {
    if (!str) return !1;
    var objRegExp = new XRegExp("^[\\p{L}\\p{N}\\p{M}\\_]([\\p{L}\\p{N}\\p{M}\\_\\+\\-\\.\\'\\&\\!\\*]*)@(?=.{4,256}$)(([\\p{L}\\p{N}\\p{M}]+)(([\\-\\_]*[\\p{L}\\p{N}\\p{M}])*)[\\.])+[\\p{L}\\p{M}]{2,22}$", "i");
    return XRegExp.test(str.trim(), objRegExp)
}

function isPhoneNumber(str) {
    if (!str) return !1;
    str = str.trim();
    var objRegExp = /^([0-9]{5,14})$/;
    return objRegExp.test(str)
}

function hasEmoji(str) {
    for (var i = 0; i < str.length; i++) {
        var codePoint = str.codePointAt(i);
        if (codePoint >= 127744 && 129459 >= codePoint || codePoint >= 127995 && 127999 >= codePoint) return !0
    }
    return !1
}

function isClearText(val) {
    if (val.length > 100) return !1;
    var pattern = /^[0-9a-zA-Z_\-\+\.\$@\?\,\:\'\/\!\[\]\|\u0080-\uFFFF\s]+$/;
    return pattern.test(val.trim())
}

function formatMessage() {
    var msg = arguments[0];
    if (void 0 != msg)
        for (var i = 1; i < arguments.length; i++) void 0 != arguments[i] && (msg = msg.replace(new RegExp("\\{" + (i - 1) + "\\}", "g"), escapeHTML(arguments[i].toString())));
    return msg
}

function escapeHTML(value) {
    return value && (value = value.replace("<", "&lt;"), value = value.replace(">", "&gt;"), value = value.replace('"', "&quot;"), value = value.replace("'", "&#x27;"), value = value.replace("/", "&#x2F;")), value
}

function de(id) {
    return document.getElementById(id)
}

function euc(i) {
    return encodeURIComponent(i)
}

function isEmpty(str) {
    return str ? !1 : !0
}

function getPlainResponse(action, params) {
    "undefined" != typeof contextpath && (action = contextpath + action), 0 === params.indexOf("&") && (params = params.substring(1));
    var objHTTP;
    return objHTTP = xhr(), objHTTP.open("POST", action, !1), objHTTP.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"), isEmpty(params) && (params = "__d=e"), objHTTP.setRequestHeader("Content-length", params.length), objHTTP.send(params), objHTTP.responseText
}

function getErrorMessage(response) {
    var msg = void 0 != response.localized_message ? response.localized_message : void 0 != response.message ? response.message : err_try_again;
    return msg
}

function showErrMsg(msg) {
    $("#error_space").removeClass("show_error"), $(".cross_mark").removeClass("cross_mark_success"), $(".cross_mark").css("background", "#DA6161"), $(".top_msg").html(msg), $(".cross_mark").addClass("cross_mark_error"), $("#error_space").addClass("show_error"), setTimeout(function() {
        $("#error_space").removeClass("show_error"), $(".cross_mark").removeClass("cross_mark_error"), $(".top_msg").html("")
    }, 5e3)
}

function showmsg(msg) {
    $("#error_space").removeClass("show_error"), $(".cross_mark").removeClass("cross_mark_error"), $(".cross_mark").css("background", "#69C585"), $(".top_msg").html(msg), $(".cross_mark").addClass("cross_mark_success"), $("#error_space").addClass("show_error"), setTimeout(function() {
        $("#error_space").removeClass("show_error"), $(".cross_mark").removeClass("cross_mark_success"), $(".top_msg").html("")
    }, 5e3)
}

function show_blur_screen() {
    $(".blur").css({
        "z-index": 3,
        opacity: .6
    }), $("html, body").css({
        overflow: "hidden"
    })
}

function xhr() {
    var xmlhttp;
    if (window.XMLHttpRequest) xmlhttp = new XMLHttpRequest;
    else if (window.ActiveXObject) try {
        xmlhttp = new ActiveXObject("Msxml2.XMLHTTP")
    } catch (e) {
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP")
    }
    return xmlhttp
}

function sendRequestWithCallback(action, params, async, callback, method, encryptionpath, encryptionvalue, URIEncryptionNeeeded) {
    var encryptionPromise;
    encryptionPromise = "function" == typeof triggerEncryption ? triggerEncryption(params, encryptionpath, encryptionvalue, URIEncryptionNeeeded) : Promise.resolve({
        data: params
    }), encryptionPromise.then(function(keyandvalue) {
        "undefined" != typeof contextpath && (action = URIEncryptionNeeeded && encryptData.enabled && keyandvalue ? contextpath + keyandvalue.data : contextpath + action);
        var objHTTP = xhr();
        objHTTP.open(method ? method : "POST", action, async), objHTTP.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"), objHTTP.setRequestHeader("X-ZCSRF-TOKEN", csrfParam + "=" + euc(getCookie(csrfCookieName))), keyandvalue && keyandvalue.key && objHTTP.setRequestHeader("Waf-Encryption-Key", keyandvalue.key), async &&(objHTTP.onreadystatechange = function() {
            if (4 === objHTTP.readyState) {
                if (0 === objHTTP.status) return handleConnectionError(), !1;
                callback && callback(objHTTP.responseText)
            }
        }), objHTTP.send(URIEncryptionNeeeded && encryptData.enabled ? params : keyandvalue.data), !async &&callback && callback(objHTTP.responseText)
    })
}

function redirectLink(link, ele) {
    ele && disabledButton(ele), window.location.href = link
}

function err_remove() {
    $(".err_text").remove(), $(".chk_err_text").remove(), $(".textbox_div").removeClass("error_field_card")
}

function disabledButton(form_ele) {
    $(form_ele).attr("disabled", "disabled"), $(form_ele).addClass("disable_button")
}

function removeButtonDisable(form_ele) {
    $(form_ele).removeAttr("disabled"), $(form_ele).removeClass("disable_button")
}

function getCookie(cname) {
    for (var name = cname + "=", decodedCookie = decodeURIComponent(document.cookie), ca = decodedCookie.split(";"), i = 0; i < ca.length; i++) {
        for (var c = ca[i];
            " " == c.charAt(0);) c = c.substring(1);
        if (0 == c.indexOf(name)) return c.substring(name.length, c.length)
    }
    return ""
}

function isUserName(str) {
    if (!str) return !1;
    var objRegExp = new XRegExp("^[\\p{L}\\p{N}\\p{M}\\_\\.\\-]+$", "i");
    return XRegExp.test(str.trim(), objRegExp)
}

function isValidNameString(str) {
    var objRegExp = new XRegExp("^[\\p{L}\\p{M}\\p{N}\\-\\_\\ \\.\\+\\!\\[\\]\\']+$", "i");
    return objRegExp.test(str.trim())
}

function doGet(action, params) {
    "undefined" != typeof contextpath && (action = contextpath + action);
    var objHTTP;
    return objHTTP = xhr(), isEmpty(params) && (params = "__d=e"), objHTTP.open("GET", action + "?" + params, !1), objHTTP.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"), objHTTP.send(params), objHTTP.responseText
}

function check_pp(cases, spl, num, minlen, formID, passInputID) {
    validatePasswordPolicy().validate(formID, passInputID)
}

function validatePasswordPolicy(passwordPolicy) {
    passwordPolicy = passwordPolicy || PasswordPolicy.data;
    var initCallback = function(id, msg) {
            var li = document.createElement("li");
            return li.setAttribute("id", "pp_" + id), li.setAttribute("class", "pass_policy_rule"), li.textContent = msg, li
        },
        setErrCallback = function(id) {
            return $("#pp_" + id).removeClass("success"), id
        };
    return {
        getErrorMsg: function(value, callback) {
            if (passwordPolicy) {
                var isInit = value ? !1 : !0;
                value = value ? value.trim() : "", callback = callback || setErrCallback;
                var rules = ["MIN_MAX", "SPL", "NUM", "CASE"],
                    err_rules = [];
                isInit || $(".pass_policy_rule").addClass("success");
                for (var i = 0; i < rules.length; i++) switch (rules[i]) {
                    case "MIN_MAX":
                        (value.length < passwordPolicy.min_length || value.length > passwordPolicy.max_length) && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get("IAM.PASS_POLICY.MIN_MAX"), passwordPolicy.min_length.toString(), passwordPolicy.max_length.toString()) : void 0));
                        break;
                    case "SPL":
                        passwordPolicy.min_spl_chars > 0 && (value.match(new RegExp("[^a-zA-Z0-9]", "g")) || []).length < passwordPolicy.min_spl_chars && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get(1 === passwordPolicy.min_spl_chars ? "IAM.PASS_POLICY.SPL_SING" : "IAM.PASS_POLICY.SPL"), passwordPolicy.min_spl_chars.toString()) : void 0));
                        break;
                    case "NUM":
                        passwordPolicy.min_numeric_chars > 0 && (value.match(new RegExp("[0-9]", "g")) || []).length < passwordPolicy.min_numeric_chars && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get(1 === passwordPolicy.min_numeric_chars ? "IAM.PASS_POLICY.NUM_SING" : "IAM.PASS_POLICY.NUM"), passwordPolicy.min_numeric_chars.toString()) : void 0));
                        break;
                    case "CASE":
                        !passwordPolicy.mixed_case || new RegExp("[A-Z]", "g").test(value) && new RegExp("[a-z]", "g").test(value) || err_rules.push(callback(rules[i], isInit ? I18N.get("IAM.PASS_POLICY.CASE") : void 0))
                }
                return "undefined" != typeof isClientPortal && isClientPortal && (0 == err_rules.length ? $(".hover-tool-tip").hide() : $(".hover-tool-tip").show()), err_rules.length && err_rules
            }
        },
        init: function(passInputID) {
            $(".hover-tool-tip").remove();
            var tooltip = document.createElement("div");
            tooltip.setAttribute("class", isMobile ? "hover-tool-tip no-arrow" : "hover-tool-tip");
            var p = document.createElement("p");
            p.textContent = I18N.get("IAM.PASS_POLICY.HEADING");
            var ul = document.createElement("ul"),
                errList = this.getErrorMsg(void 0, initCallback);
            errList && (errList.forEach(function(eachLi) {
                ul.appendChild(eachLi)
            }), tooltip.appendChild(p), tooltip.appendChild(ul), document.querySelector("body").appendChild(tooltip), $(passInputID).on("focus blur", function(e) {
                if ("focus" === e.type) {
                    var offset = document.querySelector(passInputID).getBoundingClientRect();
                    $(".hover-tool-tip").css("rtl" === $("body").attr("dir") ? isMobile ? {
                        top: offset.bottom + $(window).scrollTop() + 8,
                        right: offset.x,
                        width: offset.width - 40
                    } : {
                        top: offset.y + $(window).scrollTop(),
                        right: offset.x + offset.width + 15
                    } : isMobile ? {
                        top: offset.bottom + $(window).scrollTop() + 8,
                        left: offset.x,
                        width: offset.width - 40
                    } : {
                        top: offset.y + $(window).scrollTop(),
                        left: offset.x + offset.width + 15
                    }), "undefined" != typeof isClientPortal && isClientPortal && $(".hover-tool-tip").css({
                        top: offset.bottom + $(window).scrollTop() + 8,
                        left: offset.x,
                        width: offset.width - 40
                    }), $(".hover-tool-tip").show()
                } else {
                    $(".hover-tool-tip").hide();
                    var offset = document.querySelector(".hover-tool-tip").getBoundingClientRect();
                    $(".hover-tool-tip").css("rtl" === $("body").attr("dir") ? {
                        top: -offset.height,
                        right: -(offset.width + 15)
                    } : {
                        top: -offset.height,
                        left: -(offset.width + 15)
                    })
                }
            }))
        },
        validate: function(formID, passInputID) {
            var str = $(passInputID).val();
            this.getErrorMsg(str, setErrCallback) ? $(".hover-tool-tip").show() : $(".hover-tool-tip").hide()
        }
    }
}

function isNumeric(obj) {
    var reg = /^\d+$/;
    return reg.test(obj)
}

function decodeHTML(t) {
    return "" != t ? $("<textarea />").html(t).text() : ""
}

function updateIcon() {
    $(".selectbox_options_container--Mobile").width($(".selectbox--Mobile").outerWidth() + "px"), $(".option--Mobile p").addClass("icon-Mobile"), $(".icon-Mobile").each(function() {
        $(this).html("<span style=width:" + $(".option--Mobile").width() + "px;overflow:hidden;white-space:nowrap;text-overflow:ellipsis;font-family:ZohoPuvi;>" + $(this).text() + "</span>")
    })
}

function ischaracter(obj) {
    var reg = /^[A-Za-z]+$/;
    return reg.test(obj)
}

function renderUV(locator, search, drpWidth, drpAlign, embedIcon, CF, CC, theme, Mobstyle, flagCodeAttribute, countryCodeAttribute, useThisAttrAsValue) {
    $(locator).uvselect({
        searchable: search,
        "dropdown-width": $(drpWidth).outerWidth() + "px",
        "dropdown-align": drpAlign,
        "embed-icon-class": embedIcon,
        "country-flag": CF,
        "flag-code-attr": flagCodeAttribute,
        "country-code": CC,
        "country-code-attr": countryCodeAttribute,
        theme: theme,
        prevent_mobile_style: Mobstyle,
        "use-attr-as-value": useThisAttrAsValue
    })
}

function isValidCode(code) {
    if (0 != code.trim().length) {
        var codePattern = new RegExp("^([0-9]{" + otp_length + "})$");
        return codePattern.test(code) ? !0 : !1
    }
    return !1
}

function hideCommonLoader() {
    $(".load-bg").is(":visible") && setTimeout(function() {
        document.querySelector(".load-bg").classList.add("load-fade"), setTimeout(function() {
            document.querySelector(".load-bg").style.display = "none", isMobile || $("#login_id").focus()
        }, 50)
    }, 100)
}

function mobileviewDevices(select_ID) {
    $(select_ID).parent().children().hasClass("devicelist") || $(select_ID).parent().append($("<div class='devicelist'><span class='device_icon icon-Mobile'></span><div class='devicename'></div><span class='mobile_dev_arrow'></span></div>")), 1 == $(select_ID + " option").length && $(".mobile_dev_arrow").hide(), updatedevices(select_ID)
}

function updatedevices(select_ID) {
    $(".devicename").html($(select_ID).find(":selected")[0].innerHTML), handlewidthOfSelect(select_ID)
}

function handlewidthOfSelect(select_ID) {
    $(select_ID).css("width", $(".devicelist").outerWidth())
}

function mobileflag() {
    $("#country_code_select").find(":selected").attr("id") && (0 == $(".mobileFlag").length && ($("#country_code_select").parent().prepend($("<div class='MobflagContainer' style='position:absolute;display:inline-flex;'><i class='mobileFlag' style='margin-top:12px;'></i><label for='country_code_select' class='select_country_code'></label><span class='arrow_position'><b style='height: 0px; width: 0px;border-color: transparent #CCCCCC #CCCCCC transparent;border-style: solid;transform: rotate(45deg);border-width: 3px;display: inline-block;position: relative;'><b><span></div>")), $(".MobflagContainer").hide()), $(".mobileFlag").html(""), hideUVFlag || addFlagIcon($(".mobileFlag"), $("#country_code_select").find(":selected").attr("id")))
}

function getToastTimeDuration(msg) {
    var timing = 333.3 * msg.split(" ").length;
    return timing > 3e3 ? timing : 3e3
}

function isValidSecurityKeyName(val) {
    var pattern = /^[0-9a-zA-Z_\-\+\.\$@\,\:\'\!\[\]\|\u0080-\uFFFF\s]+$/;
    return pattern.test(val.trim()) && !hasEmoji(val.trim()) ? !0 : !1
}

function showAutheticationError(msg, field) {
    $("#" + field + " .fielderror").html(msg), $("#" + field + " .fielderror").slideDown(300)
}

function remove_err() {
    $(".fielderror:visible").slideUp(300, function() {
        this.text = ""
    })
}

function hideResendOTP() {
    $(".resendotp").hasClass("sendingotp") && $(".resendotp").removeClass("sendingotp"), $(".resendotp").addClass("nonclickelem"), $(".resendotp").html(I18N.get("IAM.NEW.SIGNIN.RESEND.OTP")), $(".resendotp").hide()
}

function isValid(instr) {
    return null != instr && "" != instr && "null" != instr
}

function handleConnectionError() {
    return $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), isFormSubmited = !1, showTopErrNotification(navigator.onLine && "undefined" != typeof NIC_support_email ? formatMessage(I18N.get("NIC.ONLINE.ERROR.MESSAGE"), NIC_support_email) : I18N.get("IAM.PLEASE.CONNECT.INTERNET")), ZASEC.Encryption.makeitnull(null), !1
}

function allownumonly(element) {
    isEmailId(element.value) && (element.value = ""), element.value = element.value.replace(/[^0-9]/g, "")
}

function removeAndAddEventListener(ele, event, callback) {
    $(ele).off(event), $(ele).removeAttr("on" + event), $(ele).on(event, callback)
}

function handleDomainForPortal(domains) {
    return 1 != $("#portaldomain").length ? !1 : ($("#login_id").attr("placeholder", ""), $("#login_id").css("borderRadius", "2px 0px 0px 2px"), $("#portaldomain").show(), $("#login_id").css("width", "55%"), $("#portaldomain").css("width", "45%"), $("#login_id").css("display", "inline-block"), $.each(domains, function(i, v) {
        var optVal = "@" + v;
        $("#domaincontainer").append($("<option></option>").attr("value", optVal).text(optVal))
    }), 1 === domains.length ? ($("#portaldomain").append("<span class='close'> </span>"), $("#portaldomain .close").click(function() {
        handleDomainChange(!0)
    })) : ($("#domaincontainer").append($("<option class='option option--domain_select removedomain'></option>").attr("value", "removedomain").text(I18N.get("IAM.SIGNIN.REMOVE.DOMAIN"))), isMobile || (renderUV(".domainselect", !1, "", "", "", !1, !1, "domain_select", !0, null, null, "value"), $("#domaincontainer").change(function() {
        handleDomainChange()
    }))), isMobile && ($(".domainselect").hasClass("select2-hidden-accessible") && $(".domainselect").select2("destroy"), $(".domainselect").show()), void(1 === domains.length ? ($(".domainselect").show(), $("#domaincontainer").addClass("nonclickelem"), $(".selectbox_arrow").hide()) : ($("#portaldomain .select2-selection").addClass("select2domain"), $("#portaldomain .select2").css("width", "196px !important"), $("#portaldomain .select2").show())))
}

function handleDomainChange(isClose) {
    ("removedomain" === $("#domaincontainer").val() || isClose === !0) && ($("#login_id").css("borderRadius", "2px"), $("#portaldomain").hide(0, function() {
        $("#login_id").css("width", "100%"), $("#login_id").focus()
    }), $(".doaminat").show())
}

function enableDomain() {
    $("#login_id").css("width", "55%"), setTimeout(function() {
        $(".domainselect").val($(".domainselect option:first").val()), $(".select_input--domain_select").val($(".domainselect").val()), $("#portaldomain").css("width", "45%"), $("#login_id").css("display", "inline-block"), $("#login_id").css("borderRadius", "2px 0px 0px 2px"), $(".doaminat").hide(), $("#portaldomain").show()
    }, 200)
}

function postRedirection(url, loginid, target, csrfneeded) {
    var oldForm = document.getElementById("postredirection");
    oldForm && document.documentElement.removeChild(oldForm);
    var form = document.createElement("form");
    form.setAttribute("id", "postredirection"), form.setAttribute("method", "POST"), form.setAttribute("action", url), form.setAttribute("target", void 0 === target ? "_self" : target);
    var hiddenField = document.createElement("input");
    if (loginid && (hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "LOGIN_ID"), hiddenField.setAttribute("value", loginid)), csrfneeded) {
        var csrfField = document.createElement("input");
        csrfField.setAttribute("type", "hidden"), csrfField.setAttribute("name", csrfParam), csrfField.setAttribute("value", getCookie(csrfCookieName)), form.appendChild(csrfField)
    }
    return form.appendChild(hiddenField), document.documentElement.appendChild(form), form.submit(), !1
}

function throttle(func, delay) {
    var lastTime = 0;
    return function() {
        var now = Date.now();
        now - lastTime >= delay && (func.apply(this, arguments), lastTime = now)
    }
}

function submitsignin(frm, event) {
    if (event && "function" == typeof event.preventDefault ? event.preventDefault() : void 0 != window.event && "function" == typeof window.event.preventDefault && window.event.preventDefault(), $(".signin_head .fielderror").removeClass("errorlabel"), $(".signin_head .fielderror").text(""), isFormSubmited) return !1;
    $("#nextbtn span").addClass("zeroheight"), $("#nextbtn").addClass("changeloadbtn"), $("#nextbtn").attr("disabled", !0), $("#totpverifybtn").is(":visible") && ($("#totpverifybtn .loadwithbtn").show(), $("#totpverifybtn .waittext").addClass("loadbtntext"));
    var isCaptchaNeeded = $("#captcha_container").is(":visible"),
        captchavalue = frm.captcha && frm.captcha.value.trim();
    if (isCaptchaNeeded) {
        if (!isValid(captchavalue)) return showCommonError("captcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.REQUIRED"), !0), !1;
        if (!/^[a-zA-Z0-9]*$/.test(captchavalue)) return showCommonError("captcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.INVALID"), !0), !1
    }
    if ("lookup" === signinathmode) {
        var LOGIN_ID = frm.LOGIN_ID.value.trim();
        if ($("#portaldomain").is(":visible") && (LOGIN_ID += $(".domainselect").val()), !isValid(LOGIN_ID)) {
            var errorContent = emailOnlySignin ? "IAM.NEW.SIGNIN.ENTER.EMAIL.ADDRESS" : isMobilenumberOnly ? "IAM.NEW.SIGNIN.ENTER.MOBILE.NUMBER" : "IAM.NEW.SIGNIN.ENTER.EMAIL.OR.MOBILE";
            return showCommonError("login_id", I18N.get(errorContent)), !1
        }
        if (($(".showcountry_code").is(":visible") || $(".select_container--country_implement").is(":visible")) && !isPhoneNumber(LOGIN_ID)) return showCommonError("login_id", I18N.get("IAM.PHONE.ENTER.VALID.MOBILE_NUMBER")), !1;
        if (emailOnlySignin && isPhoneNumber(LOGIN_ID.split("-")[1] ? LOGIN_ID.split("-")[1] : LOGIN_ID.split("-")[0])) return showCommonError("login_id", I18N.get("IAM.ERROR.EMAIL.INVALID")), !1;
        if (!isUserName(LOGIN_ID) && !isEmailIdSignin(LOGIN_ID) && !isPhoneNumber(LOGIN_ID.split("-")[1]) || isPhoneNumber(LOGIN_ID.split("-")[1]) && -1 != LOGIN_ID.split("-")[0].indexOf("+")) {
            var errorContent = emailOnlySignin ? "IAM.NEW.SIGNIN.INVALID.LOOKUP.EMAIL" : isMobilenumberOnly ? "IAM.NEW.SIGNIN.INVALID.LOOKUP.MOBILE" : "IAM.NEW.SIGNIN.INVALID.LOOKUP.IDENTIFIER";
            return showCommonError("login_id", I18N.get(errorContent)), !1
        }
        isEmailId(LOGIN_ID) && (LOGIN_ID = LOGIN_ID.toLowerCase()), LOGIN_ID = $(".select_country_code").is(":visible") || $(".select_container--country_implement").is(":visible") ? $("#country_code_select").val().split("+")[1] + "-" + LOGIN_ID : LOGIN_ID, LOGIN_ID = isPhoneNumber(LOGIN_ID.split("-")[1]) ? LOGIN_ID.split("-")[0].trim() + "-" + LOGIN_ID.split("-")[1].trim() : LOGIN_ID;
        var loginurl = uriPrefix + "/signin/v2/lookup/" + LOGIN_ID,
            encryptionJson = {
                path: loginurl,
                value: LOGIN_ID
            },
            params = "mode=primary&" + signinParams;
        return isCaptchaNeeded && (params += "&captcha=" + captchavalue + "&cdigest=" + cdigest), sendRequestWithCallback(loginurl, params, !0, handleLookupDetails, void 0, encryptionJson, LOGIN_ID, !0), !1
    }
    if ("passwordauth" === signinathmode || "ldappasswordauth" === signinathmode) {
        if (void 0 != allowedmodes && -1 != allowedmodes.indexOf("yubikey") && !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), changeButtonAction(I18N.get("IAM.NEXT"), !1), !1;
        var PASSWORD = frm.PASSWORD.value.trim();
        if (!isValid(PASSWORD)) return showCommonError("password", I18N.get("IAM.ERROR.ENTER_PASS")), !1;
        var jsonData = "passwordauth" === signinathmode ? {
                passwordauth: {
                    password: PASSWORD
                }
            } : {
                ldappasswordauth: {
                    password: PASSWORD
                }
            },
            encryptionJson = {
                path: "passwordauth" === signinathmode ? "passwordauth.password" : "ldappasswordauth.password",
                value: PASSWORD
            },
            loginurl = "passwordauth" === signinathmode ? uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/password?" : uriPrefix + "/onpremise/signin/v2/" + callmode + "/" + zuid + "/ldappasswordauth?";
        return loginurl += "digest=" + digest + "&" + signinParams, isCaptchaNeeded && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest), sendRequestWithCallback(loginurl, JSON.stringify(jsonData), !0, handlePasswordDetails, void 0, encryptionJson, PASSWORD), !1
    }
    if ("totpsecauth" === signinathmode || "oneauthsec" === signinathmode && "ONEAUTH_TOTP" === prefoption || "totpauth" === signinathmode) {
        if (isClientPortal) var TOTP = frm.TOTP.value.trim();
        else var TOTP = document.getElementById("mfa_totp").firstChild.value.trim();
        if (!isValid(TOTP)) return showCommonError("mfa_totp", I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.EMPTY")), !1;
        if (TOTP.length != totp_size) return showCommonError("mfa_totp", I18N.get("IAM.ERROR.VALID.OTP")), !1;
        if (/[^0-9\-\/]/.test(TOTP)) return showCommonError("mfa_totp", I18N.get("IAM.SIGNIN.ERROR.INVALID.VERIFICATION.CODE")), !1;
        callmode = "totpauth" === signinathmode ? "primary" : "secondary";
        var loginurl = "ONEAUTH_TOTP" === prefoption ? uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/oneauth/" + deviceid + "?" : uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/totp?";
        loginurl += "digest=" + digest + "&" + signinParams, isCaptchaNeeded && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest);
        var jsonData = "ONEAUTH_TOTP" === prefoption ? {
                oneauthsec: {
                    devicepref: prefoption,
                    code: TOTP
                }
            } : "totpauth" === signinathmode ? {
                totpauth: {
                    code: TOTP
                }
            } : {
                totpsecauth: {
                    code: TOTP
                }
            },
            method = "ONEAUTH_TOTP" === prefoption ? "PUT" : "POST";
        loginurl = "ONEAUTH_TOTP" === prefoption ? loginurl + "&polling=" + !1 : loginurl;
        var callback = "totpauth" === signinathmode ? handlePasswordDetails : handleTotpDetails;
        return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, callback, method), !1
    }
    if ("otpsecauth" === signinathmode) {
        if (isClientPortal) var TFA_OTP_CODE = frm.MFAOTP.value.trim();
        else var TFA_OTP_CODE = $("#mfa_otp input:first-child").val() && $("#mfa_otp input:first-child").val().trim();
        var errorfield = "mfa_otp",
            incorrectOtpErr = I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.NEW");
        if ("email" === prev_showmode && (TFA_OTP_CODE = isClientPortal ? frm.MFAEMAIL.value.trim() : $("#mfa_email input:first-child").val() && $("#mfa_email input:first-child").val().trim(), errorfield = "mfa_email", incorrectOtpErr = I18N.get("IAM.NEW.SIGNIN.INVALID.EMAIL.MESSAGE.NEW")), !isValid(TFA_OTP_CODE)) return showCommonError(errorfield, I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.EMPTY")), !1;
        if (isNaN(TFA_OTP_CODE) || !isValidCode(TFA_OTP_CODE)) return showCommonError(errorfield, incorrectOtpErr), !1;
        if (/[^0-9\-\/]/.test(TFA_OTP_CODE)) return showCommonError(errorfield, I18N.get("IAM.SIGNIN.ERROR.INVALID.VERIFICATION.CODE")), !1;
        var mode = "email" === prev_showmode ? "EMAIL" : "MOBILE";
        callmode = "secondary";
        var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/otp/" + emobile + "?";
        loginurl += "digest=" + digest + "&" + signinParams, isCaptchaNeeded && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest);
        var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
            jsonData = isAMFA ? {
                otpsecauth: {
                    mdigest: mdigest,
                    code: TFA_OTP_CODE,
                    isAMFA: !0,
                    mode: mode
                }
            } : {
                otpsecauth: {
                    mdigest: mdigest,
                    code: TFA_OTP_CODE,
                    mode: mode
                }
            };
        return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleTotpDetails, "PUT"), !1
    }
    if ("otpauth" === signinathmode) {
        if (isClientPortal) var OTP_CODE = frm.OTP.value.trim();
        else var OTP_CODE = document.getElementById("otp").firstChild.value.trim();
        if (void 0 != allowedmodes && -1 != allowedmodes.indexOf("yubikey") && !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), changeButtonAction(I18N.get("IAM.NEW.SIGNIN.VERIFY"), !1), !1;
        if (!isValid(OTP_CODE)) return showCommonError("otp", I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.EMPTY")), !1;
        if (isNaN(OTP_CODE) || !isValidCode(OTP_CODE)) {
            var error_msg = I18N.get("email" === prev_showmode ? "IAM.NEW.SIGNIN.INVALID.EMAIL.MESSAGE.NEW" : "IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.NEW");
            return showCommonError("otp", error_msg), !1
        }
        if (/[^0-9\-\/]/.test(OTP_CODE)) return showCommonError("otp", I18N.get("IAM.SIGNIN.ERROR.INVALID.VERIFICATION.CODE")), !1;
        var mode = "email" === prev_showmode ? "EMAIL" : "MOBILE",
            loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/otp/" + emobile + "?";
        loginurl += "digest=" + digest + "&" + signinParams, isCaptchaNeeded && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest);
        var jsonData = {
            otpauth: {
                code: OTP_CODE,
                is_resend: !1,
                mode: mode
            }
        };
        return sendRequestWithCallback(loginurl, JSON.stringify(jsonData), !0, handlePasswordDetails, "PUT"), !1
    }
    if ("deviceauth" === signinathmode || "devicesecauth" === signinathmode) {
        var myzohototp;
        if (clearTimeout(oneauthgrant), "totp" === prefoption) {
            if (myzohototp = isClientPortal ? isTroubleSignin ? frm.MFATOTP.value.trim() : frm.TOTP.value.trim() : isTroubleSignin ? document.getElementById("verify_totp").firstChild.value.trim() : document.getElementById("mfa_totp").firstChild.value.trim(), !isValid(myzohototp)) {
                var container = isTroubleSignin ? "verify_totp" : "mfa_totp";
                return showCommonError(container, I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.EMPTY")), !1
            }
            if (myzohototp.length != totp_size) {
                var container = isTroubleSignin ? "verify_totp" : "mfa_totp";
                return showCommonError(container, I18N.get("IAM.ERROR.VALID.OTP")), !1
            }
        }
        var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/device/" + deviceid + "?";
        loginurl += "digest=" + digest + "&" + signinParams, isResend = "push" === prefoption ? !0 : !1;
        var jsonData = "totp" === prefoption ? {
            devicesecauth: {
                devicepref: prefoption,
                code: myzohototp
            }
        } : {
            devicesecauth: {
                devicepref: prefoption
            }
        };
        "deviceauth" === signinathmode && (jsonData = "totp" === prefoption ? {
            deviceauth: {
                devicepref: prefoption,
                code: myzohototp
            }
        } : {
            deviceauth: {
                devicepref: prefoption
            }
        });
        var method = "POST",
            invoker = handleMyZohoDetails;
        return "totp" === prefoption && (method = "PUT", loginurl += "&polling=" + !1, invoker = handleTotpDetails), sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, invoker, method), !1
    }
    if ("oneauthsec" === signinathmode) {
        var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/oneauth/" + deviceid + "?";
        loginurl += "digest=" + digest + "&" + signinParams;
        var jsonData = {
            oneauthsec: {
                devicepref: prefoption
            }
        };
        return isResend = "totp" === prefoption || "scanqr" === prefoption ? !1 : !0, sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleOneAuthDetails), !1
    }
    if ("yubikeysecauth" === signinathmode) {
        if (clearCommonError("yubikey"), !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), !1;
        var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/yubikey/self?" + signinParams;
        return sendRequestWithTemptoken(loginurl, "", !0, handleYubikeyDetails), !1
    }
    return void 0 == signinathmode ? ($("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#totpverifybtn").is(":visible") && ($("#totpverifybtn .loadwithbtn").hide(), $("#totpverifybtn .waittext").removeClass("loadbtntext")), !1) : (isFormSubmited = !0, !1)
}

function sendRequestWithTemptoken(action, params, async, callback, method, encryptionpath, encryptionvalue) {
    triggerEncryption(params, encryptionpath, encryptionvalue).then(function(keyandvalue) {
        "undefined" != typeof contextpath && (action = contextpath + action);
        var objHTTP = xhr();
        objHTTP.open(method ? method : "POST", action, async), objHTTP.setRequestHeader("Content-Type", "application/x-www-form-urlencoded;charset=UTF-8"), isValid(temptoken) && objHTTP.setRequestHeader("Z-Authorization", "Zoho-ticket " + temptoken), keyandvalue && keyandvalue.key && objHTTP.setRequestHeader("Waf-Encryption-Key", keyandvalue.key), objHTTP.setRequestHeader("X-ZCSRF-TOKEN", csrfParam + "=" + euc(getCookie(csrfCookieName))), async &&(objHTTP.onreadystatechange = function() {
            if (4 == objHTTP.readyState) {
                if (0 === objHTTP.status) return handleConnectionError(), !1;
                callback && callback(objHTTP.responseText)
            }
        }), objHTTP.send(keyandvalue.data), async ||callback && callback(objHTTP.responseText)
    })
}

function showCommonError(field, message, skipReload) {
    if ($(".fielderror").val(""), $(".changeloadbtn").is(":visible")) {
        var btnvalue = I18N.get("login_id" === field ? "IAM.NEXT" : "password" === field ? "IAM.SIGN_IN" : "IAM.NEW.SIGNIN.VERIFY");
        changeButtonAction(btnvalue, !1)
    }
    skipReload || ("captcha" === field || "bcaptcha" === field ? $("#bcaptcha_container").is(":visible") ? changeHip("bcaptcha_img", "bcaptcha") : changeHip() : ($("#captcha_container,#bcaptcha_container").hide(), $("#captcha,#bcaptcha").val(""))), $(".sendingotp").is(":visible") && ($(".resendotp").removeClass("sendingotp").addClass("nonclickelem"), $(".resendotp").text(I18N.get("IAM.NEW.SIGNIN.RESEND.OTP")));
    var container = field + "_container";
    return $("#" + field).addClass("errorborder"), $("#" + container + " .fielderror").addClass("errorlabel"), $("#" + container + " .fielderror").html(message), $("#" + container + " .fielderror").slideDown(200), $("#" + field).focus(), $("#totpverifybtn").is(":visible") && ($("#totpverifybtn .loadwithbtn").hide(), $("#totpverifybtn .waittext").removeClass("loadbtntext")), !1
}

function callback_signin_lookup(msg) {
    return showCommonError("login_id", msg), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEXT")), isFormSubmited = !1, !1
}

function changeButtonAction(textvalue, isSubmitted) {
    return $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").html(textvalue), isFormSubmited = isSubmitted, !1
}

function identifyEmailOrNum(login_id, encryptedMobile) {
    var userLogin = isValid(login_id) ? login_id : deviceauthdetails[deviceauthdetails.resource_name].loginid;
    return isPhoneNumber(userLogin.split("-")[1]) || encryptedMobile ? "+" + userLogin.split("-")[0] + " " + userLogin.split("-")[1] : userLogin
}

function validateAllowedMode(option, removeany) {
    var optionToShow = {
            enableMore: !1,
            nootheroption: !0,
            option: option
        },
        fallBackOption = allowedmodes.slice();
    fallBackOption.splice(fallBackOption.indexOf(option), 1), removeany && fallBackOption.splice(fallBackOption.indexOf(removeany), 1);
    var countOfMode = fallBackOption.length;
    return fallBackOption.forEach(function(mode) {
        ("jwt" == mode || "saml" == mode || "federated" == mode || "oidc" == mode) && countOfMode--
    }), countOfMode > 1 && (optionToShow.enableMore = !0, isShowEnableMore = !0, optionToShow.option = ""), 1 == countOfMode && (optionToShow.option = fallBackOption[0], optionToShow.nootheroption = !1), optionToShow
}

function appendSAML(count) {
    var samlDisplayName = deviceauthdetails.lookup.modes.saml.data[count].display_name ? " - " + deviceauthdetails.lookup.modes.saml.data[count].display_name : "",
        samlElement = document.createElement("span");
    samlElement.setAttribute("class", "saml_signin SAMLval_" + count), samlElement.setAttribute("title", "SAML" + samlDisplayName), samlElement.innerHTML = '<span class="icon-fsaml"></span>SAML' + samlDisplayName, document.getElementById("fed_signin_options").appendChild(samlElement), $(".SAMLval_" + count).on("click", function() {
        redirectToSaml(deviceauthdetails.lookup.modes.saml.data[count])
    })
}

function appendOIDC(count) {
    var oidc_id = deviceauthdetails.lookup.modes.oidc.data[count].oidc_id,
        DisplayName = deviceauthdetails.lookup.modes.oidc.data[count].display_name ? " - " + deviceauthdetails.lookup.modes.oidc.data[count].display_name : "",
        elementToAppend = document.createElement("span");
    elementToAppend.setAttribute("class", "oidc_signin OIDCval_" + count), elementToAppend.setAttribute("title", "OpenID" + DisplayName), elementToAppend.innerHTML = '<span class="icon-openid"><span class="path1"></span><span class="path2"></span><span class="path3"></span></span>OpenID' + DisplayName, document.getElementById("fed_signin_options").appendChild(elementToAppend), $("#fed_signin_options .OIDCval_" + count).on("click", function() {
        enableOIDCAuth(oidc_id)
    })
}

function appendJWT(count) {
    var redirectURI = deviceauthdetails.lookup.modes.jwt.data[count].redirect_uri,
        DisplayName = deviceauthdetails.lookup.modes.jwt.data[count].display_name ? " - " + deviceauthdetails.lookup.modes.jwt.data[count].display_name : "",
        elementToAppend = document.createElement("span");
    elementToAppend.setAttribute("class", "jwt_signin JWTval" + count), elementToAppend.setAttribute("title", "JWT" + DisplayName), elementToAppend.innerHTML = '<span class="icon-jwt_d"><span class="path1"></span><span class="path2"></span><span class="path3"></span><span class="path4"></span><span class="path5"></span><span class="path6"></span></span>JWT' + DisplayName, document.getElementById("fed_signin_options").appendChild(elementToAppend), $("#fed_signin_options .JWTval" + count).on("click", function() {
        switchto(redirectURI)
    })
}

function enableOIDCAuth(OIDCId) {
    OIDCId = void 0 === OIDCId ? deviceauthdetails.lookup.modes.oidc.data[0].oidc_id : OIDCId;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/oidcauth/" + OIDCId + "?";
    return loginurl += "digest=" + digest + "&" + signinParams, sendRequestWithTemptoken(loginurl, "", !0, handleOIDCAuthdetails), !1
}

function handleOIDCAuthdetails(resp) {
    if (!IsJsonString(resp)) return showTopErrNotification(I18N.get("IAM.ERROR.GENERAL")), !1;
    var jsonStr = JSON.parse(resp);
    switchto(jsonStr.oidcauth.redirect_uri)
}

function enableSamlAuth(samlAuthDomain) {
    var login_id = deviceauthdetails.lookup.loginid;
    samlAuthDomain = void 0 === samlAuthDomain ? deviceauthdetails.lookup.modes.saml.data[0].auth_domain : samlAuthDomain;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/samlauth/" + samlAuthDomain + "?";
    loginurl += "digest=" + digest + "&" + signinParams;
    var jsonData = {
        samlauth: {
            login_id: login_id
        }
    };
    return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleSamlAuthdetails), !1
}

function handleSamlAuthdetails(resp) {
    if (!IsJsonString(resp)) return showTopErrNotification(I18N.get("IAM.ERROR.GENERAL")), !1;
    var jsonStr = JSON.parse(resp);
    if (1 == jsonStr.samlauth.method && isValid(jsonStr.samlauth.redirect_uri) && isValid(jsonStr.samlauth.RelayState) && isValid(jsonStr.samlauth.SAMLRequest)) {
        var form = document.createElement("form");
        form.setAttribute("id", "samlform"), form.setAttribute("method", "POST"), form.setAttribute("action", jsonStr.samlauth.redirect_uri), form.setAttribute("target", "_self");
        var RelayState = document.createElement("input"),
            SAMLRequest = document.createElement("input");
        return RelayState.setAttribute("type", "hidden"), RelayState.setAttribute("name", "RelayState"), RelayState.setAttribute("value", jsonStr.samlauth.RelayState), SAMLRequest.setAttribute("type", "hidden"), SAMLRequest.setAttribute("name", "SAMLRequest"), SAMLRequest.setAttribute("value", jsonStr.samlauth.SAMLRequest), form.appendChild(RelayState), form.appendChild(SAMLRequest), document.documentElement.appendChild(form), form.submit(), !1
    }
    switchto(jsonStr.samlauth.redirect_uri)
}

function enableOTP(enablemode) {
    return showAndGenerateOtp(enablemode), !1
}

function enableMfaField(mfamode) {
    if (callmode = "secondary", "totp" === mfamode) $("#password_container,#captcha_container,.fed_2show,#otp_container").hide(), $("#headtitle").text(I18N.get("IAM.NEW.SIGNIN.TOTP")), $(".service_name").text(I18N.get("IAM.NEW.SIGNIN.MFA.TOTP.HEADER")), $(".product_text,.product_head,.MAppIcon,.OnaAuthHLink,.pwless_head,.pwless_text").hide(), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_totp_mode"), mfaBanner = !0, $("#forgotpassword").hide(), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEW.SIGNIN.VERIFY")), isClientPortal || enableSplitField("mfa_totp", totp_size, I18N.get("IAM.NEW.SIGNIN.VERIFY.CODE")), $("#mfa_totp_container").show(), $(".service_name").addClass("extramargin"), isClientPortal ? $("#mfa_totp").focus() : setTimeout(function() {
        $("#mfa_totp").click()
    }, 100), isFormSubmited = !1, callmode = "secondary", goBackToProblemSignin(), signinathmode = "totpsecauth";
    else if ("otp" === mfamode) {
        MFAotpThresholdmob = 3, $("#password_container,#captcha_container,.fed_2show,#otp_container").hide();
        var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
            headTitle = I18N.get(isAMFA ? "IAM.AC.CHOOSE.OTHER_MODES.MOBILE.HEADING" : "IAM.NEW.SIGNIN.SMS.MODE");
        $("#headtitle").text(headTitle), isRecovery && ($("#headtitle").prepend("<span class='icon-backarrow backoption recbackop'></span>"), $(".recbackop").on("click", function() {
            hideCantAccessDevice(this)
        }));
        var descMsg = formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.HEADER"), rmobile);
        descMsg = isAMFA ? descMsg + "<br>" + formatMessage(I18N.get("IAM.NEW.SIGNIN.WHY.VERIFY"), suspisious_login_link) : descMsg, $(".service_name").html(descMsg), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_otp_mode"), mfaBanner = !0, showTopNotification(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.SENT"), rmobile)), isClientPortal || enableSplitField("mfa_otp", otp_length, I18N.get("IAM.VERIFY.CODE")), $("#mfa_otp_container,#mfa_otp_container .textbox_actions").show(), $("#forgotpassword").hide(), $(".service_name").addClass("extramargin"), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEW.SIGNIN.VERIFY")), isClientPortal ? $("#mfa_otp").focus() : setTimeout(function() {
            $("#mfa_otp").click()
        }, 100), isFormSubmited = !1, $(".resendotp").show(), goBackToProblemSignin(), callmode = "secondary", signinathmode = "otpsecauth"
    }
    return $(".loader,.blur").hide(), isRecovery || allowedModeChecking(), !1
}

function enableMyZohoDevice(jsonStr, trymode) {
    clearTimeout(oneauthgrant), jsonStr = isValid(jsonStr) ? jsonStr : deviceauthdetails, signinathmode = jsonStr.resource_name;
    var devicedetails = jsonStr[signinathmode].modes.mzadevice.data[parseInt(mzadevicepos)];
    prefoption = trymode ? trymode : devicedetails.prefer_option, devicename = devicedetails.device_name, deviceid = devicedetails.device_id, isSecondary = allowedmodes.length > 1 && -1 === allowedmodes.indexOf("recoverycode") && -1 === allowedmodes.indexOf("passphrase") ? !0 : !1, isSecondary = allowedmodes.length > 2 && -1 === allowedmodes.indexOf("recoverycode") && -1 === allowedmodes.indexOf("passphrase") ? !0 : isSecondary, isSecondary = -1 === allowedmodes.indexOf("recoverycode") && -1 === allowedmodes.indexOf("passphrase") && 3 === allowedmodes.length ? !1 : isSecondary, bioType = devicedetails.bio_type;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/device/" + deviceid + "?";
    loginurl += "digest=" + digest + "&" + signinParams;
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
        jsonData = "primary" === callmode ? {
            deviceauth: {
                devicepref: prefoption
            }
        } : {
            devicesecauth: {
                devicepref: prefoption
            }
        };
    return jsonData = "primary" != callmode && isAMFA ? {
        devicesecauth: {
            devicepref: prefoption,
            isAMFA: !0
        }
    } : jsonData, "undefined" != typeof device_validity_token && isValid(device_validity_token) && (jsonData = "primary" === callmode ? {
        deviceauth: {
            devicepref: prefoption,
            verify_device_token: device_validity_token
        }
    } : {
        devicesecauth: {
            devicepref: prefoption,
            verify_device_token: device_validity_token
        }
    }, jsonData = "primary" != callmode && isAMFA ? {
        devicesecauth: {
            devicepref: prefoption,
            isAMFA: !0,
            verify_device_token: device_validity_token
        }
    } : jsonData), sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleMyZohoDetails), signinathmode = "primary" === callmode ? "deviceauth" : "devicesecauth", !1
}

function enableOneauthDevice(jsonStr, index) {
    index = isValid(index) ? index : parseInt(oadevicepos), jsonStr = isValid(jsonStr) ? jsonStr : deviceauthdetails;
    var devicedetails = jsonStr[deviceauthdetails.resource_name].modes.oadevice.data[index];
    if (deviceid = devicedetails.device_id, prefoption = devicedetails.prefer_option, isFaceId = devicedetails.isFaceid, devicename = devicedetails.device_name, "ONEAUTH_TOTP" === prefoption) return enableTOTPdevice(jsonStr, !1, !0), !1;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/oneauth/" + deviceid + "?";
    loginurl += "digest=" + digest + "&" + signinParams;
    var jsonData = {
        oneauthsec: {
            devicepref: prefoption
        }
    };
    return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleOneAuthDetails), signinathmode = "oneauthsec", !1
}

function enableYubikeyDevice(jsonStr) {
    if (signinathmode = jsonStr.resource_name, !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), !1;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/yubikey/self?" + signinParams;
    return isSecondary = allowedmodes.length > 1 && -1 === allowedmodes.indexOf("recoverycode") ? !0 : !1, sendRequestWithTemptoken(loginurl, "", !0, handleYubikeyDetails), signinathmode = "yubikeysecauth", isRecovery || allowedModeChecking(), !1
}

function enableTOTPdevice(resp, isMyZohoApp, isOneAuth) {
    if (isPasswordless ? "" : $(".hellouser").hide(), $("#password_container,#login_id_container,#captcha_container,.fed_2show,#otp_container").hide(), $("#headtitle").text(I18N.get("IAM.NEW.SIGNIN.TOTP")), $(".service_name").text(I18N.get("IAM.NEW.SIGNIN.MFA.TOTP.HEADER")), $(".product_text,.product_head,.MAppIcon,.OnaAuthHLink,.pwless_head,.pwless_text").hide(), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_totp_mode"), $("#forgotpassword").hide(), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEW.SIGNIN.VERIFY")), $("#nextbtn").show(), isMyZohoApp) {
        $(".deviceparent .devicetext").text(devicename), $(".devicedetails .devicetext").text(devicename), $("#mfa_device_container").show(), $(".tryanother").show();
        var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
        isAMFA && (allowedModeChecking(), $(".tryanother").hide()), $(".service_name").text(I18N.get("IAM.NEW.SIGNIN.TOTP.HEADER")), $("#problemsignin,#recoverybtn,.loader,.blur,.deviceparent").hide(), clearCommonError("mfa_totp"), $(".signin_container").removeClass("mobile_signincontainer")
    } else isOneAuth && $(".service_name").text(I18N.get("IAM.NEW.SIGNIN.TOTP.HEADER"));
    $("#mfa_totp").val(""), isClientPortal || enableSplitField("mfa_totp", totp_size, I18N.get("IAM.NEW.SIGNIN.VERIFY.CODE")), $("#mfa_totp_container").show(), isClientPortal ? $("#mfa_totp").focus() : $("#mfa_totp").click(), $(".service_name").addClass("extramargin"), isFormSubmited = !1;
    var mzauth = "primary" === callmode ? "deviceauth" : "devicesecauth";
    return signinathmode = isMyZohoApp ? mzauth : "oneauthsec", isMyZohoApp || isRecovery || allowedModeChecking(), !1
}

function enableOneAuthBackup() {
    changeRecoverOption(allowedmodes[0]), $("#backup_container .backoption,#recovery_passphrase,#recovery_backup").hide(), -1 != allowedmodes.indexOf("passphrase") ? $("#recovery_passphrase").show() : $("#recovery_passphrase").hide(), -1 != allowedmodes.indexOf("recoverycode") ? $("#recovery_backup").show() : $("#recovery_backup").hide()
}

function handleYubikeyDetails(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) return "throttles_limit_exceeded" === jsonStr.cause ? (showCommonError("yubikey", jsonStr.localized_message), $("#yubikey_container").is(":visible") || (showYubikeyDetails(), showError(), $("#yubikey_container").show(), $(".blur,.loader").is(":visible") && $(".blur,.loader").hide()), !1) : (showCommonError("password", jsonStr.localized_message), !1);
        var successCode = jsonStr.code;
        return "SI203" === successCode && ($(".loader,.blur").hide(), $(".waittext").css("waittext", "25px"), showYubikeyDetails(), getAssertion(jsonStr.yubikeysecauth)), !1
    }
    var errorcontainer = "passwordauth" === signinathmode ? "password" : "login_id";
    return showCommonError(errorcontainer, I18N.get(jsonStr.localized_message)), !1
}

function getAssertion(parameters) {
    var requestOptions = {};
    return requestOptions.challenge = strToBin(parameters.challenge), requestOptions.timeout = parameters.timeout, requestOptions.rpId = parameters.rpId, requestOptions.allowCredentials = credentialListConversion(parameters.allowCredentials), "authenticatorSelection" in parameters && (requestOptions.authenticatorSelection = parameters.authenticatorSelection), requestOptions.extensions = {}, "extensions" in parameters && "appid" in parameters.extensions && (requestOptions.extensions.appid = parameters.extensions.appid), navigator.credentials.get({
        publicKey: requestOptions
    }).then(function(assertion) {
        var publicKeyCredential = {};
        "id" in assertion && (publicKeyCredential.id = assertion.id), "type" in assertion && (publicKeyCredential.type = assertion.type), "rawId" in assertion && (publicKeyCredential.rawId = binToStr(assertion.rawId)), assertion.response || (showCommonError("yubikey", formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.InvalidResponse"), accounts_support_contact_email_id)), $("#yubikey_container").show(), showError());
        var _response = assertion.response;
        publicKeyCredential.response = {
            clientDataJSON: binToStr(_response.clientDataJSON),
            authenticatorData: binToStr(_response.authenticatorData),
            signature: binToStr(_response.signature),
            userHandle: binToStr(_response.userHandle)
        };
        var yubikey_sec_data = {};
        yubikey_sec_data.yubikeysecauth = publicKeyCredential, sendRequestWithTemptoken("/signin/v2/secondary/" + zuid + "/yubikey/self?" + signinParams, JSON.stringify(yubikey_sec_data), !0, VerifySuccess, "PUT")
    }).catch(function(err) {
        "NotAllowedError" == err.name ? showCommonError("yubikey", I18N.get("IAM.WEBAUTHN.ERROR.NotAllowedError")) : "InvalidStateError" == err.name ? showCommonError("yubikey", I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.InvalidStateError")) : "AbortError" == err.name ? showCommonError("yubikey", I18N.get("IAM.WEBAUTHN.ERROR.NotAllowedError")) : "UnknownError" == err.name ? showCommonError("yubikey", formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.UnknownError"), accounts_support_contact_email_id)) : showCommonError("yubikey", formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.ErrorOccurred"), accounts_support_contact_email_id) + "<br>" + err.toString()), $("#yubikey_container").show(), showError()
    })
}

function showYubikeyDetails() {
    var headtitle = "IAM.NEW.SIGNIN.YUBIKEY.TITLE",
        headerdesc = isMobile ? "IAM.NEW.SIGNIN.YUBIKEY.HEADER.NEW.FOR.MOBILE" : "IAM.NEW.SIGNIN.YUBIKEY.HEADER.NEW";
    return $("#password_container,#login_id_container,#captcha_container,.fed_2show,#otp_container").hide(), $("#headtitle").text(I18N.get(headtitle)), isRecovery && ($("#headtitle").prepend("<span class='icon-backarrow backoption recbackop'></span>"), $(".recbackop").on("click", function() {
        hideCantAccessDevice(this)
    })), $(".service_name").text(I18N.get(headerdesc)), $(".product_text,.product_head,.MAppIcon,.OnaAuthHLink,.pwless_head,.pwless_text").hide(), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_yubikey_mode"), $("#forgotpassword").hide(), $("#nextbtn").hide(), $(".service_name").addClass("extramargin"), $(".deviceparent").removeClass("hide"), $(".deviceparent").css("display", ""), $("#mfa_device_container,.devicedetails").show(), $(".devices").hide(), $("#waitbtn").show(), $(".loadwithbtn").show(), $(".waitbtn .waittext").text(I18N.get("IAM.NEW.SIGNIN.WAITING.APPROVAL")), $("#waitbtn").attr("disabled", !0), isRecovery || allowedModeChecking(), !1
}

function triggerPostRedirection(url, loginid) {
    if (url) {
        var oldForm = document.getElementById("postredirection");
        oldForm && document.documentElement.removeChild(oldForm);
        var form = document.createElement("form");
        form.setAttribute("id", "postredirection"), form.setAttribute("method", "POST"), form.setAttribute("action", url), form.setAttribute("target", "_self");
        var hiddenField = document.createElement("input"),
            csrfField = document.createElement("input");
        return csrfField.setAttribute("type", "hidden"), csrfField.setAttribute("name", csrfParam), csrfField.setAttribute("value", getCookie(csrfCookieName)), loginid && (hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "LOGIN_ID"), hiddenField.setAttribute("value", loginid)), form.appendChild(hiddenField), form.appendChild(csrfField), document.documentElement.appendChild(form), form.submit(), !1
    }
    return !1
}

function handleLookupDetails(resp, isExtUserVerified, ispasskeyfailed) {
    if ($(".blur,.loader").is(":visible") && $(".blur,.loader").hide(), $("#problemsigninui").is(":visible") && ispasskeyfailed) return isPasswordless = !1, showmoresigininoption(), !1;
    if (!IsJsonString(resp)) return callback_signin_lookup(I18N.get("IAM.ERROR.GENERAL")), !1;
    var jsonStr = JSON.parse(resp),
        statusCode = jsonStr.status_code;
    if ("U300" === jsonStr.code) return isValid(jsonStr.lookup.signup_url) && triggerPostRedirection(jsonStr.lookup.signup_url, jsonStr.lookup.loginid), !1;
    if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
        if ($(".fed_2show,.line,#signuplink,.banner_newtoold,#signuplink,#forgotpassword").hide(), $("#smartsigninbtn").addClass("hide"), digest = jsonStr[signinathmode].digest, zuid = jsonStr[signinathmode].identifier, isPhoneNumber(de("login_id").value) && $("#login_id").val($("#country_code_select").val().split("+")[1] + "-" + $("#login_id").val().trim()), deviceauthdetails = jsonStr, isExtUserVerified)
        else if (jsonStr[signinathmode].ext_usr) {
            $("#forgotpassword,#nextbtn").hide();
            var loginId = jsonStr[signinathmode].loginid ? jsonStr[signinathmode].loginid : de("login_id").value;
            return $("#login_id_container,#showIDPs").slideUp(200), $("#password_container").removeClass("zeroheight"), $("#password_container").slideDown(200), $(".username").text(identifyEmailOrNum()), $("#password_container .textbox_div").hide(), $(".externaluser_container").html(jsonStr[signinathmode].ext_msg), $(".externaluser_container,#continuebtn").show(), !1
        }
        if (adminEmail = jsonStr[signinathmode].admin, contactAdminHelpdoc = jsonStr[signinathmode].doc_link, identifyEmailOrNum(jsonStr[signinathmode].loginid ? jsonStr[signinathmode].loginid : de("login_id").value), $(".username").text(identifyEmailOrNum()), isEmpty(jsonStr[signinathmode].modes) || !isValid(jsonStr[signinathmode].modes) || ispasskeyfailed && 1 == jsonStr[signinathmode].modes.allowed_modes.length && -1 != jsonStr[signinathmode].modes.allowed_modes.indexOf("passkey")) {
            changeButtonAction(I18N.get("IAM.SIGN_IN"), !1), $("#forgotpassword").hide();
            var loginId = jsonStr[signinathmode].loginid ? jsonStr[signinathmode].loginid : de("login_id").value;
            return $("#login_id_container,#showIDPs").slideUp(200), $("#password_container").removeClass("zeroheight"), $("#password_container").slideDown(200), identifyEmailOrNum(loginId), $(".username").text(identifyEmailOrNum()), $("#password_container .textbox_div,#nextbtn").hide(), window.setTimeout(function() {
                enableNoPassPopup()
            }, 200), $("#captcha_container").hide(), !1
        }
        deviceauthdetails.lookup.showNotePasswordLessEnforced && showHideEnforcePop(!0), isPrimaryMode = !0, allowedmodes = jsonStr[signinathmode].modes.allowed_modes, prev_showmode = allowedmodes[0], $(".otp_actions .signinwithjwt,.otp_actions .signinwithsaml,.otp_actions .showmoresigininoption").hide();
        var identifiers = getIdentifierDetails(),
            lmp = !isClientPortal && "undefined" != typeof isParamLoginID && isParamLoginID;
        if (ispasskeyfailed && (allowedmodes.splice(allowedmodes.indexOf("passkey"), 1), isPasswordless = !1), isEmailVerifyReqiured = jsonStr[signinathmode].isUserName && -1 != allowedmodes.indexOf("email") ? !0 : !1, "passkey" === allowedmodes[0]) return enablePassKey(), !1;
        if ("password" === allowedmodes[0] || "ldap" === allowedmodes[0]) return signinathmode = "passwordauth", "ldap" === allowedmodes[0] && ($("#password").attr("placeholder", I18N.get("IAM.LDAP.PASSWORD.PLACEHOLDER")), $(".blueforgotpassword").hide(), signinathmode = "ldappasswordauth"), prev_showmode = allowedmodes[0], enableOptionsAsPrimary(allowedmodes[0]), enableFieldFirstFactor(), $("#password").focus(), !1;
        if ("federated" === allowedmodes[0]) return $("#password_container").show(), $("#login_id_container .textbox_div,#password_container .textbox_div,#nextbtn").hide(), $("#captcha_container,.line").hide(), enableOptionsAsPrimary(allowedmodes[0]), !1;
        if ("otp" === allowedmodes[0] || "email" === allowedmodes[0]) return emobile = "otp" === allowedmodes[0] ? jsonStr[signinathmode].modes.otp.data[0].e_mobile : jsonStr[signinathmode].modes.email.data[0].e_email, rmobile = "otp" === allowedmodes[0] ? identifyEmailOrNum(jsonStr[signinathmode].modes.otp.data[0].r_mobile, !0) : jsonStr[signinathmode].modes.email.data[0].email, $("#signinwithpass").hide(), enableOTP(allowedmodes[0]), enableOptionsAsPrimary(allowedmodes[0]), enableFieldFirstFactor(), !1;
        if ("totp" === allowedmodes[0]) return enableFieldFirstFactor(), enableTotpAsPrimary(), !1;
        if ("mzadevice" === allowedmodes[0]) {
            isPasswordless = !0, secondarymodes = allowedmodes;
            var secondary_modes = jsonStr[signinathmode].secondary_modes && jsonStr[signinathmode].secondary_modes.allowed_modes;
            return recoverymodes = secondary_modes, secondarymodes.push.apply(secondarymodes, secondary_modes), mzadevicepos = 0, handleSecondaryDevices(allowedmodes[0]), enableMyZohoDevice(jsonStr), !1
        }
        if ("saml" === allowedmodes[0]) {
            var isMoreSaml = jsonStr[signinathmode].modes.saml.count > 1;
            return isMoreSaml || allowedmodes.length > 1 || jsonStr[signinathmode].show_setpassword || identifiers.count > 1 ? showSigninFedOptionalone(loginId) : lmp ? handleOpenRedirection(jsonStr[signinathmode].modes.saml.data[0], "saml") : redirectToSaml(jsonStr[signinathmode].modes.saml.data[0]), !1
        }
        if ("jwt" === allowedmodes[0]) {
            var isMoreJwt = jsonStr[signinathmode].modes.jwt.count > 1;
            return isMoreJwt || allowedmodes.length > 1 || jsonStr[signinathmode].show_setpassword || identifiers.count > 1 ? showSigninFedOptionalone(loginId) : lmp ? handleOpenRedirection(jsonStr[signinathmode].modes.jwt.data[0], "jwt") : switchto(jsonStr[signinathmode].modes.jwt.data[0].redirect_uri), !1
        }
        if ("oidc" === allowedmodes[0]) {
            var isMoreOidc = jsonStr[signinathmode].modes.oidc.count > 1;
            return isMoreOidc || jsonStr[signinathmode].show_setpassword || identifiers.count > 1 ? showSigninFedOptionalone(loginId) : lmp ? handleOpenRedirection(jsonStr[signinathmode].modes.oidc.data[0], "oidc") : enableOIDCAuth(), !1
        }
    } else {
        if ("throttles_limit_exceeded" === jsonStr.cause) return callback_signin_lookup(jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors[0],
            errorCode = error_resp.code,
            errorMessage = jsonStr.localized_message;
        if ("U400" === errorCode || "U301" === errorCode) {
            var loginid = jsonStr.data.loginid;
            if (loginid && (isEmailIdSignin(loginid) || isUserName(loginid)) || isPhoneNumber(loginid.split("-")[1])) {
                var deploymentUrl = jsonStr.data.redirect_uri,
                    signinParams = removeParamFromQueryString("LOGIN_ID"),
                    loginurl = deploymentUrl + (-1 != deploymentUrl.indexOf("?") ? "&" : "?") + signinParams;
                return triggerPostRedirection(loginurl, loginid), !1
            }
            return !1
        }
        if ("EMAIL509" === errorCode) errorMessage = formatMessage(I18N.get("IAM.ERROR.PORTAL.UNCONFIRMED.USER"), supportEmailAddress), showCommonError("login_id", errorMessage);
        else {
            if ("U201" === errorCode) return switchto(error_resp.redirect_uri), !1;
            if ("IN107" === errorCode || "IN108" === errorCode) return isSignupCaptcha = jsonStr.isSignupCaptcha, cdigest = isSignupCaptcha ? jsonStr.data.cdigest : jsonStr.cdigest, showHip(cdigest), showCaptcha(I18N.get("IAM.NEXT"), !1, "login_id"), "IN107" === errorCode && showCommonError("captcha", errorMessage), !1;
            if ("U401" === errorCode) return callback_signin_lookup(errorMessage), $("#i18nsignup").css({
                color: "#309FF4",
                display: "inline",
                cursor: "pointer"
            }), $("#i18nsignup").on("click", function() {
                iamMovetoSignUp($(this).attr("data-link"), $(this).attr("data-id"))
            }), isShowFedOptions && (isMobile || $(".line").show(), fediconsChecking()), !1;
            if ("R303" === errorCode) return showRestrictsignin(), !1;
            if ("U404" !== errorCode && "RIP104" !== errorCode || "undefined" == typeof canShowResetIP || "true" != canShowResetIP) {
                if ("DOMAIN500" !== errorCode) return callback_signin_lookup(errorMessage), !1;
                $("#signin_div, #signuplink, .smartsigninbutton").hide(), $(".zoho_logo").addClass("logoCentre"), $("#domain_error").show(), $(".domain_err_heading").text(I18N.get("IAM.NEW.SIGNIN.RESTRICT.SIGNIN.HEADER")), $(".domain_err_content").text(errorMessage), $(".domain_err_info").text(I18N.get("IAM.DOMAIN.WAIT.WARNING")), $(".domain_refresh").text(I18N.get("IAM.REFRESH")), $(".domain_refresh").on("click", function() {
                    location.reload()
                })
            } else {
                hiderightpanel(), $("#login,.fed_2show,.line, .ip_orgDiv").hide();
                var LOGIN_ID = de("login_id").value.trim();
                LOGIN_ID = isPhoneNumber(LOGIN_ID) ? $("#country_code_select").val().split("+")[1] + "-" + LOGIN_ID : LOGIN_ID, $(".resetIP_container .username").text(identifyEmailOrNum(LOGIN_ID));
                var IP = void 0 != jsonStr.currentIp ? jsonStr.currentIp : currentIP;
                $("#ip_desc").html(formatMessage(I18N.get("IAM.SIGNIN.ERROR.USER.NOT.ALLOWED.IP.RESETOPTION"), IP, ipRestrictionLearn)), $(".resetIP_container,#goto_resetIP").show(), $(".zoho_logo").addClass("applycenter"), 1 == $("#smartsigninbtn").length && $("#smartsigninbtn").addClass("hide"), $("#signuplink").hide(), "RIP104" === errorCode && ($("#goto_resetIP").hide(), $(".ip_orgDiv").css("display", "flex"), $(".ip_orgAdminEmail").text(jsonStr.adminEmail))
            }
        }
    }
    return !1
}

function redirectToSaml(samlData) {
    var redirect_uri = samlData.redirect_uri;
    if (1 == samlData.method && isValid(redirect_uri) && isValid(samlData.RelayState) && isValid(samlData.SAMLRequest)) {
        var form = document.createElement("form");
        form.setAttribute("id", "samlform"), form.setAttribute("method", "POST"), form.setAttribute("action", samlData.redirect_uri), form.setAttribute("target", "_self");
        var RelayState = document.createElement("input"),
            SAMLRequest = document.createElement("input");
        return RelayState.setAttribute("type", "hidden"), RelayState.setAttribute("name", "RelayState"), RelayState.setAttribute("value", samlData.RelayState), SAMLRequest.setAttribute("type", "hidden"), SAMLRequest.setAttribute("name", "SAMLRequest"), SAMLRequest.setAttribute("value", samlData.SAMLRequest), form.appendChild(RelayState), form.appendChild(SAMLRequest), document.documentElement.appendChild(form), form.submit(), !1
    }
    isValid(redirect_uri) ? switchto(redirect_uri) : enableSamlAuth(samlData.auth_domain)
}

function showSigninFedOptionalone(loginId) {
    $("#login_id_container,#showIDPs").slideUp(200), identifyEmailOrNum(loginId), $(".username").text(identifyEmailOrNum()), $("#captcha_container,.line").hide(), $("#password_container").removeClass("zeroheight"), $("#password_container").slideDown(200), $("#forgotpassword").hide(), $("#password_container .textbox_div,#nextbtn").hide(), showSigninUsingFedOption(), enableNoPassPopup()
}

function showHideEnforcePop(needtoshow) {
    var boxheight = bottomheight = elemdisplay = "";
    needtoshow && (boxheight = $(".signin_box").outerHeight() + $("#device_box_info").outerHeight() + "px", bottomheight = $("#device_box_info").outerHeight() + parseInt($(".tryanother").css("bottom")) + "px", elemdisplay = "flex"), $("#device_box_info").css("display", elemdisplay), $(".signin_box").css("height", boxheight), $(".tryanother").css("bottom", bottomheight)
}

function enableNoPassPopup(captcha) {
    var show_setpassword = deviceauthdetails[deviceauthdetails.resource_name].show_setpassword;
    "undefined" != typeof show_setpassword && show_setpassword && ($(".nopassword_container").css("position", "absolute"), $(".nopassword_container").show(), "undefined" != typeof allowedmodes && (-1 != allowedmodes.indexOf("otp") || -1 != allowedmodes.indexOf("email") || -1 != allowedmodes.indexOf("password")) && getIdentifierDetails().count > 0 ? $(".signin_box").css("height", $(".signin_box").outerHeight() + $(".nopassword_container").outerHeight() + "px") : $(".signin_box").css("height", "580px"), captcha && $(".signin_box").css("height", $(".signin_box").outerHeight() + $(".nopassword_container").outerHeight() + "px"))
}

function enablePassKey() {
    return isWebAuthNSupported() ? (isPasswordless = !0, $(".loader,.blur").show(), enableWebauthnDevice(), !1) : (showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), changeButtonAction(I18N.get("IAM.NEXT"), !1), !1)
}

function enableOptionsAsPrimary(mode) {
    $("#password_container").removeClass("zeroheight"), $(".username").text(identifyEmailOrNum()), $(".otp_actions,.enableotpoption").hide();
    var fallBackToShow = validateAllowedMode(mode);
    return fallBackToShow.enableMore ? isClientPortal ? enableFallBackPortal(mode) : ($("#enablemore").show(), $("#enableforgot").hide(), $(".showmoresigininoption").show(), "password" == mode || "ldap" == mode ? ("ldap" == mode ? $(".blueforgotpassword").hide() : $(".blueforgotpassword").show(), $(".resendotp").hide()) : ("email" == mode || "otp" == mode) && ($(".blueforgotpassword").hide(), $(".resendotp").show())) : fallBackToShow.nootheroption ? ($("#enablemore").hide(), $("#enableforgot").show()) : fallBackForSingleMode(mode, fallBackToShow.option), showIdentifiers(), window.setTimeout(function() {
        enableNoPassPopup()
    }, 200), !1
}

function enableFieldFirstFactor() {
    return changeButtonAction(I18N.get("IAM.SIGN_IN"), !1), $("#login_id_container,#showIDPs").slideUp(200), $("#password_container").removeClass("zeroheight"), $("#password_container").slideDown(200), $(".backbtn").show(), $("#captcha_container,.line").hide(), $(".username").text(identifyEmailOrNum()).css("font-weight", "500").css("color", "#000"), $("#passwordcontainer .hellouser").show().css("display", "flex").css("align-items", "center").css("justify-content", "space-between"),
        $("#passwordcontainer .Notyou").show().css("display", "inline-block"), !1
}

function enableTotpAsPrimary() {
    if (signinathmode = "totpauth", $("#password_container .textbox_div,#captcha_container,#otp_container,#problemsigninui, #problemsignin_container").hide(), $("#forgotpassword").hide(), $("#mfa_totp_container").show(), $("#nextbtn span").removeClass("zeroheight"), $("#password_container").addClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEW.SIGNIN.VERIFY")), $("#login .signin_head,#nextbtn").show(), $(".resendotp,.blueforgotpassword").hide(), isClientPortal ? $("#mfa_totp").focus() : (enableSplitField("mfa_totp", totp_size, I18N.get("IAM.NEW.SIGNIN.VERIFY.CODE")), $("#mfa_totp").click()), isPasswordless) {
        "undefined" != typeof oaNotInstalled && oaNotInstalled && $(".service_name").html(I18N.get("IAM.NEW.SIGNIN.MFA.TOTP.HEADER")), $("#enableotpoption,#enablesaml,#enablejwt,#enablemore .resendotp,#enableoptionsoneauth,#signinwithpassoneauth").hide();
        var showingmodes = secondarymodes;
        3 == showingmodes.length ? -1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enableotpoption").show() : -1 != showingmodes.indexOf("ldap") ? $("#enableldap").show() : "" : showingmodes.length > 2 && $("#enablemore").show()
    } else $(".fed_2show").hide(), fallBackForSingleMode("totp", validateAllowedMode("totp").option);
    return !1
}

function showPrimaryTotp() {
    return enableTotpAsPrimary(), prev_showmode = "totp", !1
}

function fallBackForSingleMode(mode, fallBackOption) {
    if (mode == fallBackOption) return !1;
    if (isClientPortal) return enableFallBackPortal(mode), !1;
    deviceauthdetails[deviceauthdetails.resource_name].modes;
    return $(".otp_actions,#enableotpoption").hide(), $("#enablemore").show(), $(".showmoresigininoption").off("click"), "password" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.PASSWORD")), $(".showmoresigininoption").on("click", function() {
        showPassword()
    })) : "otp" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.MOBILE.OTP")), $(".showmoresigininoption").on("click", function() {
        showAndGenerateOtp(fallBackOption)
    })) : "email" == fallBackOption ? (isEmailVerifyReqiured = deviceauthdetails[deviceauthdetails.resource_name].isUserName ? !0 : !1, $(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.EMAIL.OTP")), $(".showmoresigininoption").on("click", function() {
        showAndGenerateOtp(fallBackOption)
    })) : "passkey" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.PASSKEY")), $(".showmoresigininoption").on("click", function() {
        enablePassKey()
    })) : "totp" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.ENTER.TOTP.FIRST.FACTOR")), $(".showmoresigininoption").on("click", function() {
        enableTotpAsPrimary()
    })) : "mzadevice" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.ONEAUTH.FIRST.FACTOR")), $(".showmoresigininoption").on("click", function() {
        enableMyZohoAsPrimary()
    })) : "ldap" == fallBackOption ? ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.USING.LDAP.PASSWORD")), $(".showmoresigininoption").on("click", function() {
        showPassword(!0)
    })) : ($(".showmoresigininoption").html(I18N.get("IAM.NEW.SIGNIN.TRY.ANOTHERWAY")), $(".showmoresigininoption").click(function() {
        return $(this).hasClass("getbackemailverify") ? (showmoresigininoption("getbackemailverify"), !1) : void showmoresigininoption()
    })), "password" == mode || "ldap" == mode ? ("password" == mode ? $(".blueforgotpassword").show() : ($(".blueforgotpassword").hide(), $("#password").attr("placeholder", I18N.get("IAM.LDAP.PASSWORD.PLACEHOLDER"))), $(".resendotp").hide()) : ("otp" == mode || "email" == mode) && ($(".blueforgotpassword").hide(), $(".resendotp").show()), !1
}

function enableFallBackPortal(mode) {
    return "password" == mode ? ($(".textbox_actions,#enableforgot,#enableotpoption,#signinwithotp").hide(), -1 != allowedmodes.indexOf("otp") ? ($("#signinwithotp").html(I18N.get("IAM.NEW.SIGNIN.USING.MOBILE.OTP")), $("#signinwithotp").off("click"), $("#signinwithotp").on("click", function() {
        showAndGenerateOtp("otp")
    }), $("#enableotpoption,#signinwithotp").show()) : -1 != allowedmodes.indexOf("email") ? ($("#signinwithotp").html(I18N.get("IAM.NEW.SIGNIN.USING.EMAIL.OTP")), $("#signinwithotp").off("click"), $("#signinwithotp").on("click", function() {
        showAndGenerateOtp("email")
    }), $("#enableotpoption,#signinwithotp").show()) : $("#enableforgot").show()) : ("otp" == mode || "email" == mode) && ($(".textbox_actions,#signinwithpass,.resendotp").hide(), -1 != allowedmodes.indexOf("password") ? $(".textbox_actions,#signinwithpass,.resendotp").show() : $(".textbox_actions,.resendotp").show()), !1
}

function getIdentifierDetails() {
    var userIdentifiers = {
        saml: !1,
        jwt: !1,
        federated: !1,
        oidc: !1,
        count: 0
    };
    return allowedmodes.forEach(function(mode) {
        ("jwt" == mode || "saml" == mode || "federated" == mode || "oidc" == mode) && (userIdentifiers[mode] = !0, userIdentifiers.count = userIdentifiers.count + 1)
    }), userIdentifiers
}

function showIdentifiers() {
    var identifiers = getIdentifierDetails();
    if (identifiers.count < 1) return !1;
    var autheticationmodes = deviceauthdetails[deviceauthdetails.resource_name].modes;
    if ($(".fed_2show").show(), $(".large_box").removeClass("large_box"), $(".fed_div").addClass("small_box"), $(".fed_div, .fed_text").hide(), $(".googleIcon").removeClass("google_small_icon"), document.getElementById("fed_signin_options").innerHTML = "", identifiers.oidc)
        if (autheticationmodes.oidc && autheticationmodes.oidc.count > 1)
            for (var oidcCount = autheticationmodes.oidc.count, i = 0; oidcCount > i; i++) appendOIDC(i);
        else appendOIDC(0);
    if (1 == identifiers.saml)
        if (autheticationmodes.saml && autheticationmodes.saml.count > 1)
            for (var samlCount = autheticationmodes.saml.count, i = 0; samlCount > i; i++) appendSAML(i);
        else appendSAML(0);
    if (identifiers.jwt)
        if (autheticationmodes.jwt && autheticationmodes.jwt.count > 1)
            for (var jwtCount = autheticationmodes.jwt.count, i = 0; jwtCount > i; i++) appendJWT(i);
        else appendJWT(0);
    if (identifiers.federated) {
        var idps = deviceauthdetails.lookup.modes.federated.data;
        idps.forEach(function(idps) {
            isValid(idps) && (idp = idps.idp.toLowerCase(), $("." + idp + "_fed").attr("style", "display:block !important"))
        }), $(".apple_fed").is(":visible") && (isneedforGverify ? $("#macappleicon").hide() : ($(".apple_fed").hide(), $("#macappleicon").show(), $(".googleIcon").addClass("google_small_icon"))), isneedforGverify ? $(".google_icon .fed_text").show() : $(".google_icon .fed_text").hide()
    }
}

function enableMyZohoAsPrimary() {
    isPasswordless = !0, secondarymodes = allowedmodes;
    var secondary_modes = jsonStr[signinathmode].secondary_modes && jsonStr[signinathmode].secondary_modes.allowed_modes;
    return recoverymodes = secondary_modes, secondarymodes.push.apply(secondarymodes, secondary_modes), handleSecondaryDevices(allowedmodes[0]), enableMyZohoDevice(jsonStr), !1
}

function enableWebauthnDevice() {
    if (!isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), !1;
    var loginurl = uriPrefix + "/signin/v2/primary/" + zuid + "/passkey/self?";
    return loginurl += "digest=" + digest + "&" + signinParams, sendRequestWithCallback(loginurl, "", !0, handleWebauthnDevice), !1
}

function handleWebauthnDevice(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
            if ("throttles_limit_exceeded" === jsonStr.cause) {
                var errorMsg = I18N.get(1 == allowedmodes.length && "passkey" == allowedmodes[0] ? "IAM.NEW.SIGNIN.PASSKEY.THROTTLE.ERROR.MSG.SINGLE.MODE" : "IAM.NEW.SIGNIN.PASSKEY.THROTTLE.ERROR.MSG");
                return isPrimaryMode && !$("#yubikey_container").is(":visible") ? (showTopErrNotification(errorMsg, "", 7e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0), !1) : (showCommonError("yubikey", jsonStr.localized_message), !1)
            }
            return showCommonError("password", jsonStr.localized_message), !1
        }
        var successCode = jsonStr.code;
        return "SI203" === successCode && getAssertionLookup(jsonStr.passkeyauth), !1
    }
    var errorcontainer = "passwordauth" === signinathmode ? "password" : "login_id";
    return showCommonError(errorcontainer, I18N.get(jsonStr.localized_message)), !1
}

function getAssertionLookup(parameters) {
    var requestOptions = {};
    return requestOptions.challenge = strToBin(parameters.challenge), requestOptions.timeout = parameters.timeout, requestOptions.rpId = parameters.rpId, requestOptions.allowCredentials = credentialListConversion(parameters.allowCredentials), "authenticatorSelection" in parameters && (requestOptions.authenticatorSelection = parameters.authenticatorSelection), requestOptions.extensions = {}, "extensions" in parameters && "appid" in parameters.extensions && (requestOptions.extensions.appid = parameters.extensions.appid), navigator.credentials.get({
        publicKey: requestOptions
    }).then(function(assertion) {
        var publicKeyCredential = {};
        "id" in assertion && (publicKeyCredential.id = assertion.id), "type" in assertion && (publicKeyCredential.type = assertion.type), "rawId" in assertion && (publicKeyCredential.rawId = binToStr(assertion.rawId)), assertion.response || (showTopErrNotification(formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.PASSKEY.InvalidResponse"), accounts_support_contact_email_id), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0));
        var _response = assertion.response;
        publicKeyCredential.response = {
            clientDataJSON: binToStr(_response.clientDataJSON),
            authenticatorData: binToStr(_response.authenticatorData),
            signature: binToStr(_response.signature),
            userHandle: binToStr(_response.userHandle)
        };
        var passkey_data = {};
        passkey_data.passkeyauth = publicKeyCredential, sendRequestWithTemptoken("/signin/v2/primary/" + zuid + "/passkey/self?digest=" + digest + "&" + signinParams, JSON.stringify(passkey_data), !0, VerifySuccess, "PUT")
    }).catch(function(err) {
        "NotAllowedError" == err.name ? (showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.NotAllowedError"), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0)) : "InvalidStateError" == err.name ? (showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.PASSKEY.InvalidStateError"), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0)) : "AbortError" == err.name ? (showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.NotAllowedError"), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0)) : "TypeError" == err.name ? (showTopErrNotificationStatic(I18N.get("IAM.WEBAUTHN.ERROR.TYPE.ERROR"), formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.HELP.HOWTO"), passkeyURL), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0)) : (showTopErrNotification(formatMessage(I18N.get("IAM.WEBAUTHN.ERROR.AUTHENTICATION.PASSKEY.ErrorOccurred"), accounts_support_contact_email_id) + "<br>" + err.toString(), "", 3e3), signinathmode = "lookup", handleLookupDetails(JSON.stringify(deviceauthdetails), !1, !0))
    })
}

function showmoresigininoption(isMoreSaml) {
    if (isPasswordless) return $("#password").is(":visible") && (prev_showmode = isLdapVisible ? "ldap" : "password"), $("#enableoptionsoneauth").is(":visible") ? $("#enableoptionsoneauth").hide() : $("#enableoptionsoneauth").show(), -1 != allowedmodes.indexOf("password") && "password" != prev_showmode ? $("#signinwithpassoneauth").css("display", "block") : $("#signinwithpassoneauth").hide(), -1 != allowedmodes.indexOf("ldap") && "ldap" != prev_showmode ? $("#signinwithldaponeauth").css("display", "block") : $("#signinwithldaponeauth").hide(), -1 != allowedmodes.indexOf("otp") && "otp" != prev_showmode ? $("#signinwithotponeauth").css("display", "block") : $("#signinwithotponeauth").hide(), -1 != allowedmodes.indexOf("email") && "email" != prev_showmode ? $("#passlessemailverify").css("display", "block") : $("#passlessemailverify").hide(), -1 != allowedmodes.indexOf("totp") && "totp" != prev_showmode ? $("#signinwithtotponeauth").css("display", "block") : $("#signinwithtotponeauth").hide(), -1 != allowedmodes.indexOf("otp") ? $("#signinwithotponeauth").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.PASSWORDLESS.OTP.VERIFY.TITLE"), identifyEmailOrNum(deviceauthdetails[deviceauthdetails.resource_name].modes.otp.data[0].r_mobile, !0))) : "", -1 != allowedmodes.indexOf("email") ? $("#passlessemailverify").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.PASSWORDLESS.EMAIL.VERIFY.TITLE"), deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].email)) : "", $("#enableoptionsoneauth").is(":visible") && setTimeout(function() {
        document.getElementsByClassName("signin_container")[0].addEventListener("click", function hideandforgetEnableoption() {
            $("#enableoptionsoneauth").hide(), document.getElementsByClassName("signin_container")[0].removeEventListener("click", hideandforgetEnableoption)
        })
    }, 10), !1;
    $("#enablemore").hide(), isMoreSaml || (allowedmodes.splice(allowedmodes.indexOf(prev_showmode), 1), allowedmodes.unshift(prev_showmode)), $("#emailverify_container,#mfa_totp_container").hide(), $("#login").show();
    var problemsignin_con = "",
        i18n_msg = {
            otp: ["IAM.NEW.SIGNIN.OTP.TITLE", "IAM.NEW.SIGNIN.OTP.HEADER"],
            saml: ["IAM.NEW.SIGNIN.SAML.TITLE", "IAM.NEW.SIGNIN.SAML.HEADER"],
            password: ["IAM.NEW.SIGNIN.PASSWORD.TITLE", "IAM.NEW.SIGNIN.PASSWORD.HEADER"],
            jwt: ["IAM.NEW.SIGNIN.JWT.TITLE", "IAM.NEW.SIGNIN.SAML.HEADER"],
            email: ["IAM.NEW.SIGNIN.EMAIL.TITLE", "IAM.NEW.SIGNIN.OTP.HEADER"],
            ldap: ["IAM.NEW.SIGNIN.WITH.LDAP", "IAM.NEW.SIGNIN.LDAP.HEADER"],
            totp: ["IAM.NEW.SIGNIN.VERIFY.VIA.AUTHENTICATOR", "IAM.NEW.SIGNIN.VERIFY.VIA.AUTHENTICATOR.DESC"]
        },
        problemsigninheader = "<div class='problemsignin_head'><span class='icon-backarrow backoption problemsigninback'></span>" + I18N.get("IAM.NEW.SIGNIN.TRY.ANOTHERWAY") + "</div>";
    return allowedmodes.forEach(function(prob_mode, position) {
        if (0 != position || isMoreSaml) {
            var saml_position, secondary_header = i18n_msg[prob_mode] ? I18N.get(i18n_msg[prob_mode][0]) : "",
                secondary_desc = i18n_msg[prob_mode] ? I18N.get(i18n_msg[prob_mode][1]) : "";
            if ("otp" === prob_mode) {
                var tempRmobile = identifyEmailOrNum(deviceauthdetails.lookup.modes.otp.data[0].r_mobile, !0);
                secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile), problemsignin_con += createSigninMoreOptions(prob_mode, saml_position, secondary_header, secondary_desc)
            } else if ("email" === prob_mode) {
                var tempRmobile = deviceauthdetails.lookup.modes.email.data[0].email;
                secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile), problemsignin_con += createSigninMoreOptions(prob_mode, saml_position, secondary_header, secondary_desc)
            } else "federated" != prob_mode && "saml" != prob_mode && "oidc" != prob_mode && "jwt" != prob_mode && (problemsignin_con += createSigninMoreOptions(prob_mode, saml_position, secondary_header, secondary_desc))
        }
    }), $("#problemsigninui").html(problemsigninheader + "<div class='problemsignincon'>" + problemsignin_con + "</div>"), $("#password_container,#nextbtn,.signin_head,#otp_container,#captcha_container,.fed_2show").hide(), $("#problemsigninui, #problemsignin_container").show(), $(".problemsigninback").on("click", function() {
        "getbackemailverify" === isMoreSaml ? getbackemailverify() : hideSigninOptions()
    }), $(".showallowedmodeselem").on("click", function() {
        showallowedmodes($(this).attr("mode"), parseInt($(this).attr("index")))
    }), !1
}

function createSigninMoreOptions(prob_mode, saml_position, secondary_header, secondary_desc) {
    var prefer_icon = prob_mode,
        secondary_con = "<div class='optionstry options_hover showallowedmodeselem' id='secondary_" + prob_mode + "' mode=" + prob_mode + " index=" + saml_position + ">							<div class='img_option_try img_option icon-" + prefer_icon + "'></div>							<div class='option_details_try decreasewidth'>								<div class='option_title_try'>" + secondary_header + "</div>								<div class='option_description'>" + secondary_desc + "</div>							</div>						</div>";
    return secondary_con
}

function handlePasswordDetails(resp, allowmodelist) {
    if (!IsJsonString(resp)) {
        var errorfield = $("#emailverify").is(":visible") ? "emailverify" : "otpauth" === signinathmode ? "otp" : "password";
        return showCommonError(errorfield, I18N.get("IAM.ERROR.GENERAL")), !1
    }
    var jsonStr = JSON.parse(resp);
    signinathmode = jsonStr.resource_name;
    var statusCode = jsonStr.status_code;
    if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
        var errorfield = $("#emailverify").is(":visible") ? "emailverify" : "otpauth" === signinathmode ? "otp" : "totpauth" == signinathmode ? "mfa_totp" : "password";
        if ("throttles_limit_exceeded" === jsonStr.cause) return clearInterval(resendTimer), hideResendOTP(), showCommonError(errorfield, jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors[0],
            errorCode = error_resp.code,
            errorMessage = jsonStr.localized_message;
        return isClientPortal || $(".signin_box").css("height", "580px"), "IN107" === errorCode || "IN108" === errorCode ? (cdigest = jsonStr.cdigest, showHip(cdigest), showCaptcha(I18N.get("IAM.NEXT"), !1, "password"), deviceauthdetails[deviceauthdetails.resource_name].show_setpassword && enableNoPassPopup(!0), "IN107" === errorCode && showCommonError("captcha", errorMessage), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : (showCommonError(errorfield, errorMessage), !1)
    }
    zuid = zuid ? zuid : jsonStr[signinathmode].identifier, restrictTrustMfa = jsonStr[signinathmode].restrict_trust_mfa || jsonStr[signinathmode].isAMFA, void 0 === adminEmail && (adminEmail = jsonStr[signinathmode].admin), "undefined" == typeof adminEmail || jsonStr[signinathmode].isAMFA || ($(".contact_support .option_title").html(I18N.get("IAM.NEW.SIGNIN.CONTACT.ADMIN.TITLE")), $(".contact_support .contactsuprt").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.CONTACT.ADMIN.DESC"), adminEmail, contactAdminHelpdoc)), isClientPortal && $(".contact_support .contactsuprt a").hide()), restrictTrustMfa || (trustMfaDays = "" + jsonStr[signinathmode].trust_mfa_days), $(".overlapBanner,.dotHead,#emailverify_container").hide(), $(".mfa_panel,#login").show();
    var successCode = jsonStr.code;
    if ($(".nopassword_container").hide(), $(".signin_box").css("height", ""), jsonStr[signinathmode].isAMFA && ($("#problemsignin").text(I18N.get("IAM.SIGNIN.VIEW.OTHER.OPTION")), $("#recoverybtn").text(I18N.get("IAM.NEW.SIGNIN.PROBLEM.SIGNIN"))), "SI302" === successCode || "SI200" === successCode || "SI300" === successCode || "SI301" === successCode || "SI303" === successCode || "SI305" === successCode || "SI507" === successCode || "SI509" === successCode || "SI506" === successCode) return switchto(jsonStr[signinathmode].redirect_uri), !1;
    if ("P500" === successCode || "P501" === successCode || "P506" === successCode) return temptoken = jsonStr[signinathmode].token, showPasswordExpiry(jsonStr[signinathmode].pwdpolicy, successCode), $(".hellouser").hide(), !1;
    if ("MFA302" === successCode) {
        if ($(".resendotp").removeClass("bluetext_action_right"), $("#enablemore").hide(), $("#mfa_totp_container, .hellouser").hide(), isValid(digest) || (digest = jsonStr[signinathmode].digest), allowedmodes = "undefined" != typeof allowmodelist ? allowmodelist : jsonStr[signinathmode].modes.allowed_modes, void 0 != allowedmodes && -1 != allowedmodes.indexOf("yubikey") && !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), changeButtonAction(I18N.get("IAM.NEXT"), !1), !1;
        if (allowedmodes.length < 1) return oaNotInstalled ? showContactSupport() : showCantAccessDevice(), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_ga_mode"), $("#recovery_container .backoption").hide(), !1;
        if (isPrimaryMode = !1, deviceauthdetails = jsonStr, isSecondary = allowedmodes.length > 1 && -1 === allowedmodes.indexOf("recoverycode") ? !0 : !1, temptoken = jsonStr[signinathmode].token, secondarymodes = allowedmodes, prev_showmode = allowedmodes[0], handleSecondaryDevices(prev_showmode), jsonStr[signinathmode].isAMFA && ($(".fed_2show").hide(), allowedmodes.length > 1)) return callmode = "secondary", showproblemsignin(!1, !0), $(".problemsignin_head .backoption").hide(), !1;
        if (isPasswordless) {
            if (isPasswordless = !1, "undefined" == typeof allowmodelist && (secondarymodes.splice(secondarymodes.indexOf(prev_showmode), 1), secondarymodes.unshift(prev_showmode)), $(".backupstep span").text("2"), $(".backupstep").show(), allowedmodes.length > 1) return callmode = "secondary", showMoreSigninOptions(!0), oaNotInstalled && ($(".rec_head_text").html(I18N.get("IAM.NEW.SIGNIN.FEDERATED.LOGIN.TITLE")), $(".recoveryhead").css("margin-bottom", "10px")), !1;
            $("#backup_title").hide()
        }
        return "otp" === allowedmodes[0] || "email" === allowedmodes[0] ? (jsonStr[signinathmode].isAMFA && $(".resendotp").show(), emobile = "otp" === allowedmodes[0] ? jsonStr[signinathmode].modes.otp && jsonStr[signinathmode].modes.otp.data[0].e_mobile : jsonStr[signinathmode].modes.email && jsonStr[signinathmode].modes.email.data[0].e_email, rmobile = "otp" === allowedmodes[0] ? jsonStr[signinathmode].modes.otp && identifyEmailOrNum(jsonStr[signinathmode].modes.otp.data[0].r_mobile, !0) : jsonStr[signinathmode].modes.email && jsonStr[signinathmode].modes.email.data[0].email, callmode = "secondary", "email" === allowedmodes[0] ? emailposition = 0 : mobposition = 0, generateOTP(!1, allowedmodes[0]), !1) : "mzadevice" === allowedmodes[0] ? (callmode = "secondary", mzadevicepos = 0, enableMyZohoDevice(jsonStr), !1) : "oadevice" === allowedmodes[0] ? (callmode = "secondary", enableOneauthDevice(jsonStr, oadevicepos), !1) : "yubikey" === allowedmodes[0] ? (callmode = "secondary", enableYubikeyDevice(jsonStr), !1) : "recoverycode" === allowedmodes[0] || "passphrase" === allowedmodes[0] ? (callmode = "secondary", enableOneAuthBackup(), !1) : (enableMfaField(allowedmodes[0]), !1)
    }
    return !1
}

function handleTotpDetails(resp) {
    if (!IsJsonString(resp)) {
        var container = "otpsecauth" === signinathmode ? "mfa_otp" : "otpauth" === signinathmode ? "otp" : "mfa_totp";
        return container = isTroubleSignin ? "verify_totp" : container, showCommonError(container, I18N.get("IAM.ERROR.GENERAL")), !1
    }
    var jsonStr = JSON.parse(resp);
    signinathmode = void 0 != jsonStr.resource_name ? jsonStr.resource_name : signinathmode;
    var statusCode = jsonStr.status_code,
        container = "otpsecauth" === signinathmode ? "mfa_otp" : "otpauth" === signinathmode ? "otp" : "mfa_totp";
    if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
        if (container = isTroubleSignin ? "verify_totp" : "email" === prev_showmode ? "mfa_email" : container, "throttles_limit_exceeded" === jsonStr.cause) return hideResendOTP(), showCommonError(container, jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors[0],
            errorCode = error_resp.code,
            errorMessage = jsonStr.localized_message;
        return "IN107" === errorCode || "IN108" === errorCode ? (cdigest = jsonStr.cdigest, showHip(cdigest), showCaptcha(I18N.get("IAM.NEXT"), !1, container), "IN107" === errorCode && showCommonError("captcha", errorMessage), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : (showCommonError(container, errorMessage), !1)
    }
    $(".go_to_bk_code_container").removeClass("show_bk_pop"), $(".go_to_bk_code_container").hide();
    var successCode = jsonStr.code,
        statusmsg = jsonStr[signinathmode].status;
    return "SI302" === successCode || "SI200" === successCode || "SI300" === successCode || "SI301" === successCode || "SI303" === successCode || "SI305" === successCode || "SI507" === successCode || "SI509" === successCode || "SI506" === successCode ? (switchto(jsonStr[signinathmode].redirect_uri), !1) : "success" === statusmsg ? restrictTrustMfa ? (updateTrustDevice(!1), !1) : (showTrustBrowser(), !1) : "P500" === successCode || "P501" === successCode || "P506" === successCode ? (temptoken = jsonStr[signinathmode].token, showPasswordExpiry(jsonStr[signinathmode].pwdpolicy, successCode), !1) : !1
}

function handleMyZohoDetails(resp) {
    if (!IsJsonString(resp)) {
        var errorcontainer = "passwordauth" === signinathmode ? "password" : "login_id";
        return showCommonError(errorcontainer, I18N.get("IAM.ERROR.GENERAL")), !1
    }
    var jsonStr = JSON.parse(resp);
    signinathmode = jsonStr.resource_name;
    var statusCode = jsonStr.status_code;
    if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
        var errorcontainer = isPasswordless ? "login_id" : "totp" === prefoption ? "mfa_totp" : $("#password_container").is(":visible") ? "password" : $("#otp_container").is(":visible") ? "otp" : "yubikey";
        errorcontainer = isResend ? "yubikey" : errorcontainer, "yubikey" === errorcontainer ? $("#yubikey_container").show() : $("#yubikey_container").hide();
        var error_resp = jsonStr.errors && jsonStr.errors[0],
            errorCode = error_resp && error_resp.code;
        if ("D105" === errorCode) return $(".fed_2show").hide(), showCommonError(errorcontainer, jsonStr.localized_message), isRecovery || allowedModeChecking(), !1;
        if ($("#problemsignin,#recoverybtn").hide(), "throttles_limit_exceeded" === jsonStr.cause) return showCommonError(errorcontainer, jsonStr.localized_message), $(".loader,.blur").hide(), !1;
        if ("pattern_not_matched" === jsonStr.cause) return changeHip(), showCommonError("captcha", jsonStr.localized_message), $(".loader,.blur").hide(), !1;
        if ("R303" === errorCode) return showRestrictsignin(), !1;
        var error_resp = jsonStr.errors[0],
            errorCode = error_resp.code,
            errorMessage = jsonStr.localized_message;
        return "push" === prefoption || "scanqr" === prefoption ? showTopErrNotificationStatic(jsonStr.localized_message) : showCommonError(errorcontainer, errorMessage), $(".loader,.blur").hide(), !1
    }
    var successCode = jsonStr.code;
    if ("SI202" === successCode || "MFA302" === successCode || "SI302" === successCode || "SI201" === successCode) {
        if (temptoken = jsonStr[signinathmode].token, isResend) return verifyCount = 0, showResendPushInfo(), isPasswordless && void 0 != jsonStr[signinathmode].rnd && ($("#rnd_num").html(jsonStr[signinathmode].rnd), resendpush_checking(time = 25)), !1;
        isTroubleSignin = !1, showMzaDevice(), $(".hellouser").hide(), handle_width_Of_Select(), $(".devices").click(function() {
            hideOABackupRedirection()
        });
        var devicedetails = deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[parseInt(mzadevicepos)];
        if ($(".tryanother").text(I18N.get(devicedetails.is_active ? "IAM.NEW.SIGNIN.TRY.ANOTHERWAY" : "IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH.OTHER.OPTION")), $(".tryanother").off().on("click", function() {
                devicedetails.is_active ? showTryanotherWay() : showproblemsignin(!0)
            }), prev_showmode = "mzadevice", !devicedetails.is_active || "undefined" != typeof jsonStr[signinathmode].is_installed_device && !jsonStr[signinathmode].is_installed_device) {
            var deviceUnstalled = !0;
            showMzaDevice(), $(".backup_info_content").html(formatMessage(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH.DESC"), devicedetails.device_name, oneAuthLearnmore)), window.setTimeout(function() {
                showOABackupRedirection(deviceUnstalled)
            }, 1e3)
        }
        if ("totp" === prefoption) return $(".step_two").html(I18N.get("IAM.NEW.SIGNIN.RIGHT.PANEL.VERIFY.TOTP")), $(".step_three").html(I18N.get("IAM.NEW.SIGNIN.RIGHT.PANEL.ALLOW.TOTP")), $(".approved").css("background", 'url("../images/TOTP_Verify.7413beaafe5ff6a598eeb58a16bad79f.svg") no-repeat transparent'), $("#mfa_scanqr_container,#mfa_push_container,#waitbtn,#openoneauth").hide(), enableTOTPdevice(jsonStr, !0, !1), $(".rnd_container").hide(), !1;
        if (showMzaDevice(), devicedetails && ($(".secondary_devices").uvselect("destroy"), $(".secondary_devices").val($(".secondary_devices option")[mzadevicepos].value)), $(".secondary_devices").off("change"), isMobile ? mobile_view_Device() : renderUV(".secondary_devices", !1, "", "", "", !1, !1, "Mobile", !0, null, null, "value"), $(".secondary_devices").change(function() {
                changeSecDevice(this)
            }), $(".secondary_devices option").length > 1 || $(".selectbox_arrow").hide(), handle_width_Of_Select(), "push" === prefoption || "scanqr" === prefoption) {
            var wmsid = jsonStr[signinathmode].WmsId && jsonStr[signinathmode].WmsId.toString();
            isVerifiedFromDevice(prefoption, !0, wmsid)
        }
        if ("push" === prefoption && (isPasswordless && void 0 != jsonStr[signinathmode].rnd ? ($(".rnd_container").show(), $("#rnd_num").html(jsonStr[signinathmode].rnd), $("#waitbtn,.loadwithbtn").hide(), $("#mfa_scanqr_container,#mfa_totp_container,#openoneauth, #qrOneContent, #qrOrLine").hide(), $(".service_name").text(I18N.get("IAM.NEW.SIGNIN.PUSH.RND.DESC")), $(".loader,.blur").hide(), $(".rnd_resend").show(), resendpush_checking(time = 20)) : ($("#waitbtn,.loadwithbtn").show(), $(".rnd_container").hide(), $(".waitbtn .waittext").text(I18N.get("IAM.NEW.SIGNIN.WAITING.APPROVAL")), $("#waitbtn").attr("disabled", !0), $("#mfa_scanqr_container,#mfa_totp_container,#openoneauth, #qrOneContent, #qrOrLine").hide(), $(".loader,.blur").hide(), window.setTimeout(function() {
                return $(".waitbtn .waittext").text(I18N.get("IAM.PUSH.RESEND.NOTIFICATION")), $(".loadwithbtn").hide(), $("#waitbtn").attr("disabled", !1), isFormSubmited = !1, !1
            }, 2e4))), "scanqr" === prefoption) {
            $(".step_two").html(I18N.get("IAM.NEW.SIGNIN.RIGHT.PANEL.ALLOW.SCANQR")), $(".step_three").html(I18N.get("IAM.NEW.SIGNIN.RIGHT.PANEL.VERIFY.SCANQR")), $(".approved").css("background", 'url("../images/SCANQR_Verify.823be333b83563ed3c9e71e7eaa175e5.svg") no-repeat transparent'), signinathmode = jsonStr.resource_name, $("#waitbtn").hide();
            var qrcodeurl = jsonStr[signinathmode].img;
            qrtempId = jsonStr[signinathmode].temptokenid, isValid(qrtempId) ? $("#qrOrLine, #openoneauth, #qrOneContent").show() : $("#qrOrLine, #openoneauth, #qrOneContent").hide(), isMobile && $(".devices").css("display", "none"), $("#mfa_push_container,#mfa_totp_container").hide(), $("#qrimg").attr("src", qrcodeurl), $(".checkbox_div").addClass("qrwidth")
        }
        $(".tryanother").show();
        var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
        return isAMFA && (allowedModeChecking(), $(".tryanother").hide()), isFormSubmited = !1, signinathmode = "primary" === callmode ? "deviceauth" : "devicesecauth", $(".loader,.blur").hide(), oneauthgrant = window.setTimeout(function() {
            showOABackupRedirection(!1)
        }, 45e3), !1
    }
    return !1
}

function showMzaDevice() {
    var headtitle = "push" === prefoption ? "IAM.NEW.SIGNIN.VERIFY.PUSH" : "totp" === prefoption ? "IAM.NEW.SIGNIN.TOTP" : "scanqr" === prefoption ? "IAM.NEW.SIGNIN.QR.CODE" : "",
        headerdesc = "push" === prefoption ? "IAM.NEW.SIGNIN.MFA.PUSH.HEADER" : "totp" === prefoption ? "IAM.NEW.SIGNIN.TOTP.HEADER" : "scanqr" === prefoption ? "IAM.NEW.SIGNIN.QR.HEADER" : "";
    $("#password_container,#login_id_container,#captcha_container,.fed_2show,#recoverybtn,#otp_container").hide(), isMobile ? $(".deviceparent").show() : $(".deviceparent").hide(), $("#headtitle").text(I18N.get(headtitle)), $(".devices").css("display", ""), headerdesc = deviceauthdetails[deviceauthdetails.resource_name].isAMFA ? I18N.get(headerdesc) + "<br>" + formatMessage(I18N.get("IAM.NEW.SIGNIN.WHY.VERIFY"), suspisious_login_link) : headerdesc, $(".service_name").html(I18N.get(headerdesc)), $(".product_text,.product_head,.MAppIcon,.OnaAuthHLink,.pwless_head,.pwless_text").hide(), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_" + prefoption + "_mode"), $("#forgotpassword,#problemsignin,#recoverybtn").hide(), $("#nextbtn").hide(), $("#mfa_" + prefoption + "_container").show(), $(".service_name").addClass("extramargin"), $("#mfa_device_container").show(), $(".signin_container").removeClass("mobile_signincontainer"), $(".rnd_container").hide()
}

function handleOneAuthDetails(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
            var errorcontainer = "totp" === prefoption || "ONEAUTH_TOTP" === prefoption ? "mfa_totp" : "yubikey";
            "yubikey" === errorcontainer ? $("#yubikey_container").show() : $("#yubikey_container").hide();
            var error_resp = jsonStr.errors[0],
                errorCode = error_resp.code;
            return "D105" === errorCode ? (showCommonError(errorcontainer, jsonStr.localized_message), $(".fed_2show").hide(), isRecovery || allowedModeChecking(), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : "throttles_limit_exceeded" === jsonStr.cause ? (showCommonError(errorcontainer, jsonStr.localized_message), !1) : (showCommonError(errorcontainer, jsonStr.localized_message), !1)
        }
        var successCode = jsonStr.code;
        if ("SI302" === successCode || "MFA302" === successCode || "SI202" === successCode || "SI201" === successCode) {
            temptoken = jsonStr[signinathmode].token, "blockversion" in jsonStr[signinathmode] && jsonStr[signinathmode].blockversion && ($("#yubikey_container").show(), showCommonError("yubikey", jsonStr.localized_message)), prefoption = deviceauthdetails[deviceauthdetails.resource_name].modes.oadevice.data[oadevicepos].prefer_option;
            var devicemode = "ONEAUTH_PUSH_NOTIF" === prefoption ? "push" : "ONEAUTH_TOTP" === prefoption ? "totp" : "ONEAUTH_SCAN_QR" === prefoption ? "scanqr" : "ONEAUTH_FACE_ID" === prefoption ? "faceid" : "ONEAUTH_TOUCH_ID" === prefoption ? "touch" : "";
            if (isResend) return showResendPushInfo(), !1;
            var headtitle = "ONEAUTH_PUSH_NOTIF" === prefoption ? "IAM.NEW.SIGNIN.VERIFY.PUSH" : "ONEAUTH_TOTP" === prefoption ? "IAM.NEW.SIGNIN.TOTP" : "ONEAUTH_SCAN_QR" === prefoption ? "IAM.NEW.SIGNIN.QR.CODE" : "ONEAUTH_FACE_ID" === prefoption ? "IAM.NEW.SIGNIN.FACEID.TITLE" : "ONEAUTH_TOUCH_ID" === prefoption ? "IAM.NEW.SIGNIN.TOUCHID.TITLE" : "",
                headerdesc = "ONEAUTH_PUSH_NOTIF" === prefoption ? "IAM.NEW.SIGNIN.MFA.PUSH.HEADER" : "ONEAUTH_TOTP" === prefoption ? "IAM.NEW.SIGNIN.ONEAUTH.TOTP.HEADER" : "ONEAUTH_SCAN_QR" === prefoption ? "IAM.NEW.SIGNIN.QR.HEADER" : "ONEAUTH_FACE_ID" === prefoption ? "IAM.NEW.SIGNIN.FACEID.HEADER" : "ONEAUTH_TOUCH_ID" === prefoption ? "IAM.NEW.SIGNIN.TOUCHID.HEADER" : "";
            if (isFaceId === !0 && (headtitle = "IAM.NEW.SIGNIN.FACEID.TITLE", headerdesc = "IAM.NEW.SIGNIN.FACEID.HEADER", devicemode = "faceid"), $("#password_container,#login_id_container,#captcha_container,.fed_2show,#otp_container,.deviceparent").hide(), $("#headtitle").text(I18N.get(headtitle)), $(".service_name").text(I18N.get(headerdesc)), $(".product_text,.product_head,.MAppIcon,.OnaAuthHLink,.pwless_head,.pwless_text").hide(), $("#product_img").removeClass($("#product_img").attr("class")), $(".devices").css("display", ""), $("#product_img").addClass("tfa_" + devicemode + "_mode"), $("#forgotpassword").hide(), $("#nextbtn").hide(), $("#mfa_" + devicemode + "_container").show(), $(".service_name").addClass("extramargin"), $("#mfa_device_container").show(), isRecovery || allowedModeChecking(), $(".loader,.blur").hide(), "push" === devicemode || "touch" === devicemode || "faceid" === devicemode || "scanqr" === devicemode) {
                var wmsid = jsonStr[signinathmode].WmsId && jsonStr[signinathmode].WmsId.toString();
                callmode = "secondary", isVerifiedFromDevice(prefoption, !1, wmsid)
            }
            if (("push" === devicemode || "touch" === devicemode || "faceid" === devicemode) && ($("#waitbtn").attr("disabled", !0), $(".waitbtn .waittext").text(I18N.get("IAM.NEW.SIGNIN.WAITING.APPROVAL")), $(".loadwithbtn").show(), $("#waitbtn").show(), $("#openoneauth, #qrOneContent, #qrOrLine").hide(), window.setTimeout(function() {
                    return $(".waitbtn .waittext").text(I18N.get("IAM.PUSH.RESEND.NOTIFICATION")), $("#waitbtn").attr("disabled", !1), $(".loadwithbtn").hide(), isFormSubmited = !1, !1
                }, 2e4)), "scanqr" === devicemode) {
                var qrcodeurl = jsonStr[signinathmode].img;
                qrtempId = jsonStr[signinathmode].temptokenid, isValid(qrtempId) ? $("#openoneauth, #qrOneContent, #qrOrLine").show() : $("#openoneauth, #qrOneContent, #qrOrLine").hide(), $("#qrimg").attr("src", qrcodeurl), $(".checkbox_div").addClass("qrwidth")
            }
            return isFormSubmited = !1, !1
        }
        return !1
    }
    var errorcontainer = "passwordauth" === signinathmode ? "password" : "login_id";
    return showCommonError(errorcontainer, I18N.get("IAM.ERROR.GENERAL")), !1
}

function handlePassphraseDetails(resp) {
    if (IsJsonString(resp)) {
        $("#backupVerifybtn span").removeClass("zeroheight"), $("#backupVerifybtn").removeClass("changeloadbtn"), $("#backupVerifybtn").attr("disabled", !1);
        var jsonStr = JSON.parse(resp);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            var successCode = jsonStr.code,
                statusmsg = jsonStr.passphrasesecauth.status;
            return "success" === statusmsg ? restrictTrustMfa ? (updateTrustDevice(!1), !1) : (showTrustBrowser(), !1) : "P500" === successCode || "P501" === successCode || "P506" === successCode ? (temptoken = jsonStr[signinathmode].token, showPasswordExpiry(jsonStr[signinathmode].pwdpolicy, successCode), !1) : (showCommonError("passphrase", jsonStr.localized_message), !1)
        }
        if ("throttles_limit_exceeded" === jsonStr.cause) return showCommonError("passphrase", jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors && jsonStr.errors[0],
            errorCode = error_resp && error_resp.code;
        return "IN107" === errorCode || "IN108" === errorCode ? ($(".fed_2show,.line").hide(), cdigest = jsonStr.cdigest, showHip(cdigest, "bcaptcha_img"), $("#bcaptcha_container").show(), $("#bcaptcha").focus(), clearCommonError("bcaptcha"), changeButtonAction(I18N.get("IAM.NEW.SIGNIN.VERIFY"), !1), "IN107" === errorCode && showCommonError("bcaptcha", errorMessage), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : (showCommonError("passphrase", jsonStr.localized_message), !1)
    }
}

function resendpush_checking(resendtiming) {
    clearInterval(resendTimer), $(".rnd_resend").addClass("nonclickelem"), $(".rnd_resend").html(I18N.get("IAM.NEW.SIGNIN.RESEND.PUSH.COUNTDOWN")), $(".rnd_resend span").text(resendtiming), resendTimer = setInterval(function() {
        resendtiming--, $(".rnd_resend span").text(resendtiming), 0 === resendtiming && (clearInterval(resendTimer), $(".rnd_resend").html(I18N.get("IAM.NEW.SIGNIN.RESEND.PUSH")), $(".rnd_resend").removeClass("nonclickelem"))
    }, 1e3)
}

function isVerifiedFromDevice(prefmode, isMyZohoApp, WmsID) {
    if (isWmsRegistered === !1 && isValid(WmsID) && "undefined" != WmsID) {
        wmscallmode = prefmode, wmscallapp = isMyZohoApp, wmscallid = WmsID;
        try {
            WmsLite.setClientSRIValues(wmsSRIValues), WmsLite.setNoDomainChange(), WmsLite.registerAnnon("AC", WmsID), isWmsRegistered = !0
        } catch (e) {}
    }
    if (prefmode = void 0 === prefmode ? wmscallmode : prefmode, isMyZohoApp = void 0 === isMyZohoApp ? wmscallapp : isMyZohoApp, WmsID = void 0 === WmsID ? wmscallid : WmsID, clearInterval(_time), verifyCount > 15) return !1;
    var loginurl = isMyZohoApp ? uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/device/" + deviceid + "?" : uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/oneauth/" + deviceid + "?";
    loginurl += "digest=" + digest + "&" + signinParams + "&polling=" + !0;
    var jsonData = {
        oneauthsec: {
            devicepref: prefmode
        }
    };
    if (isMyZohoApp) {
        jsonData = "primary" === callmode ? {
            deviceauth: {
                devicepref: prefmode
            }
        } : {
            devicesecauth: {
                devicepref: prefmode
            }
        };
        var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
        jsonData = "primary" != callmode && isAMFA ? {
            devicesecauth: {
                devicepref: prefoption,
                isAMFA: !0
            }
        } : jsonData
    }
    if (sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !1, VerifySuccess, "PUT"), verifyCount++, isValid(WmsID) && "undefined" != WmsID) {
        wmscount++;
        var callIntervalTime = 6 > wmscount ? 5e3 : 25e3;
        return _time = setInterval(function() {
            isVerifiedFromDevice(prefmode, isMyZohoApp, WmsID)
        }, callIntervalTime), !1
    }
    return _time = setInterval(function() {
        isVerifiedFromDevice(prefmode, isMyZohoApp, WmsID)
    }, 3e3), !1
}

function VerifySuccess(res) {
    if (IsJsonString(res)) {
        var jsonStr = JSON.parse(res);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            var successCode = jsonStr.code,
                statusmsg = jsonStr[signinathmode].status;
            if ("SI302" === successCode || "SI200" === successCode || "SI300" === successCode || "SI301" === successCode || "SI303" === successCode || "SI305" === successCode || "SI507" === successCode || "SI509" === successCode || "SI506" === successCode) return switchto(jsonStr[signinathmode].redirect_uri), !1;
            if ("success" === statusmsg) return clearInterval(_time), restrictTrustMfa ? (updateTrustDevice(!1), !1) : (showTrustBrowser(), !1);
            if ("P500" === successCode || "P501" === successCode || "P506" === successCode) return temptoken = jsonStr[signinathmode].token, showPasswordExpiry(jsonStr[signinathmode].pwdpolicy, successCode), !1
        } else if ("500" == statusCode) {
            var error_resp = jsonStr.errors && jsonStr.errors[0].code;
            if (error_resp && "D103" != error_resp && "D112" != error_resp && !jsonStr.is_active) {
                var devicedetails = deviceauthdetails[deviceauthdetails.resource_name].modes,
                    devicename = devicedetails.mzadevice.data && devicedetails.mzadevice.data[parseInt(mzadevicepos)].device_name;
                return $(".backup_info_content").html(formatMessage(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH.DESC"), devicename, oneAuthLearnmore)), showOABackupRedirection(!0), !1
            }
            if ("Y401" == error_resp) {
                if (isPasswordless) return showTopErrNotification(I18N.get("IAM.SIGNIN.ERROR.YUBIKEY.VALIDATION.FAILED")), !1;
                if ("R303" === error_resp) return showRestrictsignin(), !1;
                showCommonError("yubikey", I18N.get("IAM.SIGNIN.ERROR.YUBIKEY.VALIDATION.FAILED")), $("#yubikey_container").show(), showError()
            }
        }
    }
    return !1
}

function handleSecondaryDevices(primaryMode) {
    if ("oadevice" === primaryMode || "mzadevice" === primaryMode) {
        $(".secondary_devices").find("option").remove().end();
        var deviceDetails = deviceauthdetails[deviceauthdetails.resource_name].modes,
            isSecondaryDevice = !1,
            optionElem = "";
        if (secondaryMode = "oadevice", "oadevice" == primaryMode && (secondaryMode = "mzadevice"), deviceDetails[primaryMode]) {
            var oneauthdetails = deviceDetails[primaryMode].data;
            "push" != oneauthdetails[0].prefer_option ? (optionElem += "<option value='0' version='" + oneauthdetails[0].app_version + "'>" + oneauthdetails[0].device_name + "</option>", isSecondaryDevice = !0) : oneauthdetails.forEach(function(data, index) {
                optionElem += "<option value=" + index + " version='" + data.app_version + "'>" + data.device_name + "</option>", isSecondaryDevice = !0
            })
        }
        if (deviceDetails[secondaryMode]) {
            var oneauthdetails = deviceDetails[secondaryMode].data;
            "push" != oneauthdetails[0].prefer_option ? (optionElem += "<option value='0' version='" + oneauthdetails[0].app_version + "'>" + oneauthdetails[0].device_name + "</option>", isSecondaryDevice = !0) : oneauthdetails.forEach(function(data, index) {
                optionElem += "<option value=" + index + " version='" + data.app_version + "'>" + data.device_name + "</option>", isSecondaryDevice = !0
            })
        }
        if (document.getElementsByClassName("secondary_devices")[0].innerHTML = optionElem, isSecondaryDevice) try {
            $(".secondary_devices").off("change"), isMobile ? mobile_view_Device() : renderUV(".secondary_devices", !1, "", "", "", !1, !1, "Mobile", !0, null, null, "value"), $(".secondary_devices").change(function() {
                changeSecDevice(this)
            }), prevoption = $(".secondary_devices").children("option:selected").val(), $(".secondary_devices option").length > 1 || $(".selectbox_arrow").hide(), window.setTimeout(function() {
                $(".devices .select2").addClass("device_select"), $(".devices .select2").show(), $(".devices .select2-selection--single").addClass("device_selection"), $(".devicedetails").hide(), $(".select2-selection__arrow").addClass("hide"), $(".secondary_devices option").length > 1 || ($(".downarrow").hide(), $(".devices").css("pointer-events", "none"))
            }, 100)
        } catch (err) {
            $(".secondary_devices").css("display", "block"), $(".secondary_devices option").length > 1 || $(".secondary_device").css("pointer-events", "none"), $("option").each(function() {
                if (this.text.length > 20) {
                    var optionText = this.text,
                        newOption = optionText.substring(0, 20);
                    $(this).text(newOption + "...")
                }
            })
        }
    }
}

function mobile_view_Device() {
    $(".devicetext").html($(".secondary_devices").find(":selected")[0].innerHTML).show(), $(".deviceparent").css("width", "fit-content").css("margin", "auto").css("max-width", "200px").css("border", "1px solid #CECECE").css("border-radius", "6px").css("padding", "8px 18px").css("direction", "ltr").show(), 1 == $(".secondary_devices option").length && $(".mobile_dev_arrow").hide(), handle_width_Of_Select()
}

function handle_width_Of_Select() {
    var direction = "rtl" === $("body").attr("dir") ? "margin-right" : "margin-left";
    $(".secondary_devices").css("width", $(".deviceparent").outerWidth()).css(direction, $(".deviceparent").css("margin-left")), $(".secondary_devices option").css("width", $(".deviceparent").outerWidth())
}

function secondaryFormat(option) {
    return "<div><span class='icon-device select_icon'></span><span class='select_con' value=" + $(option.element).attr("value") + " version=" + $(option.element).attr("version") + ">" + option.text + "</span></div>"
}

function showMoreSigninOptions(listoutallmode) {
    listoutallmode ? showproblemsignin(!0, !1, !0) : showproblemsignin(!0), showCantAccessDevice(), $(".problemsignin_head,.recoveryhead .backoption").hide(), -1 != allowedmodes.indexOf("recoverycode") ? $("#recoverOption").show() : $("#recoverOption").hide(), -1 != allowedmodes.indexOf("passphrase") ? $("#passphraseRecover").show() : $("#passphraseRecover").hide(), $(".rec_head_text").html(I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY") + "<div class='oa_head_con'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY.DESC") + "</div></div>"), $(".backuphead .backoption,.greytext").hide(), $(".recoveryhead .backoption").css("cssText", "display: none !important;"), $("#recoverymodeContainer").html($(".problemsignincon").html() ? $(".problemsignincon").html() + $(".recoverymodes").html() : $(".recoverymodes").html()), $(".showBackupVerificationCode").click(function() {
        showBackupVerificationCode()
    }), $("#passphraseRecover").click(function() {
        showPassphraseContainer()
    }), $(".showCurrentMode").on("click", function() {
        isPasswordless ? showAlterVerificationINfo($(this).attr("mode")) : showCurrentMode($(this).attr("mode"), parseInt($(this).attr("index")))
    }), $(".recoverymodes,.contact_support").hide(), $(".contactSupport").show(), $("#recoverymodeContainer").children().length - !$("#recoverOption").is(":visible") - !$("#passphraseRecover").is(":visible") > 3 && !isMobile && $("#recoverymodeContainer").addClass("problemsignincontainer"), oaNotInstalled && ($("#recoverymodeContainer,.contactSupport").show(), $(".contactSupportDesc,.mailbox,.supportSLA,#FAQ").hide()), isRecovery = listoutallmode ? !0 : !1, isPasswordless = !1
}

function generateOTP(isResendOnly, mode, captchavalue) {
    if ("undefined" != typeof mode && isResendOnly && (mode = prev_showmode), mode = mode && "email" == mode.toLowerCase() ? "EMAIL" : "MOBILE", isResendOnly && ($(".resendotp").addClass("sendingotp"), $(".resendotp").text(I18N.get("IAM.NEW.GENERAL.SENDING.OTP"))), isPrimaryMode) return generateOTPAuth(isResendOnly, mode, captchavalue), !1;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/otp/" + emobile,
        isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
        callback = "email" == prev_showmode ? enableOTPForEmail : enableOTPDetails;
    if (isResendOnly) {
        loginurl += "?digest=" + digest + "&" + signinParams;
        var jsonData = isAMFA ? {
            otpsecauth: {
                mdigest: mdigest,
                is_resend: !0,
                isAMFA: !0,
                mode: mode
            }
        } : {
            otpsecauth: {
                mdigest: mdigest,
                is_resend: !0,
                mode: mode
            }
        };
        return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, showResendInfo, "PUT"), !1
    }
    loginurl += "?digest=" + digest + "&" + signinParams, captchavalue && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest);
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
        jsonData = isAMFA ? {
            otpsecauth: {
                isAMFA: !0,
                mode: mode
            }
        } : {
            otpsecauth: {
                mode: mode
            }
        };
    return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, callback), !1
}

function generateOTPAuth(isResendOnly, mode, captchavalue) {
    var emailID = $("#emailcheck").val() ? $("#emailcheck").val().trim() : "";
    if ($("#emailcheck_container").is(":visible") && (!isValid(emailID) || !isEmailIdSignin(emailID))) return isValid(emailID) ? showCommonError("emailcheck", I18N.get("IAM.NEW.SIGNIN.INVALID.LOOKUP.EMAIL")) : showCommonError("emailcheck", I18N.get("IAM.NEW.SIGNIN.ENTER.EMAIL.ADDRESS")), !1;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/otp/" + emobile + "?digest=" + digest + "&" + signinParams;
    captchavalue && (loginurl += "&captcha=" + captchavalue + "&cdigest=" + cdigest);
    var callback = isResendOnly ? showResendInfo : enableOTPDetails;
    callback = $("#emailcheck_container").is(":visible") ? enableEmailOTPDetails : callback;
    var jsonData = isValid(emailID) ? {
            otpauth: {
                email_id: emailID,
                mode: mode
            }
        } : {
            otpauth: {
                mode: mode
            }
        },
        jsonDataResend = isResendOnly && $("#emailverify_container").is(":visible") ? {
            otpauth: {
                is_resend: !0,
                email_id: emailID,
                mode: mode
            }
        } : {
            otpauth: {
                is_resend: !0,
                mode: mode
            }
        },
        encryptionJson = {
            path: "otpauth.email_id",
            value: emailID
        };
    return isResendOnly ? sendRequestWithTemptoken(loginurl, JSON.stringify(jsonDataResend), !0, callback, void 0, encryptionJson, emailID) : sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, callback, void 0, encryptionJson, emailID), !1
}

function showResendInfo(resp) {
    var elem = $("#mfa_otp").is(":visible") ? "mfa_otp" : $("#mfa_email").is(":visible") ? "mfa_email" : $("#otp").is(":visible") ? "otp" : $("#emailverify").is(":visible") ? "emailverify" : void 0;
    if (void 0 != elem && $("#" + elem).click(), resendcheck >= 0 && IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
            if ("throttles_limit_exceeded" === jsonStr.cause) return isPrimaryDevice ? (showTopErrNotification(jsonStr.localized_message), !1) : (elem ? showCommonError(elem, jsonStr.localized_message) : showTopErrNotification(jsonStr.localized_message), !1);
            var error_resp = jsonStr.errors && jsonStr.errors[0],
                errorCode = error_resp && error_resp.code,
                errorMessage = jsonStr.localized_message;
            return "IN107" === errorCode || "IN108" === errorCode ? (cdigest = jsonStr.cdigest, showHip(cdigest), showCaptcha(I18N.get("IAM.NEXT"), !1, "otp"), "IN107" === errorCode && showCommonError("captcha", errorMessage), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : (showCommonError("otp", errorMessage), !1)
        }
        var successCode = jsonStr.code;
        if ("SI201" === successCode || "SI200" === successCode) return mdigest = jsonStr[signinathmode].mdigest, showTopNotification(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.SENT.RESEND"), rmobile)), "primary" === callmode ? PriotpThreshold-- : void 0 != MFAotpThresholdmob && "otp" === prev_showmode ? MFAotpThresholdmob-- : void 0 != AMFAotpThreshold && "email" === prev_showmode ? AMFAotpThreshold-- : "", resendotp_checking(), -1 != allowedmodes.indexOf("recoverycode") && setTimeout(function() {
            $("#mfa_otp_container").is(":visible") && ($(".go_to_bk_code_container").addClass("show_bk_pop"), $(".go_to_bk_code_container").show())
        }, 3e4), !1
    }
    return !1
}

function enableOTPDetails(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            var successCode = jsonStr.code;
            return "SI201" === successCode || "SI200" === successCode ? ($(".loader,.blur").hide(), mdigest = jsonStr[signinathmode].mdigest, isSecondary = deviceauthdetails[deviceauthdetails.resource_name] && deviceauthdetails[deviceauthdetails.resource_name].modes.otp && deviceauthdetails[deviceauthdetails.resource_name].modes.otp.count > 1 || allowedmodes.length > 1 && -1 === allowedmodes.indexOf("recoverycode") ? !0 : !1, hideCaptchaContainer(), "otpauth" === signinathmode ? (clearCommonError("otp"), $("#login").show(), $("#emailcheck_container").hide(), $("#emailcheck").val(""), showTopNotification(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.SENT"), rmobile), 1e4), resendotp_checking(), showOtpDetails(), isPasswordless || fallBackForSingleMode(prev_showmode, validateAllowedMode(prev_showmode).option), $(".resendotp").show(), !1) : (isValid(digest) || (digest = jsonStr[signinathmode].mdigest), enableMfaField("otp"), resendotp_checking(), !1)) : !1
        }
        $(".blur,.loader").hide();
        var error_resp = jsonStr.errors && jsonStr.errors[0],
            errorCode = error_resp && error_resp.code;
        if ("IN107" === errorCode || "IN108" === errorCode) return showCaptchaContainer(jsonStr), cdigest = jsonStr.cdigest, showHip(cdigest), !1;
        if ("AS115" == errorCode) return showOtpDetails(), showCommonError("otp", jsonStr.localized_message), $("#otp").blur(), $(".resendotp").hide(), isPasswordless || fallBackForSingleMode(prev_showmode, validateAllowedMode(prev_showmode).option), !1;
        isPasswordless || fallBackForSingleMode(prev_showmode, validateAllowedMode(prev_showmode).option);
        var errorfield = $("#emailcheck_container").is(":visible") ? "emailcheck" : "password";
        if ("throttles_limit_exceeded" === jsonStr.cause) return $("#problemsigninui").is(":visible") && $("#enablemore").hide(), $("#" + errorfield).is(":visible") ? showCommonError(errorfield, jsonStr.localized_message) : showTopErrNotification(jsonStr.localized_message), !1;
        var errorMessage = jsonStr.localized_message;
        return showCommonError(errorfield, errorMessage), !1
    }
    return !1
}

function btnAllowedModes() {
    var bBtnAllowedModes = allowedmodes.length;
    return allowedmodes.forEach(function(usedmode) {
        ("saml" == usedmode || "federated" == usedmode || "jwt" == usedmode || "mzadevice" == usedmode || "oidc" == usedmode) && bBtnAllowedModes--
    }), bBtnAllowedModes
}

function showSigninUsingFedOption() {
    if ("undefined" == typeof allowedmodes) return !1;
    if ((-1 != allowedmodes.indexOf("oidc") || -1 != allowedmodes.indexOf("jwt") || -1 != allowedmodes.indexOf("federated") || -1 != allowedmodes.indexOf("saml")) && ($(".fed_2show").show(), $(".large_box").removeClass("large_box"), $(".fed_div").addClass("small_box"), $(".fed_div, .fed_text").hide(), $(".googleIcon").removeClass("google_small_icon"), document.getElementById("fed_signin_options").innerHTML = ""), -1 != allowedmodes.indexOf("federated")) {
        var idps = deviceauthdetails.lookup.modes.federated.data;
        idps.forEach(function(idps) {
            isValid(idps) && (idp = idps.idp.toLowerCase(), $("." + idp + "_fed").attr("style", "display:block !important"))
        }), $(".apple_fed").is(":visible") && (isneedforGverify ? $("#macappleicon").hide() : ($(".apple_fed").hide(), $("#macappleicon").show(), $(".googleIcon").addClass("google_small_icon"))), isneedforGverify ? $(".google_icon .fed_text").show() : $(".google_icon .fed_text").hide()
    }
    if (-1 != allowedmodes.indexOf("jwt"))
        if (deviceauthdetails.lookup.modes.jwt && deviceauthdetails.lookup.modes.jwt.count > 1)
            for (var jwtCount = deviceauthdetails.lookup.modes.jwt.count, i = 0; jwtCount > i; i++) appendJWT(i);
        else appendJWT(0);
    if (-1 != allowedmodes.indexOf("oidc"))
        if (deviceauthdetails.lookup.modes.oidc && deviceauthdetails.lookup.modes.oidc.count > 1)
            for (var oidcCount = deviceauthdetails.lookup.modes.oidc.count, i = 0; oidcCount > i; i++) appendOIDC(i);
        else appendOIDC(0);
    if (-1 != allowedmodes.indexOf("saml"))
        if (deviceauthdetails.lookup.modes.saml && deviceauthdetails.lookup.modes.saml.count > 1)
            for (var samlCount = deviceauthdetails.lookup.modes.saml.count, i = 0; samlCount > i; i++) appendSAML(i);
        else appendSAML(0)
}

function enableOTPForEmail(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp);
        signinathmode = jsonStr.resource_name;
        var statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            AMFAotpThreshold = 3; {
                jsonStr.code
            }
            $(".loader,.blur").hide(), mdigest = jsonStr[signinathmode].mdigest, oldsigninathmode = oldsigninathmode ? oldsigninathmode : signinathmode, goBackToProblemSignin();
            var emaillist = deviceauthdetails[deviceauthdetails.resource_name].modes && deviceauthdetails[deviceauthdetails.resource_name].modes.email;
            return isSecondary = emaillist && emaillist.count > 1 || allowedmodes.length > 1 && -1 === allowedmodes.indexOf("recoverycode"), $("#password_container,#captcha_container,.fed_2show,#otp_container").hide(), $("#headtitle").text(I18N.get("IAM.AC.CHOOSE.OTHER_MODES.EMAIL.HEADING")), $(".service_name").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.HEADER"), rmobile) + "<br>" + formatMessage(I18N.get("IAM.NEW.SIGNIN.WHY.VERIFY"), suspisious_login_link)), $("#product_img").removeClass($("#product_img").attr("class")), $("#product_img").addClass("tfa_otp_mode"), showTopNotification(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.SENT"), rmobile)), isClientPortal || enableSplitField("mfa_email", otp_length, I18N.get("IAM.VERIFY.CODE")), $("#mfa_email_container,#mfa_email_container .textbox_actions").show(), $("#forgotpassword").hide(), $(".service_name").addClass("extramargin"), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), $("#nextbtn span").text(I18N.get("IAM.NEW.SIGNIN.VERIFY")), isClientPortal && $("#mfa_email").focus(), isFormSubmited = !1, callmode = "secondary", resendotp_checking(), allowedModeChecking(), isValid(digest) || (digest = jsonStr[signinathmode].mdigest), signinathmode = jsonStr.resource_name, !1
        }
        if (triggeredUser) return showTopErrNotification(jsonStr.localized_message), !1;
        if ("throttles_limit_exceeded" === jsonStr.cause) return showCommonError("password", jsonStr.localized_message), !1;
        var errorMessage = jsonStr.localized_message;
        return showCommonError("password", errorMessage), !1
    }
    return !1
}

function resendotp_checking() {
    var resendtiming = 60;
    clearInterval(resendTimer), $(".resendotp").hasClass("sendingotp") && $(".resendotp").removeClass("sendingotp"), $(".resendotp").addClass("nonclickelem"), $(".resendotp span").text(resendtiming), resendcheck = "primary" === callmode ? PriotpThreshold : "undefined" != MFAotpThresholdmob && "otp" === prev_showmode ? MFAotpThresholdmob : "undefined" != AMFAotpThreshold && "email" === prev_showmode ? AMFAotpThreshold : "";
    var attemptContent = 0 == resendcheck && "primary" === callmode ? "IAM.SIGNIN.OTP.THRESHOLD.LIMIT.ENDS" : 0 == resendcheck && "primary" != callmode ? "IAM.SIGNIN.OTP.MAX.COUNT.MFA.LIMIT.ENDS" : "";
    if (2 >= resendcheck && resendcheck >= 0) {
        if ($(".resendotp").html(I18N.get("IAM.TFA.RESEND.OTP.COUNTDOWN")), 0 == resendcheck) return $(".resendotp").html(I18N.get(attemptContent)), !1
    } else $(".resendotp").html(I18N.get("IAM.TFA.RESEND.OTP.COUNTDOWN"));
    resendTimer = setInterval(function() {
        resendtiming--, $(".resendotp span").text(resendtiming), 0 === resendtiming && (clearInterval(resendTimer), $(".resendotp").html(I18N.get("IAM.NEW.SIGNIN.RESEND.OTP")), $(".resendotp").removeClass("nonclickelem"))
    }, 1e3)
}

function changeRecoverOption(recoverOption) {
    "passphrase" === recoverOption ? showPassphraseContainer() : showBackupVerificationCode(), "passphrase" === recoverOption ? (recoverTitle = I18N.get("IAM.NEW.SIGNIN.PASSPHRASE.RECOVER.TITLE"), recoverHeader = I18N.get("IAM.NEW.SIGNIN.PASSPHRASE.RECOVER.HEADER")) : "recoverycode" === recoverOption && (recoverTitle = I18N.get("IAM.BACKUP.VERIFICATION.CODE"), recoverHeader = I18N.get("IAM.NEW.SIGNIN.BACKUP.RECOVER.HEADER")), $("#backup_container #backup_title").text(recoverTitle), $("#backup_container .backup_desc").text(recoverHeader), $("#backup_container .backoption").hide()
}

function showError() {
    return $(".waitbtn .waittext").text(I18N.get("IAM.EXCEPTION.RELOAD")), $(".waittext").css("waittext", "0px"), $(".loadwithbtn").hide(), $("#waitbtn").attr("disabled", !1), isFormSubmited = !1, !1
}

function showMoreIdps() {
    return $("#showIDPs, .zohosignin").attr("aria-expanded", !0), $("#login,.line").hide(), $(".small_box").removeClass("small_box"), $(".fed_div").addClass("large_box"), $(".fed_text,.fed_2show").show(), $(".zohosignin").removeClass("hide"), $("#showIDPs").hide(), $(".fed_div").show(), $(".more").hide(), $(".signin_container").css("height", "auto"), $(".intuiticon").removeClass("icon-intuit_small"), $(".intuit_icon,.intuit_icon .fed_center").removeClass("intuit_fed"), $("#fed_large_title").show(), $(".signin_fed_text").hide(), $("#signuplink").hide(), setFooterPosition(), isneedforGverify ? void $("#macappleicon").hide() : ($(".fed_center_google").css("width", "max-content"), $(".googleIcon").removeClass("google_small_icon"), $(".apple_fed").hide(), $("#macappleicon").show(), !1)
}

function showZohoSignin() {
    $("#showIDPs, .zohosignin").attr("aria-expanded", !1), $("#login").show(), isMobile || $(".line").show(), $(".zohosignin").addClass("hide"), $(".fed_text,.fed_div").hide(), $(".signin_fed_text").removeClass("signin_fedtext_bold"), $(".more,.show_fed").show(), de("login_id") && $("#login_id").focus(), $(".large_box").removeClass("large_box"), $(".fed_div").addClass("small_box"), $(".intuiticon").addClass("icon-intuit_small"), $(".intuit_icon,.intuit_icon .fed_center").removeClass("intuit_fed"), $("#fed_large_title").hide(), $(".signin_fed_text").show(), $("#signuplink").show(), fediconsChecking()
}

function showHidePassword(fieldID) {
    var passwordField = isValid(fieldID) ? fieldID : "#password";
    passwordField = $("#passphrase").is(":visible") ? "#passphrase" : passwordField;
    var passType = $(passwordField).attr("type");
    "password" === passType ? ($(passwordField).attr("type", "text"), fieldID ? $(fieldID + "~ .show_hide_Confpassword").addClass("icon-show").removeClass("icon-hide") : $(".show_hide_password").addClass("icon-show").removeClass("icon-hide")) : ($(passwordField).attr("type", "password"), fieldID ? $(fieldID + " ~ .show_hide_Confpassword").removeClass("icon-show").addClass("icon-hide") : $(".show_hide_password").removeClass("icon-show").addClass("icon-hide")), $(passwordField).focus()
}

function changeCountryCode() {
    $(".select_country_code").text($("#country_code_select").val()), mobileflag()
}

function fediconsChecking() {
    if (0 === isShowFedOptions || $(".profile_head").is(":visible")) return $(".fed_2show,.line").hide(), !1;
    if ("undefined" != typeof signinathmode && "lookup" != signinathmode) return !1;
    $(".large_box").removeClass("large_box"), isneedforGverify ? 1 == $("#macappleicon").length && ($("#macappleicon").remove(), $("#appleNormalIcon").show()) : ($("#appleNormalIcon").remove(), $("#macappleicon").show()), $(".fed_div").addClass("small_box"), $(".fed_text,.fed_div").hide();
    /^((?!chrome|android).)*safari/i.test(navigator.userAgent) || /Mac|iPad|iPhone|iPod/.test(navigator.platform || "");
    if (isneedforGverify ? $(".google_icon .fed_text").show() : $(".google_icon .fed_text").hide(), document.getElementsByClassName("fed_div").length > 0) {
        document.getElementsByClassName("fed_div")[0].style.display = "inline-block", document.getElementsByClassName("fed_div")[0].classList.add("show_fed");
        var fed_all_width = $(".signin_box").width(),
            show_fed_length = Math.floor(fed_all_width / 50),
            moreiconcount = 1;
        if ($(".fed_div").length - moreiconcount > show_fed_length) {
            show_fed_length = fed_all_width % 50 >= 40 ? show_fed_length : show_fed_length - 1;
            for (var i = 0; show_fed_length > i; i++) document.getElementsByClassName("fed_div")[i].style.display = "inline-block", document.getElementsByClassName("fed_div")[i].classList.add("show_fed");
            $(".more").show(), $(".fed_2show").show()
        } else $(".more").remove(), $(".fed_div:last").css("margin", "0px"), $(".fed_div,.fed_2show").show();
        $(".fed_div").length <= 0 && $(".fed_2show,.line").hide()
    }
}

function onSigninReady() {
    if (void 0 != typeof signin_info_urls && signin_info_urls && Object.keys(signin_info_urls).length > 0 ? handleMultiDCData() : (hideloader(), fediconsChecking()), $(".multiDC_info").hover(function() {
            loadTooltipPosition(), $(".up-arrow").show()
        }, function() {
            $(".up-arrow").hide()
        }), $(".up-arrow").hover(function() {
            $(".up-arrow").show()
        }, function() {
            $(".up-arrow").hide()
        }), clearInterval(_time), reload_page = setInterval(checkCookie, 5e3), isMobileonly = !1, !isMobile && enableServiceBasedBanner ? loadRightBanner() : hiderightpanel(), !isPreview) {
        if (setCookie(24), -1 == document.cookie.indexOf("IAM_TEST_COOKIE")) return $(".signin_container,#signuplink,.banner_newtoold").hide(), $("#enableCookie").show(), !1;
        setCookie(0), $("#enableCookie").hide()
    }
    if (!isValid(loginID) && trySmartSignin && localStorage && localStorage.getItem("isZohoSmartSigninDone")) return openSmartSignInPage(), !1;
    if ("true" === isCaptchaNeeded && (changeHip(), $("#captcha_container").show(), $("#login_id").attr("tabindex", 1), $("#captcha").attr("tabindex", 2), $("#nextbtn").attr("tabindex", 3), $("#captcha").focus()), digest && isValid(digest)) {
        $(".Notyou").hide();
        var loginurl = uriPrefix + "/signin/v2/lookup/" + euc(digest) + "?mode=digest";
        sendRequestWithCallback(loginurl, signinParams, !0, handleLookupDetails)
    }
    emailOnlySignin || (isValid(reqCountry) && (reqCountry = "#" + reqCountry.toUpperCase(), $("#country_code_select option:selected").removeAttr("selected"), $("#country_code_select " + reqCountry).attr("selected", !0), $("#country_code_select " + reqCountry).trigger("change")), isValid(CC) && $("#country_code_select").val($("#" + CC).val()), $(".select_country_code").text($("#country_code_select").val()), !isMobile || rendermovileUV ? (renderUV("#country_code_select", !0, "#login_id", "left", "flagIcons", !0, !0, "country_implement", rendermovileUV ? !0 : !1, "data-num", "value", "data-num"), show_CC_onload || $(".select_container--country_implement").hide(), $(".country_code_select .selectbox").append($("<span>").addClass("closeCountryCode"))) : (mobileflag(), $("<span class='closeCountryCode'></span>").insertBefore(".arrow_position"), hideUVFlag && $(".country_code_close .mobileFlag").css("margin-inline-start", "0px")), $(".closeCountryCode").click(function() {
        event.stopPropagation(), hideCountryCode()
    }), checking(), $("#select2-country_code_select-container").html($("#country_code_select").val()), $("#country_code_select").change(function() {
        return $(".country_code").html($("#country_code_select").val()), $("#select2-country_code_select-container").html($("#country_code_select").val()), $("#login_id").removeClass("textindent62"), $("#login_id").removeClass("textindent70"), $("#login_id").removeClass("textintent52"), $("#login_id").removeClass("textindent42"), checkTestIndent(), $(".select2-search__field").attr("placeholder", I18N.get("IAM.SEARCHING")), isMobile && $(".select_country_code").is(":visible") ? ($("#login_id").addClass(hideUVFlag ? "textindent70" : "textindent62"), !1) : void 0
    }))
}

function changeSecDevice(elem) {
    if ($(elem).children("option:selected").val() == prevoption) return !1;
    isOauPopupClosed = !1, isMobile && mobile_view_Device(), prevoption = $(elem).children("option:selected").val();
    var version = $(elem).children("option:selected").attr("version"),
        device_index = $(elem).children("option:selected").val();
    "1.0" === version ? oadevicepos = device_index : mzadevicepos = device_index, "1.0" === version ? enableOneauthDevice() : enableMyZohoDevice(), hideTryanotherWay(), "1.0" == version && $(".tryanother").hide()
}

function checkTestIndent() {
    return $(".select_container--country_implement").is(":visible") ? (uvselect.setIntentForCntyCode("country_code_select"), !1) : void 0
}

function loadRightBanner() {
    var action = "/signin/v2/banner";
    "undefined" != typeof contextpath && (action = contextpath + action), $.ajax({
        url: action,
        data: signinParams,
        success: function(resp) {
            handleRightBannerDetails(resp)
        },
        headers: {
            "Content-Type": "application/x-www-form-urlencoded;charset=UTF-8",
            "X-ZCSRF-TOKEN": csrfParam + "=" + euc(getCookie(csrfCookieName))
        }
    })
}

function handleRightBannerDetails(resp) {
    var rightboxHtml = $(".rightside_box").html();
    if (IsJsonString(resp) && (resp = JSON.parse(resp)), $(".overlapBanner").remove(), 1 === resp.banner[0].template.length) $(".rightside_box").html(rightboxHtml + "<div id='overlapBanner' class='overlapBanner' " + resp.banner[0].template + "</div>"), mfaBanner || ($(".mfa_panel").hide(), $(".overlapBanner").show());
    else if (resp.banner[0].template.length > 1) {
        var count, dottedHtml = bannerHtml = "",
            bannerDetails = resp.banner[0].template;
        bannerDetails.forEach(function(data, index) {
            bannerHtml += 0 != index ? "<div id='banner_" + index + "' class='rightbanner rightbannerTransition slideright' >" + data + "</div>" : "<div id='banner_" + index + "' class='rightbanner rightbannerTransition' >" + data + "</div>", dottedHtml += "<div class='dot' id='dot_" + index + "'><div></div></div>", count = index + 1
        }), $(".rightside_box").html(rightboxHtml + "<div id='overlapBanner' class='overlapBanner' style='width:300px'>" + bannerHtml + "</div><div class='dotHead'>" + dottedHtml + "</div>"), $(".banner1_href").text(I18N.get("IAM.TFA.LEARN.MORE")), mfaBanner || ($(".mfa_panel").hide(), $(".overlapBanner,.dotHead").show()), $("#dot_0").attr("selected", !0), bannerCount = count, handleRightBannerAnimation()
    } else hiderightpanel()
}

function handleRightBannerAnimation() {
    bannerPosition = 0, bannerTimer = setInterval(function() {
        changeBanner(!1), bannerPosition++, bannerPosition >= bannerCount && (bannerPosition = 0)
    }, 5e3), $("#overlapBanner").on({
        click: function() {
            removeRightBannerAnimation()
        },
        mouseenter: function() {
            holdRightBannerAnimation()
        },
        mouseleave: function() {
            resumeRightBannerAnimation()
        }
    }), $(".dot").on("click", function() {
        callBannerFromDot(this.attributes.id.value.split("dot_")[1])
    })
}

function removeRightBannerAnimation() {
    isBannerOnHold && resumeRightBannerAnimation(), clearInterval(bannerTimer), clearTimeout(resumeBannerIn), $("#overlapBanner").off("mouseenter").off("mouseleave").off("click"), $(".dot[selected=selected] div").css({
        transition: "opacity 0s ease-in-out,transform 0.3s linear",
        background: "#00a2f6"
    })
}

function holdRightBannerAnimation() {
    if (isBannerOnHold) return !1;
    clearInterval(bannerTimer), clearTimeout(resumeBannerIn), isBannerOnHold = !0;
    var selectedDotDiv = $(".dot[selected=selected] div");
    selectedDotDiv.css("transform", selectedDotDiv.css("transform"));
    var dotTransformation = selectedDotDiv.css("transform");
    balanceBannerTime = Math.round(5 - 5 * dotTransformation.split("matrix(")[1].split(",")[0]), selectedDotDiv.css({
        transition: "opacity .3s ease-in-out,transform " + balanceBannerTime + "s linear",
        background: "#4E5BBE"
    })
}

function resumeRightBannerAnimation() {
    return !isBannerOnHold || isBannerHardPaused ? !1 : (isBannerOnHold = !1, $(".dot[selected=selected] div").css("transform", "scaleX(1)"), $(".dot div").css("background", "#00a2f6"), void(resumeBannerIn = setTimeout(function() {
        changeBannerAndSetInterval()
    }, parseInt(1e3 * balanceBannerTime))))
}

function changeBannerAndSetInterval() {
    changeBanner(!1), bannerPosition++, bannerPosition >= bannerCount && (bannerPosition = 0), bannerTimer = setInterval(function() {
        changeBanner(!1), bannerPosition++, bannerPosition >= bannerCount && (bannerPosition = 0)
    }, 5e3)
}

function changeBanner(elem, isNoAnimation) {
    $(".dot[selected=selected] div").css({
        transition: "opacity .3s ease-in-out,transform 0s linear",
        transform: "scaleX(0)"
    }), bannerPosition = void 0 != bannerPosition ? bannerPosition : parseInt(elem.getAttribute("bannerposition")), $(".rightbanner").addClass("slideright"), bannerPosition === bannerCount - 1 ? $("#banner_0").removeClass("slideright") : $("#banner_" + (bannerPosition + 1)).removeClass("slideright"), $("#banner_" + bannerPosition).addClass("slideright");
    var dotPosition = bannerPosition === bannerCount - 1 ? 0 : bannerPosition + 1;
    $(".dot").attr("selected", !1), $("#dot_" + dotPosition).attr("selected", !0);
    var selectedDotDiv = $(".dot[selected=selected] div");
    isNoAnimation ? selectedDotDiv.css("transition", "opacity 0s ease-in-out,transform 0s linear") : selectedDotDiv.css("transition", "opacity .3s ease-in-out,transform 5s linear"), selectedDotDiv.css("transform", "scaleX(1)")
}

function callBannerFromDot(position) {
    removeRightBannerAnimation(), isBannerOnHold = !1, bannerPosition = 0 == position ? bannerCount - 1 : position - 1, clearInterval(bannerTimer), clearTimeout(resumeBannerIn), changeBanner(!1, !0)
}

function hiderightpanel() {
    $(".signin_container").css("maxWidth", "500px"), $(".rightside_box").hide(), $("#recoverybtn, #problemsignin, .tryanother,.contactSupport").css("right", "0px")
}

function format(option) {
    var spltext;
    if (!option.id) return option.text;
    spltext = option.text.split("(");
    var cncode = $(option.element).attr("data-num"),
        cnnumber = $(option.element).attr("value"),
        cnnum = cnnumber.substring(1),
        flagcls = "flag_" + cnnum + "_" + cncode,
        ob = '<div class="pic ' + flagcls + '" ></div><span class="cn">' + spltext[0] + "</span><span class='cc'>" + cnnumber + "</span>";
    return ob
}

function handleRequestCountryCode(resp) {
    IsJsonString(resp) && (resp = JSON.parse(resp)), resp.isd_code && (reqCountry = resp.country_code, reqCountry = "#" + reqCountry.toUpperCase(), $("#country_code_select option:selected").removeAttr("selected"), $("#country_code_select " + reqCountry).attr("selected", !0), $("#country_code_select " + reqCountry).trigger("change"), $("#login_id").removeClass("textindent62"), $("#login_id").removeClass("textindent70"), $("#login_id").removeClass("textintent52"), $("#login_id").removeClass("textindent42"))
}

function checking() {
    var a = $("#login_id").val().trim(),
        check = /^(?:[0-9] ?){0,1000}[0-9]$/.test(a),
        isDomainList = Boolean("undefined" != typeof isValidOrg && "undefined" != typeof orgDomainList && isValidOrg && orgDomainList);
    if ($(".select2-selection--single").attr("tabindex", "-1"), !isCountrySelected) {
        var reqUrl = uriPrefix + "/accounts/public/api/locate?" + signinParams;
        sendRequestWithCallback(reqUrl, "", !0, handleRequestCountryCode), isCountrySelected = !0
    }
    if (1 == check && a && !hiddenCountrycode) try {
        $(".select_container--country_implement").show(), checkTestIndent(), $(".selection").addClass("showcountry_code"), isMobile && !rendermovileUV ? ($(".MobflagContainer").show(), $(".select_country_code,#country_code_select").show(), $("#login_id").addClass(hideUVFlag ? "textindent70" : "textindent62")) : $(".select2").show(), $(".showCountryCode").slideUp(200), isDomainList && handleDomainChange(!0)
    } catch (err) {
        $(".select_country_code,#country_code_select").css("display", "block"), $("#login_id").addClass(hideUVFlag ? "textindent70" : "textindent62")
    } else 0 != check || show_CC_onload || (isDomainList && enableDomain(), $(".MobflagContainer").hide(), $("#login_id").removeClass("textindent62"), $("#login_id").removeClass("textindent70"), $(".select_country_code,#country_code_select,.select2").hide(), removeUVindent(), $(".select_container--country_implement").hide(), hiddenCountrycode && ($(".showCountryCode").slideUp(100), numericEditCounts = 0));
    hiddenCountrycode && (check ? (a && numericEditCounts++, numericEditCounts >= 3 && $(".showCountryCode").slideDown(200)) : $(".showCountryCode").slideUp(100)), isMobile || $(".domainselect").is(":visible") || $("#portaldomain .select2").css("display", "block")
}

function removeUVindent() {
    $(".select_container--country_implement ~ input").removeClass("uvtextindent0 uvtextindent2 uvtextindent3 uvtextindent4"), $(".select_container--country_implement").is(":visible") && $(".select_container--country_implement ~ input").attr("style", "text-indent:10px")
}

function IsJsonString(str) {
    try {
        $.parseJSON(str)
    } catch (e) {
        return !1
    }
    return !0
}

function getCookie(cookieName) {
    for (var nameEQ = cookieName + "=", ca = document.cookie.split(";"), i = 0; i < ca.length; i++) {
        var c = ca[i].trim();
        if (0 == c.indexOf(nameEQ)) return c.substring(nameEQ.length, c.length)
    }
    return null
}

function clearCommonError(field) {
    var container = field + "_container";
    $("#" + field).removeClass("errorborder"), $("#" + container + " .fielderror").slideUp(100), $("#" + container + " .fielderror").removeClass("errorlabel"), $("#" + container + " .fielderror").text("")
}

function clearFieldValue(fieldvalue) {
    $("#" + fieldvalue).val("")
}

function resetForm(isfromIP) {
    PriotpThreshold = 3, isfromIP && enableServiceBasedBanner && ($(".signin_container").css("maxWidth", ""), $(".rightside_box").show(), $("#recoverybtn, #problemsignin, .tryanother,.contactSupport").css("right", "")), $("#nextbtn,#otp").css("pointer-events", "auto"), $("#signuplink").show(), $("#resendotp, #blueforgotpassword").removeAttr("style"), $("#login_id_container").slideDown(200), $("#captcha_container,.textbox_actions,#mfa_device_container,#backupcode_container,#recoverybtn,#waitbtn,.textbox_actions_more,#openoneauth,.textbox_actions_saml,#problemsignin,.nopassword_container,.externaluser_container,.resetIP_container,#continuebtn, #qrOneContent, #qrOrLine,#mfa_totp_container,#contactSupport, #mfa_otp_container, #mfa_email_container, #mfa_totp_container, #mfa_scanqr_container").hide(), $(".signin_box").css("height", ""), $("#password_container").addClass("zeroheight"), $("#password_container,#otp_container").slideUp(200), $("#forgotpassword,#nextbtn,#password_container .textbox_div,#login_id").show(), $("#smartsigninbtn").removeClass("hide"), $(".fed_div_text span").text(""), $(".facebook_fed").removeClass("fed_div_text"), $(".signin_fed_text").show(), $("#login, .signin_head, #headtitle, .service_name, .fieldcontainer, .fieldcontainer .hellouser").show(), $("#goto_resetIP, #alternate_verification_info").hide(), $("#nextbtn span").text(I18N.get("IAM.NEXT")), $(".backbtn,.open_redirection_container").hide(), $(".fielderror").removeClass("errorlabel"), $("input").removeClass("errorborder"), $(".fielderror").text(""), $(".nopassword_container").removeAttr("style");
    var userId = $("#login_id").val().trim();
    if ($("#fed_signin_options, #problemsigninui, #AMFAemail_container").html(""), $("#problemsignin_container, #domain_btn, #AMFAownership_container").hide(), $(".select2-selection__arrow").removeClass("hide"), $(".showmoresigininoption").off("click"), $(".showmoresigininoption").on("click", function() {
            showmoresigininoption()
        }), $(".showmoresigininoption").text(I18N.get("IAM.NEW.SIGNIN.TRY.ANOTHERWAY")), changeButtonAction(I18N.get("IAM.NEXT"), !1), !emailOnlySignin && -1 != userId.indexOf("-")) {
        var phoneId = userId.split("-");
        isPhoneNumber(phoneId[1]) && ($("#login_id").val(phoneId[1]), $("#select2-country_code_select-container").html("+" + phoneId[0]), $("#country_code_select").val("+" + phoneId[0]), checking())
    }
    return $(".zoho_logo").removeClass("applycenter"), $("#headtitle").html(I18N.get("IAM.SIGN_IN")), $(".service_name").removeClass("extramargin"), $("#login_id_container .textbox_div").show(), $(".service_name").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.SERVICE.NAME.TITLE"), displayname)), isMobile || $(".line").show(), $(".fed_2show,#signuplink,#showIDPs,.banner_newtoold,.show_fed").show(), de("forgotpassword") && $("#forgotpassword").removeClass("nomargin"), de("password").value = "", $("#login_id").focus(), isFormSubmited = isPasswordless = isShowEnableMore = isLdapVisible = isOauPopupClosed = !1, emailposition = mobposition = void 0, $(".blueforgotpassword, .resendotp").addClass("bluetext_action_right"), $("#forgotpassword").removeClass("bluetext_action_right"), signinathmode = "lookup", callmode = "primary", $("#login_id_container .textbox_div").show(), $(".fed_div").length < 1 ? $(".fed_2show").hide() : fediconsChecking(), isClientPortal ? !1 : (de("otp").value = "", void(emailOnlySignin || (isMobile && userId && isPhoneNumber(userId.split("-")[1]) ? $("#country_code_select").val("+" + userId.split("-")[0]).change() : userId && isPhoneNumber(userId.split("-")[1]) && ($("#country_code_select").uvselect("destroy"), $("#country_code_select").val("+" + userId.split("-")[0]), renderUV("#country_code_select", !0, "#login_id", "left", "flagIcons", !0, !0, "country_implement", void 0, "data-num", "value", "data-num")))))
}

function switchto(url) {
    if (clearTimeout(reload_page), 0 != url.indexOf("http")) {
        var serverName = window.location.origin;
        window.location.origin || (serverName = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : "")), 0 != url.indexOf("/") && (url = "/" + url), url = serverName + url
    }
    return isClientPortal && load_iframe ? (window.location.href = url, !1) : void(window.top.location.href = url)
}

function showAndGenerateOtp(enablemode, captchavalue) {
    return prev_showmode = enablemode = void 0 != enablemode ? enablemode : -1 != allowedmodes.indexOf("email") ? "email" : "otp", "undefined" != typeof enablemode && (emobile = "email" === enablemode ? deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].e_email : deviceauthdetails[deviceauthdetails.resource_name].modes.otp.data[0].e_mobile, rmobile = "email" === enablemode ? deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].email : identifyEmailOrNum(deviceauthdetails[deviceauthdetails.resource_name].modes.otp.data[0].r_mobile, !0)), isPasswordless && $(".service_name").html(formatMessage(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.OTP"), rmobile)), isEmailVerifyReqiured && "email" == enablemode ? (checkEmailOTPInitiate(), !1) : (generateOTP(!1, enablemode, captchavalue), !1)
}

function showOtpDetails() {
    $("#password_container,#mfa_totp_container").hide();
    deviceauthdetails && deviceauthdetails.lookup.loginid ? deviceauthdetails.lookup.loginid : de("login_id").value;
    if ($(".textbox_actions").show(), showSigninUsingFedOption(), isShowEnableMore && (isShowEnableMore = !1, $("#enablemore").show(), $(".textbox_actions").hide(), $(".textbox_actions,.blueforgotpassword").hide(), goBackToCurrentMode(!0)), isPasswordless && oaNotInstalled && $(".service_name").html(formatMessage(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.OTP"), rmobile)), $("#otp").val(""), $("#otp_container .username").text(identifyEmailOrNum()), isClientPortal || enableSplitField("otp", otp_length, I18N.get("IAM.VERIFY.CODE")), $("#otp_container").show(), $("#captcha_container,#enableforgot").hide(), isClientPortal ? $("#otp").focus() : $("#otp").click(), changeButtonAction(I18N.get("IAM.NEW.SIGNIN.VERIFY"), !1), isPasswordless && ($("#signinwithpass,#enableoptionsoneauth").hide(), $(".signin_head").css("margin-bottom", "10px"), $("#nextbtn span").text(I18N.get("IAM.SIGN_IN")), $(".username").text(identifyEmailOrNum()), resendotp_checking(), isRecovery || allowedModeChecking(), $("#problemsignin,#recoverybtn,.tryanother").hide(), $("#enablemore #resendotp").show(), $("#enablemore #blueforgotpassword").hide(), secondarymodes.length > 1 && $(".otp_actions").hide(), isPasswordless)) {
        var showingmodes = secondarymodes;
        return 3 == showingmodes.length ? (-1 != showingmodes.indexOf("password") ? $("#signinwithpass").show() : $("#signinwithpass").hide(), -1 != showingmodes.indexOf("ldap") ? $("#signinwithldappass").show() : $("#signinwithldappass").hide(), $(".otp_actions").show(), $("#enablemore").hide()) : ($("#enableoptionsoneauth").hide(), -1 != allowedmodes.indexOf("totp") && "totp" != prev_showmode ? $("#signinwithtotponeauth").css("display", "block") : $("#signinwithtotponeauth").hide(), -1 != allowedmodes.indexOf("password") ? $("#signinwithpassoneauth").css("display", "block") : $("#signinwithpassoneauth").hide(), -1 != allowedmodes.indexOf("otp") ? $("#signinwithotponeauth").css("display", "block") : $("#signinwithotponeauth").hide(), -1 != allowedmodes.indexOf("email") ? $("#passlessemailverify").css("display", "block") : $("#passlessemailverify").hide(), -1 != allowedmodes.indexOf("ldap") ? $("#signinwithldaponeauth").css("display", "block") : $("#signinwithldaponeauth").hide(), -1 != allowedmodes.indexOf("otp") ? $("#signinwithotponeauth").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.PASSWORDLESS.OTP.VERIFY.TITLE"), identifyEmailOrNum(deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].r_mobile, !0))) : "", -1 != allowedmodes.indexOf("email") ? $("#passlessemailverify").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.PASSWORDLESS.EMAIL.VERIFY.TITLE"), deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].email)) : "", "otp" == prev_showmode && $("#signinwithotponeauth").hide(), "email" == prev_showmode && $("#passlessemailverify").hide()), !1
    }
}

function showPassword(isLdapPassword) {
    $("#password").val(""), clearCommonError("password"), $("#password_container .textbox_div").show(), $("#password_container").removeClass("zeroheight"), $("#otp_container").slideUp(300), $("#password_container").slideDown(300), $("#mfa_totp_container").hide(), changeButtonAction(I18N.get("IAM.SIGN_IN"), !1), $(".mobile_message").hide(), $(".service_name").show(), $("#captcha_container").hide(), $("#password").focus(), isLdapPassword ? (signinathmode = "ldappasswordauth", $(".blueforgotpassword").hide(), prev_showmode = "ldap", $("#password").attr("placeholder", I18N.get("IAM.LDAP.PASSWORD.PLACEHOLDER")), isLdapVisible = !0, $("#enableldap").hide()) : ($("#signinwithldappass").show(), signinathmode = "passwordauth", prev_showmode = "password", $("#password").attr("placeholder", I18N.get("IAM.NEW.SIGNIN.PASSWORD")), isLdapVisible = !1, $("#blueforgotpassword").show(), $("#enablepass").hide());
    var mode = isLdapPassword ? "ldap" : "password";
    if (isPasswordless || fallBackForSingleMode(mode, validateAllowedMode(mode).option), isPasswordless) {
        oaNotInstalled && $(".service_name").html(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.PASSWORD")), $("#enableotpoption,#enablesaml,#enablejwt,#enablemore .resendotp,#enableoptionsoneauth,#signinwithpassoneauth").hide();
        var showingmodes = secondarymodes;
        3 == showingmodes.length ? isLdapPassword ? (-1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enableotpoption").show() : -1 != showingmodes.indexOf("password") ? $("#enablepass").show() : $("#enablepass").hide(), -1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enablepass").hide() : "") : -1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enableotpoption").show() : -1 != showingmodes.indexOf("ldap") ? $("#enableldap").show() : "" : showingmodes.length > 3 && $("#enablemore").show()
    } else isLdapPassword ? 2 == btnAllowedModes() && (-1 == allowedmodes.indexOf("password") ? $("#enablepass").hide() : ($("#enablepass").show(), $("#enablemore").hide()), $("#signinwithldappass").hide()) : 2 == btnAllowedModes() ? ($("#enablepass").hide(), -1 == allowedmodes.indexOf("ldap") ? $("#enableldap").hide() : ($("#enableldap").show(), $("#enablemore").hide())) : 1 == btnAllowedModes() && -1 != allowedmodes.indexOf("password") && $("#enableforgot").show();
    showSigninUsingFedOption()
}

function showTryanotherWay() {
    if (showHideEnforcePop(!1), clearInterval(_time), clearTimeout(oneauthgrant), clearCommonError("yubikey"), $(".optionmod").show(), isMobileonly && "mzadevice" === prev_showmode) return $(".signin_container").addClass("mobile_signincontainer"), $("#try" + prefoption).hide(), $(".blur").show(), $(".blur").addClass("dark_blur"), allowedModeChecking_mob(), !1;
    $(".signin_head").css("margin-bottom", "10px"), $(".addaptivetfalist,.borderlesstry,#trytitle").show(), $("#nextbtn,.service_name,.fieldcontainer,#headtitle,#problemsignin,#recoverybtn_mob,#problemsignin_mob,.verify_title,.tryanother,#totpverifybtn .loadwithbtn").hide(), $("#trytitle").html("<span class='icon-backarrow backoption trytitlebackop'></span>" + I18N.get("IAM.NEW.SIGNIN.TRY.ANOTHERWAY.HEADER"));
    var preferoption = deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[mzadevicepos].prefer_option;
    return $("#verify_totp_container, #verify_qr_container").hide(), "totp" === preferoption && $("#trytotp").hide(), "scanqr" === preferoption && $("#tryscanqr").hide(), tryAnotherway("totp" === preferoption ? "qr" : "totp"), isRecovery || allowedModeChecking(), isTroubleSignin = !0, $(".trytitlebackop").on("click", function() {
        hideTryanotherWay()
    }), !1
}

function allowedModeChecking_mob() {
    return $(".addaptivetfalist").addClass("heightChange"), $("#recoverybtn,#recoverybtn_mob,#recoverybtn_mob,#recoverybtn").hide(), -1 != allowedmodes.indexOf("recoverycode") ? $("#recoverOption").show() : $("#recoverOption").hide(), isSecondary = deviceauthdetails[deviceauthdetails.resource_name].modes.otp && deviceauthdetails[deviceauthdetails.resource_name].modes.otp.count > 1 ? !0 : isSecondary, isSecondary ? $("#problemsignin_mob").show() : $("#recoverybtn_mob").show(), isSecondary ? $("#recoverybtn_mob").hide() : $("#problemsignin_mob").hide(), !1
}

function showmzadevicemodes() {
    $(".devices").css("display", ""), showTryanotherWay(), $("#problemsigninui,#recoverybtn, #problemsignin_container").hide(), isRecovery || allowedModeChecking()
}

function showproblemsignin(isBackup, optionUI, neednoremove) {
    isTroubleSignin = !1;
    var emailAdded, otpAdded = !1;
    clearTimeout(oneauthgrant), showHideEnforcePop(!1), $("#login,.backuphead").show(), isValid($(".username").text()) ? $("#problemsignin_container .hellouser").show() : $("#problemsignin_container .hellouser").hide(), hideOABackupRedirection(), $(".devices,.devicedetails,#alternate_verification_info,#recovery_container").hide(), clearInterval(_time), $(".signin_container").removeClass("mobile_signincontainer"), window.setTimeout(function() {
        $(".blur").hide(), $(".blur").removeClass("dark_blur")
    }, 100), isMobileonly ? $(".addaptivetfalist").removeClass("heightChange") : $(".addaptivetfalist").hide(), $("#trytitle").html("");
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
    neednoremove || (secondarymodes.splice(secondarymodes.indexOf(prev_showmode), 1), secondarymodes.unshift(prev_showmode));
    var i18n_content = {
            totp: ["IAM.NEW.SIGNIN.VERIFY.VIA.AUTHENTICATOR", "IAM.NEW.SIGNIN.VERIFY.VIA.AUTHENTICATOR.DESC"],
            otp: ["IAM.NEW.SIGNIN.SMS.MODE", "IAM.NEW.SIGNIN.OTP.HEADER"],
            yubikey: ["IAM.NEW.SIGNIN.VERIFY.VIA.YUBIKEY", "IAM.NEW.SIGNIN.VERIFY.VIA.YUBIKEY.DESC"],
            password: ["IAM.PASSWORD.VERIFICATION", "IAM.NEW.SIGNIN.MFA.PASSWORD.DESC"],
            saml: ["IAM.NEW.SIGNIN.SAML.TITLE", "IAM.NEW.SIGNIN.SAML.HEADER"],
            jwt: ["IAM.NEW.SIGNIN.JWT.TITLE", "IAM.NEW.SIGNIN.SAML.HEADER"],
            email: ["IAM.NEW.SIGNIN.EMAIL.TITLE", "IAM.NEW.SIGNIN.OTP.HEADER"]
        },
        i18n_recover = {
            otp: ["IAM.AC.CHOOSE.OTHER_MODES.MOBILE.HEADING", "IAM.NEW.SIGNIN.OTP.HEADER"],
            email: ["IAM.AC.CHOOSE.OTHER_MODES.EMAIL.HEADING", "IAM.NEW.SIGNIN.OTP.HEADER"],
            domain: ["IAM.AC.CHOOSE.OTHER_MODES.DOMAIN.HEADING", "IAM.AC.CHOOSE.OTHER_MODES.DOMAIN.DESCRIPTION"]
        },
        jsonPackage = deviceauthdetails[deviceauthdetails.resource_name],
        headingcontent = jsonPackage.isAMFA ? allowedmodes.length > 1 && optionUI ? "IAM.AMFA.PROBLEM.SIGNIN.HEADING" : "IAM.SIGNIN.AMFA.VERIFICATION.HEADER" : "IAM.NEW.SIGNIN.PROBLEM.SIGNIN",
        problemsigninheader = "<div class='problemsignin_head'><span class='icon-backarrow backoption backproblemsigninelem'></span><span class='rec_head_text'>" + I18N.get(headingcontent) + "</span></div>",
        allowedmodes_con = "",
        noofmodes = 0;
    if (("mzadevice" == prev_showmode || neednoremove) && !jsonPackage.isAMFA) var problemsigninheader = "<div class='problemsignin_head'><div class='oa_head_text'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY") + "</div><div class='oa_head_con'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY.DESC") + "</div></div>";
    jsonPackage.isAMFA && (problemsigninheader = problemsigninheader + "<div class='oa_head_con margin12'>" + I18N.get("IAM.AMFA.PROBLEM.SIGNIN.DESC") + "</div>");
    var i18n_msg = jsonPackage.isAMFA ? i18n_recover : i18n_content;
    if (isPasswordless || $(".problemsignincon").html(""), secondarymodes.forEach(function(prob_mode, position) {
            var listofmob = jsonPackage.modes.otp && jsonPackage.modes.otp.data;
            isValid(listofmob) && listofmob.length > 1 && 0 === position && "otp" === prob_mode && !optionUI && (otpAdded = !0, listofmob.forEach(function(data, index) {
                if (index != mobposition || neednoremove) {
                    var tempRmobile = identifyEmailOrNum(data.r_mobile, !0),
                        secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                        secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile);
                    allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                }
            }));
            var listofemail = jsonPackage.modes.email && jsonPackage.modes.email.data;
            if (listofdomain = jsonPackage.modes.domain && jsonPackage.modes.domain.data, isValid(listofemail) && listofemail.length > 1 && 0 === position && "email" === prob_mode && !optionUI && (emailAdded = !0, listofemail.forEach(function(data, index) {
                    if (index != emailposition || neednoremove) {
                        var tempRmobile = data.email,
                            secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                            secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile);
                        allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                    }
                })), 0 != position || isBackup || optionUI)
                if ("recoverycode" != prob_mode && "passphrase" != prob_mode) {
                    if ("oadevice" === prob_mode) {
                        var oadevice_modes = jsonPackage.modes.oadevice.data;
                        oadevice_modes.forEach(function(data, index) {
                            var oadevice_option = data.prefer_option,
                                device_name = data.device_name,
                                oneauthmode = "ONEAUTH_PUSH_NOTIF" === oadevice_option ? "push" : "ONEAUTH_TOTP" === oadevice_option ? "totp" : "ONEAUTH_SCAN_QR" === oadevice_option ? "scanqr" : "ONEAUTH_FACE_ID" === oadevice_option ? "faceid" : "ONEAUTH_TOUCH_ID" === oadevice_option ? "touchid" : "",
                                secondary_header = I18N.get("IAM.NEW.SIGNIN.VERIFY.VIA.ONEAUTH"),
                                secondary_desc = formatMessage(I18N.get("IAM.NEW.SIGNIN.VERIFY.VIA.ONEAUTH.DESC"), oneauthmode, device_name);
                            allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                        })
                    } else if ("mzadevice" === prob_mode) {
                        var mzadevice_modes = jsonPackage.modes.mzadevice.data;
                        mzadevice_modes.forEach(function(data, index) {
                            if (index != mzadevicepos && data.is_active) {
                                var mzadevice_option = data.prefer_option,
                                    device_name = data.device_name,
                                    secondary_header = I18N.get(deviceauthdetails[deviceauthdetails.resource_name].isAMFA ? "IAM.AC.CHOOSE.OTHER_MODES.DEVICE.HEADING" : "IAM.NEW.SIGNIN.VERIFY.VIA.ONEAUTH"),
                                    secondary_desc = formatMessage(I18N.get("IAM.NEW.SIGNIN.VERIFY.VIA.ONEAUTH.DESC"), mzadevice_option, device_name);
                                allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                            }
                        })
                    } else if ("otp" === prob_mode) otpAdded || listofmob.forEach(function(data, index) {
                        if (index != mobposition || neednoremove) {
                            var tempRmobile = identifyEmailOrNum(data.r_mobile, !0),
                                secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                                secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile);
                            allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                        }
                    });
                    else if ("email" === prob_mode) emailAdded || listofemail.forEach(function(data, index) {
                        if (index != emailposition || neednoremove) {
                            var tempRmobile = data.email,
                                secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                                secondary_desc = formatMessage(I18N.get(i18n_msg[prob_mode][1]), tempRmobile);
                            allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc, index), noofmodes++
                        }
                    });
                    else if ("domain" === prob_mode) {
                        var secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                            secondary_desc = I18N.get(i18n_msg[prob_mode][1]);
                        allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc), noofmodes++
                    } else if ("yubikey" === prob_mode) {
                        var secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                            secondary_desc = I18N.get(i18n_msg[prob_mode][1]);
                        allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc), noofmodes++
                    } else if ("federated" != prob_mode && "saml" != prob_mode && "oidc" != prob_mode && "jwt" != prob_mode && i18n_msg[prob_mode]) {
                        var secondary_header = I18N.get(i18n_msg[prob_mode][0]),
                            secondary_desc = I18N.get(i18n_msg[prob_mode][1]);
                        allowedmodes_con += problemsigninmodes(prob_mode, secondary_header, secondary_desc), noofmodes++
                    }
                } else "recoverycode" === prob_mode && $("#recoverOption").show()
        }), 0 >= noofmodes) return showCantAccessDevice(), !1;
    $("#problemsigninui").html(problemsigninheader + "<div class='problemsignincon'>" + allowedmodes_con + "</div>"), $(".tryanother").is(":visible") && $(".tryanother").hide(), noofmodes > 3 && !isMobile && !isBackup && $(".problemsignincon").addClass("problemsignincontainer"), $(".optionstry").addClass("optionmod"), isPasswordless ? $(".contactSupport").show() : $("#recoverybtn").show(), -1 == allowedmodes.indexOf("passphrase") && -1 == allowedmodes.indexOf("recoverycode") && ($(".contactSupport").show(), $("#recoverybtn").hide());
    allowedmodes[0];
    $("#problemsignin,#headtitle,.service_name,.fieldcontainer,#nextbtn").hide(), $("#problemsigninui, #problemsignin_container").show(), $(".backproblemsigninelem").on("click", function() {
        "mzadevice" !== prev_showmode || isMobileonly || isAMFA ? goBackToCurrentMode() : showmzadevicemodes()
    }), $(".showCurrentMode").on("click", function() {
        return "secondary_domain" === this.id ? (showAlterVerificationDomainInfo("domain"), !1) : void(isPasswordless && "mzadevice" != $(this).attr("mode") ? showAlterVerificationINfo($(this).attr("mode")) : showCurrentMode($(this).attr("mode"), parseInt($(this).attr("index"))))
    })
}

function problemsigninmodes(prob_mode, secondary_header, secondary_desc, index) {
    return "<div class='optionstry options_hover showCurrentMode' id='secondary_" + prob_mode + "' mode=" + prob_mode + " index=" + index + ">			<div class='img_option_try img_option icon-" + prob_mode + "'></div>			<div class='option_details_try'>				<div class='option_title_try'>" + secondary_header + "</div>				<div class='option_description'>" + secondary_desc + "</div>			</div>			</div>"
}

function showAlterVerificationDomainInfo(prob_mode) {
    return prob_mode = void 0 == prob_mode ? prev_showmode : prob_mode, $("#alternate_verification_info #headin_content").text(I18N.get("IAM.AC.SELECT.DOMAIN.MODE.HEADING")), $("#alternate_verification_info #headin_content").addClass("font20"), $("#oaalter_title_sec, #oaalter_title_first").hide(), $(".alterstep, .alterstep_con").show(), $("#alterverify_head .backoption").off(), $(".alterverify_head .backoption").on("click", function() {
        showproblemsignin(!0, !0, !0), $(".problemsignin_head .backoption").hide()
    }), $("#alterverify_desc").removeClass("margin12"), $("#alterverify_desc").html(I18N.get("IAM.SIGNIN.DOMAIN.ALTER.VERIFICATION.DECS")), $(".oaalter_con_first").html(I18N.get("IAM.AC.DOMAIN.MODE.STEP1")), $(".oaalter_con_sec").text(I18N.get("IAM.AC.DOMAIN.MODE.STEP2")), $(".oaalter_con_first, .oaalter_con_sec, .oaalter_con_third, .oaalter_con_fourth").addClass("domain_alterinfo"), $(".proceed_btn").text(I18N.get("IAM.CONTINUE")), $(".domain_step").show(), $(".alterstep").html(""), $(".alterstep").append('</div><div class="step1">1</div><div class="stepvertical"></div><div class="step2">2</div><div class="stepvertical"></div><div class="step3">3</div><div class="stepvertical"></div><div class="step4">4</div>'), $(".fieldcontainer, #login .signin_head").hide(), $(".devices,.devicedetails,#signin_box_info").hide(), $("#login_id,#mfa_totp_container,#mfa_otp_container,#mfa_email_container,#waitbtn,#nextbtn,#mfa_scanqr_container,#mfa_push_container,#openoneauth,#yubikey_container").hide(), clearInterval(_time), $("#contactSupport,#problemsigninui,#recoverybtn,#problemsignin_container").hide(), $("#alternate_verification_info").show(), $(".contactSupport").show(), $("#contactSupport").hide(), $(".AMFAdomain_container").hide(), $(".stepvertical").css("height", $(".alterstep_con div").height() - $(".step1").height() - 2 + "px"), prev_showmode = prob_mode, $(".proceed_btn").show(), $(".proceed_btn").off().on("click", function() {
        showDomainlist()
    }), oaNotInstalled = !0, $("#alternate_verification_info .hellouser").show(), !1
}

function showDomainlist() {
    $(".alterstep, .alterstep_con").hide(), $("#headin_content").text(I18N.get("IAM.AC.CHOOSE.DOMAIN")), $("#alterverify_desc").addClass("margin12"), $("#alterverify_desc").html(formatMessage(I18N.get("IAM.AC.CHOOSE.DOMAIN.DESCRIPTION"), listofdomain.length.toString())), $(".alterverify_head .backoption").off(), $(".alterverify_head .backoption").on("click", function() {
        showproblemsignin(!0, !0, !0), $(".problemsignin_head .backoption").hide()
    });
    var domain_content = "";
    listofdomain.forEach(function(domain, index) {
        domain_content += "<div class='verify_domains' data-position=" + index + "><div class='icon-domain domain_icon'></div><div class='domain_name'>" + domain.r_domain + "</div></div>"
    }), $(".AMFAdomain_container").show(), $(".AMFAdomain_container").html(domain_content), $(".AMFAownership").hide(), $(".proceed_btn, .contactSupport, #domain_btn").hide(), $(".verify_domains").off(), $(".verify_domains").on("click", function() {
        domainverifcation(this.attributes["data-position"].value)
    })
}

function domainverifcation(dataposition) {
    signinathmode = deviceauthdetails.resource_name;
    var r_domain = deviceauthdetails[signinathmode].modes.domain.data[dataposition ? dataposition : $("#AMFAdomain").attr("dataposition")].r_domain;
    temptoken = deviceauthdetails[signinathmode].token, $(".alterverify_head .backoption").off(), $(".alterverify_head .backoption").on("click", function() {
        showDomainlist()
    }), $("#domain_btn").text(I18N.get("IAM.NEXT")), $("#headin_content").text(I18N.get("IAM.AMFA.SIGNIN.FULL.DOMAIN")), $("#alterverify_desc").html(formatMessage(I18N.get("IAM.SIGNIN.FULL.DOMAIN.DECS"), r_domain)), $(".AMFAdomain_container").html(""), $(".AMFAdomain_container").append("<input class='fulldomain textbox' id='AMFAdomain' dataposition = " + dataposition + " placeholder='" + I18N.get("IAM.AC.ENTER.DOMAIN") + "'><div class='fielderror'></div>"), $("#domain_btn").show(), $("#full_domain").focus(), domainverification = !0
}

function AMFAemailverification(data) {
    $(".AMFAownership").hide(), $("#alterverify_desc").html(formatMessage(I18N.get("IAM.SIGNIN.AMFA.EMAIL.DESC"), AMFA_rdomain_resp, data.attributes.dataoption.value)), $("#domain_btn").text(I18N.get("IAM.AMFA.SEND.INSTRUCTIONS")), $("#headin_content").text(I18N.get("IAM.AC.ENTER.DOMAIN.CONTACT_ID.HEADING")), $(".AMFAemail_container").html(""), $(".AMFAemail_container").append("<input class='domainemail textbox' id='AMFAemail' placeholder='" + I18N.get("IAM.ENTER.EMAIL") + "' type='" + data.attributes.type.value + "'><div class='fielderror'></div>"), $("#domain_btn, .AMFAemail_container").show(), $(".alterverify_head .backoption").off(), $(".alterverify_head .backoption").on("click", function() {
        show_Domainownership()
    }), domainverification = !1
}

function show_Domainownership() {
    $("#AMFAownership_container, .AMFAemail_container").show(), $("#domain_btn, .AMFAemail_container").hide(), $("#headin_content").text(I18N.get("IAM.AC.ENTER.DOMAIN")), $("#alterverify_desc").html(formatMessage(I18N.get("IAM.SIGNIN.FULL.DOMAIN.DECS"), AMFA_rdomain_resp)), $(".alterverify_head .backoption").off(), $(".alterverify_head .backoption").on("click", function() {
        showDomainlist()
    })
}

function verifyDomain(frm) {
    var e_domain = isValid(AMFA_edomain_resp) ? AMFA_edomain_resp : deviceauthdetails[signinathmode].modes.domain.data[$("#AMFAdomain").attr("dataposition")].e_domain;
    if (domainverification) {
        var domain_val = frm.AMFAdomain && frm.AMFAdomain.value.trim();
        if (isValid(domain_val) && domainverification) {
            if (!/^(?:(?:(?:[a-zA-z\-]+)\:\/{1,3})?(?:[a-zA-Z0-9])(?:[a-zA-Z0-9\-\.]){1,61}(?:\.[a-zA-Z]{2,})+|\[(?:(?:(?:[a-fA-F0-9]){1,4})(?::(?:[a-fA-F0-9]){1,4}){7}|::1|::)\]|(?:(?:[0-9]{1,3})(?:\.[0-9]{1,3}){3}))(?:\:[0-9]{1,5})?$/.test(domain_val)) return showCommonError("AMFAdomain", I18N.get("IAM.AC.DOMAIN.INVALID.ERROR")), !1;
            $("#AMFAdomain").on("input", function() {
                clearCommonError("AMFAdomain")
            });
            var domain_url = uriPrefix + "signin/v2/secondary/" + zuid + "/domain/" + e_domain + "?" + signinParams,
                jsonData = {
                    domainsecauth: {
                        domain: domain_val
                    }
                };
            $("#domain_btn").addClass("changeloadbtn"), sendRequestWithTemptoken(domain_url, JSON.stringify(jsonData), !0, handleDomainresp, "POST")
        } else showCommonError("AMFAdomain", I18N.get("IAM.SIGNIN.FULL.DOMAIN.ERROR")), $("#domain_btn").removeClass("changeloadbtn");
        return !1
    }
    var email_val = frm.AMFAemail && frm.AMFAemail.value.trim();
    if ($("#AMFAemail").on("input", function() {
            clearCommonError("AMFAemail")
        }), isValid(email_val)) {
        if (!isEmailIdSignin(email_val)) return showCommonError("AMFAemail", I18N.get("IAM.ERROR.VALID.EMAIL")), $("#domain_btn").removeClass("changeloadbtn"), !1;
        var email_url = uriPrefix + "signin/v2/secondary/" + zuid + "/domain/" + e_domain + "?" + signinParams,
            jsonData = {
                domainsecauth: {
                    contact_mail: email_val,
                    type: $("#AMFAemail").attr("type")
                }
            },
            encryptionJson = {
                path: "domainsecauth.contact_mail",
                value: email_val
            };
        return $("#domain_btn").addClass("changeloadbtn"), sendRequestWithTemptoken(email_url, JSON.stringify(jsonData), !0, handleAMFAemailresp, "PUT", encryptionJson, email_val), !1
    }
    return showCommonError("AMFAemail", I18N.get("IAM.SIGNIN.FULL.DOMAIN.EMAIL.ERROR")), $("#domain_btn").removeClass("changeloadbtn"), !1
}

function handleAMFAemailresp(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        !isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode ? ($(".zoho_logo").addClass("logoCentre"), $("#AMFAemail, .alterverify_head").hide(), $(".AMFAemail_container").append("<div class='pptick_icon'></div><div class='AFMA_email_success'></div><div class='AFMA_email_success_decs'></div><div class='AFMA_email_success_decs1'></div>"), $(".AFMA_email_success").text(I18N.get("IAM.AC.DOMAIN.INSTRUCTION.HEADING")), $(".AFMA_email_success_decs").html(formatMessage(I18N.get("IAM.SIGNIN.AMFA.EMAIL.SENT.SUCCESS"), $("#AMFAemail").val())), $(".AFMA_email_success_decs1").text(I18N.get("IAM.SIGNIN.AMFA.EMAIL.SENT.SUCCESS2")), $("#domain_btn, .hellouser").hide(), $("#domain_btn").removeClass("changeloadbtn")) : (showCommonError("AMFAemail", jsonStr.localized_message), $("#domain_btn").removeClass("changeloadbtn"))
    } else showCommonError("AMFAemail", I18N.get("IAM.ERROR.GENERAL")), $("#domain_btn").removeClass("changeloadbtn");
    return !1
}

function handleDomainresp(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        !isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode ? ($("#headin_content").text(I18N.get("IAM.SIGNIN.VERIFY.DOMAIN.TITLE")), AMFA_rdomain_resp = jsonStr.domainsecauth.r_domain, AMFA_edomain_resp = jsonStr.domainsecauth.e_domain, $("#alterverify_desc").html(formatMessage(I18N.get("IAM.SIGNIN.VERIFIED.DOMAIN.DESC"), AMFA_rdomain_resp)), $("#AMFAdomain_container, #domain_btn").hide(), $("#AMFAownership_container").show(), $(".AMFA_verification_list").off(), $(".AMFA_verification_list").on("click", function() {
            AMFAemailverification(this)
        }), $("#domain_btn").removeClass("changeloadbtn")) : (showCommonError("AMFAdomain", jsonStr.localized_message), $("#domain_btn").removeClass("changeloadbtn"))
    } else showCommonError("AMFAdomain", I18N.get("IAM.ERROR.GENERAL")), $("#domain_btn").removeClass("changeloadbtn");
    return !1
}

function showAlterVerificationINfo(prob_mode) {
    return prob_mode = void 0 == prob_mode ? prev_showmode : prob_mode, $("#oaalter_title_sec, #oaalter_title_first").show(), $(".domain_step").hide(), $(".oaalter_con_first, .oaalter_con_sec, .oaalter_con_third, .oaalter_con_fourth").removeClass("domain_alterinfo"), $(".alterstep").html(""), $(".alterstep").append('</div><div class="step1">1</div><div class="stepvertical"></div><div class="step2">2</div>'), recoverymodes && -1 != recoverymodes.indexOf(prob_mode) ? ($("#oaalter_title_sec").text(I18N.get("IAM.NEWSIGNIN.VERIFY.SEC.FACTOR." + prob_mode.toUpperCase())), $(".oaalter_con_sec").text(I18N.get("IAM.NEWSIGNIN.VERIFY.SEC.FACTOR.DESC." + prob_mode.toUpperCase()))) : ($("#oaalter_title_sec").text(I18N.get("IAM.NEWSIGNIN.VERIFY.SEC.FACTOR.TITLE")), $(".oaalter_con_sec").text(I18N.get("IAM.NEWSIGNIN.VERIFY.SEC.FACTOR.DESC"))), $("#alterverify_head .backoption").on("click", function() {
        showproblemsignin(!0, !1, !0)
    }), $(".fieldcontainer .hellouser, .fieldcontainer, #login .signin_head").hide(), $(".devices,.devicedetails,#signin_box_info").hide(), $("#login_id,#mfa_totp_container,#mfa_otp_container,#mfa_email_container,#waitbtn,#nextbtn,#mfa_scanqr_container,#mfa_push_container,#openoneauth,#yubikey_container").hide(), clearInterval(_time), $("#contactSupport,#problemsigninui, #problemsignin_container").hide(), $("#alternate_verification_info").show(), $(".contactSupport").show(), $("#contactSupport").hide(), $(".stepvertical").css("height", $(".alterstep_con div").height() - $(".step1").height() + "px"), prev_showmode = prob_mode, $(".proceed_btn").off(), $(".proceed_btn").on("click", function() {
        showCurrentMode(prob_mode, 0, !0)
    }), oaNotInstalled = !0, !1
}

function backtoalterinfo() {
    return showproblemsignin(!0, !1, !0), deviceauthdetails[deviceauthdetails.resource_name].isAMFA ? showAlterVerificationDomainInfo() : showAlterVerificationINfo(), !1
}

function showallowedmodes(enablemode, mode_index) {
    $("#enablemore").show();
    var lastviewed_mode = prev_showmode;
    if (prev_showmode = "federated" === enablemode ? prev_showmode : enablemode, "saml" === enablemode) {
        $("#enablemore").hide(), $(".blur,.loader").show();
        var samlAuthDomain = deviceauthdetails.lookup.modes.saml.data[mode_index].auth_domain;
        return enableSamlAuth(samlAuthDomain), $(".blur,.loader").hide(), !1
    }
    if ("jwt" === enablemode) {
        $(".blur,.loader").show();
        var redirectURI = deviceauthdetails.lookup.modes.jwt.data[0].redirect_uri;
        return switchto(redirectURI), $(".blur,.loader").hide(), !1
    }
    if ("otp" === enablemode || "email" === enablemode) return isShowEnableMore = !0, $("#enablemore").hide(), emobile = "email" === enablemode ? deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].e_email : deviceauthdetails[deviceauthdetails.resource_name].modes.otp.data[0].e_mobile, rmobile = "email" === enablemode ? deviceauthdetails[deviceauthdetails.resource_name].modes.email.data[0].email : identifyEmailOrNum(deviceauthdetails[deviceauthdetails.resource_name].modes.otp.data[0].r_mobile, !0), deviceauthdetails[deviceauthdetails.resource_name].isUserName && "email" === enablemode ? (checkEmailOTPInitiate(), prev_showmode = lastviewed_mode, !1) : ($("#resendotp").show(), enableOTP(enablemode), !1);
    if ("totp" === enablemode) return isShowEnableMore = !0, enableTotpAsPrimary(), !1;
    if ("password" === enablemode || "ldap" === enablemode) {
        $("#enableotpoption,#resendotp").hide();
        var isLdapPassword = "ldap" == enablemode ? !0 : !1;
        showPassword(isLdapPassword), goBackToCurrentMode(!0)
    } else if ("federated" === enablemode) {
        var idp = deviceauthdetails.lookup.modes.federated.data[0].idp.toLowerCase();
        return 1 == mode_index ? createandSubmitOpenIDForm(idp) : showMoreFedOptions(), !1
    }
    return !1
}

function goBackToCurrentMode(isLookup) {
    $("#headtitle,.signin_head,.service_name,.fieldcontainer,#nextbtn").show(), $(".devices,.devicedetails").hide(), $("#problemsigninui,#recoverybtn, #problemsignin_container").hide(), "mzadevice" === prev_showmode ? $(".tryanother,.devices").show() : $(".rnd_container").hide();
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
    isAMFA && (allowedModeChecking(), $(".tryanother, #contactSupport").hide()), isLookup || $(".addaptivetfalist").is(":visible") || isRecovery || allowedModeChecking(), ($("#waitbtn").is(":visible") || $("#mfa_scanqr_container").is(":visible")) && $("#nextbtn").hide(), isClientPortal || "totp" != prev_showmode ? $("#" + prev_showmode).focus() : $("#mfa_totp").click()
}

function hideTryanotherWay(hideDevice) {
    $("#trytitle,.borderlesstry,#recoverybtn,#problemsignin,#verify_totp_container,#verify_qr_container,.contactSupport").hide(), isMobileonly ? $(".addaptivetfalist").removeClass("heightChange") : $(".addaptivetfalist").hide(), $(".service_name,.fieldcontainer,#headtitle").show(), prefoption = deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[mzadevicepos] ? deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[mzadevicepos].prefer_option : prefoption, "totp" === prefoption && $("#nextbtn").show(), $(".tryanother").show(), hideDevice ? $(".devices").hide() : $(".devices").show();
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA;
    return isAMFA && (allowedModeChecking(), $(".tryanother").hide()), $(".signin_container").removeClass("mobile_signincontainer"), window.setTimeout(function() {
        $(".blur").hide(), $(".blur").removeClass("dark_blur")
    }, 250), isTroubleSignin = !1, $("#verify_qrimg").attr("src", ""), !1
}

function showCaptcha(btnstatus, isSubmitted, submit_id) {
    if ($("#captcha_container").show(), clearCommonError("captcha"), changeButtonAction(btnstatus, isSubmitted), $("#" + submit_id).attr("tabindex", 1), $("#captcha").attr("tabindex", 2), $("#nextbtn").attr("tabindex", 3), isClientPortal) {
        var iFrame = parent.document.getElementById("zs_signin_iframe");
        iFrame && (iFrame.style.height = iFrame.contentWindow.document.body.scrollHeight + "px")
    }
    return $("#captcha").focus(), !1
}

function changeHip(cImg, cId) {
    cId = isValid(cId) ? cId : "captcha";
    var captchaReqUrl = uriPrefix + "/webclient/v1/captcha?",
        usecase = isSignupCaptcha ? "signup" : "signin";
    sendRequestWithCallback(captchaReqUrl, '{"captcha":{"digest":"' + cdigest + '","usecase":"' + usecase + '"}}', !1, handleChangeHip), de(cId).value = ""
}

function showHip(cdigest, cImg) {
    var captchimgsrc;
    if (isSignupCaptcha) captchimgsrc = isValid(cdigest) ? captchaPrefix + "/showcaptcha?digest=" + cdigest : "../v2/components/images/hiperror.gif";
    else {
        var captcha_resp = isValid(cdigest) ? doGet(uriPrefix + "/webclient/v1/captcha/" + cdigest, "darkmode=" + Boolean(isDarkMode)) : "";
        IsJsonString(captcha_resp) && (captcha_resp = JSON.parse(captcha_resp)), captchimgsrc = "throttles_limit_exceeded" !== captcha_resp.cause && isValid(cdigest) ? captcha_resp.captcha.image_bytes : "../v2/components/images/hiperror.gif"
    }
    cImg = $("#bcaptcha_img").is(":visible") ? "bcaptcha_img" : $("#verifycaptcha_img").is(":visible") ? "verifycaptcha_img" : "captcha_img";
    var inputField = $("#bcaptcha_img").is(":visible") ? "bcaptcha" : $("#verifycaptcha_img").is(":visible") ? "verifycaptcha" : "captcha";
    de(inputField).value = "";
    var hipRow = de(cImg),
        captchaImgEle = document.createElement("img");
    captchaImgEle.setAttribute("name", "hipImg"), captchaImgEle.setAttribute("id", "hip"), $(".reloadcaptcha").attr("title", I18N.get("IAM.NEW.SIGNIN.TITLE.RANDOM")), captchaImgEle.setAttribute("align", "left"), captchaImgEle.setAttribute("src", captchimgsrc), $(".signin_box").css("height", "auto"), isMobile || isDarkMode || $(captchaImgEle).css("mix-blend-mode", "multiply"), $(hipRow).html(captchaImgEle)
}

function handleChangeHip(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp);
        if (cdigest = jsonStr.digest, "throttles_limit_exceeded" === jsonStr.cause) return cdigest = "", showHip(cdigest), showCaptcha(I18N.get("IAM.NEXT"), !1), !1;
        showHip(cdigest)
    }
    return !1
}

function handleMfaForIdpUsers(idpdigest, isMagicLink) {
    if (isValid(idpdigest)) {
        hideloader(), $(".blur,.loader").show(), $("#smartsigninbtn").addClass("hide"), window.setTimeout(function() {
            $(".blur,.loader").hide()
        }, 1e3);
        var modeName = isMagicLink ? "digest" : "secondary",
            loginurl = uriPrefix + "/signin/v2/lookup/" + idpdigest + "?mode=" + modeName,
            params = signinParams;
        isValid(csrfParam) && (params = params + "&" + csrfParam + "=" + getCookie(csrfCookieName));
        var resp = getPlainResponse(loginurl, params);
        if (IsJsonString(resp)) {
            var jsonStr = JSON.parse(resp),
                statusCode = jsonStr.status_code;
            if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
                if ($(".fed_2show,.line,#signuplink,#login_id").hide(), $("#login_id_container,#showIDPs").slideUp(200), signinathmode = jsonStr.resource_name, isValid(jsonStr[jsonStr.resource_name].loginid) ? $(".username").text(identifyEmailOrNum(jsonStr[jsonStr.resource_name].loginid)) : $(".hellouser").hide(), restrictTrustMfa = jsonStr[signinathmode].restrict_trust_mfa, isMagicLink) return handleSigninUsingMagic(jsonStr), !1;
                if (restrictTrustMfa || (trustMfaDays = "" + jsonStr[signinathmode].trust_mfa_days), "undefined" == typeof jsonStr[signinathmode].modes) {
                    var successCode = jsonStr.code;
                    if ("SI302" === successCode || "SI200" === successCode || "SI300" === successCode || "SI301" === successCode || "SI303" === successCode) return switchto(jsonStr[signinathmode].redirect_uri), !1
                }
                return allowedmodes = jsonStr[signinathmode].modes.allowed_modes, "mzadevice" === allowedmodes[0] ? (prev_showmode = allowedmodes[0], secondarymodes = allowedmodes, mzadevicepos = 0, callmode = "secondary", zuid = jsonStr.lookup.identifier, temptoken = jsonStr.lookup.token, deviceauthdetails = jsonStr, handleSecondaryDevices(allowedmodes[0]), enableMyZohoDevice(jsonStr), !1) : (handlePasswordDetails(resp), !1)
            }
            return "throttles_limit_exceeded" === jsonStr.cause ? (showCommonError("login_id", jsonStr.localized_message), !1) : (showCommonError("login_id", jsonStr.localized_message), !1)
        }
        return !1
    }
    return !1
}

function handleSigninUsingMagic(resp) {
    var lookupData = resp[resp.resource_name];
    digest = lookupData && lookupData.digest, zuid = lookupData && lookupData.identifier;
    var magic_email = lookupData && lookupData.email,
        magic_portanl_name = lookupData && lookupData.portal_name;
    temptoken = lookupData && lookupData.token;
    var magic_name = magic_email.split("@")[0],
        magicLinkTplElement = '<div class="signin_head"><span id="headtitle"></span><div class="service_name"></div></div><div id="multiDC_container"><div class="profile_head"><div class="profile_dp" id="profile_img"><label class="file_lab"><img id="dp_pic" draggable="false" src="/v2/components/images/user_2.png" style="width: 100%; height: 100%;"></label></div><div class="profile_info"><div class="profile_name" id="profile_name"></div><div class="profile_email" id="profile_email"></div></div><div class="DC_info" style="display:none"><span class="icon-datacenter"></span></div></div></div><button class="btn blue" id="magicLink_btn"><span id="magicLink_btnText"></span></button>',
        magicLinkContainer = document.createElement("div");
    return magicLinkContainer.setAttribute("id", "magicLink_container"), magicLinkContainer.setAttribute("style", "display:none"), magicLinkContainer.innerHTML = magicLinkTplElement, $("#signin_flow").append(magicLinkContainer), $("#magicLink_container #headtitle").html(I18N.get("IAM.SIGNIN.VIA.MAGIC.LINK")), $("#magicLink_container .service_name").html(formatMessage(I18N.get("IAM.SIGNIN.VIA.MAGIC.LINK.DESC"), encodeURI(magic_portanl_name))), $("#profile_email").html(encodeURI(magic_email)), $("#profile_name").html(encodeURI(magic_name)), $("#magicLink_btnText").html(I18N.get("IAM.SIGN_IN")), $("#signin_div, .titlename").hide(), $("#magicLink_container").show(), magicEndpoint = uriPrefix + "/signin/v2/primary/" + zuid + "/digest/" + magicdigest + "?digest=" + digest + "&" + signinParams, $("#magicLink_btn").on("click", function() {
        submitSigninUsingMagic()
    }), !1
}

function submitSigninUsingMagic() {
    $("#magicLink_container").hide(), $("#signin_div, .titlename").show(), sendRequestWithCallback(magicEndpoint, "", !0, handlePasswordDetails)
}

function tryAnotherway(trymode) {
    return $("#verify_" + trymode + "_container").is(":visible") || ($("#verify_totp").val(""), clearCommonError("verify_totp"), prefoption = "qr" === trymode ? "scanqr" : "totp", $(".verify_totp,.verify_qr").slideUp(200), $(".verify_" + trymode).slideDown(200), $(".optionstry").removeClass("toggle_active"), $(".verify_" + trymode).parent().addClass("toggle_active"), "totp" === trymode && (isClientPortal ? $("#verify_totp").focus() : enableSplitField("verify_totp", totp_size, I18N.get("IAM.NEW.SIGNIN.VERIFY.CODE"))), "qr" === trymode && "" === $("#verify_qrimg").attr("src") && ($(".verify_qr .loader,.verify_qr .blur").show(), enableQRCodeimg())), !1
}

function showResendPushInfo() {
    return $(".loadwithbtn").show(), $(".waitbtn .waittext").text(I18N.get("IAM.NEW.SIGNIN.WAITING.APPROVAL")), $("#waitbtn").attr("disabled", !0), showTopNotification(formatMessage(I18N.get("IAM.RESEND.PUSH.MSG"))), clearTimeout(oneauthgrant), oneauthgrant = window.setTimeout(function() {
        showOABackupRedirection(!1)
    }, 45e3), window.setTimeout(function() {
        return $(".waitbtn .waittext").text(I18N.get("IAM.PUSH.RESEND.NOTIFICATION")), $(".loadwithbtn").hide(), $("#waitbtn").attr("disabled", !1), isFormSubmited = !1, !1
    }, 25e3), !1
}

function showTrustBrowser() {
    return prefoption = "ONEAUTH_PUSH_NOTIF" === prefoption ? "push" : "ONEAUTH_TOTP" === prefoption ? "totp" : "ONEAUTH_SCAN_QR" === prefoption ? "scanqr" : "ONEAUTH_FACE_ID" === prefoption ? "faceid" : "ONEAUTH_TOUCH_ID" === prefoption ? "touchid" : prefoption, prefoption = isValid(prefoption) ? prefoption : allowedmodes[0], $(".mod_sername").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.TRUST.HEADER." + prefoption.toUpperCase()), trustMfaDays)), $("#signin_div,.rightside_box,.zoho_logo,.loadwithbtn").hide(), hideOABackupRedirection(), $(".trustbrowser_ui,.trustbrowser_ui #headtitle,.zoho_logo,.mod_sername").show(), $(".trustbrowser_ui .signin_head").show(), $(".signin_container").addClass("trustdevicebox"), $(".signin_box").css("minHeight", "auto"), $(".signin_box").css("padding", "40px"), !1
}

function checkEmailOTPInitiate(notbackneeded) {
    return $(".loader,.blur").hide(), $("#login,#enablemore").hide(), $(".emailcheck_head").show(), $("#emailcheck").val(""), -1 != allowedmodes.indexOf("password") || -1 != allowedmodes.indexOf("ldap") ? $("#emailcheck_container .backoption").show() : $("#emailcheck_container .backoption").hide(), $("#emailcheck_container").show(), $("#emailverify_desc").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.VERIFY.EMAIL.DESC"), rmobile)), clearCommonError("emailcheck"), $("#emailcheck").focus(), notbackneeded && $(".backoption").hide(), !1
}

function hideEmailOTPInitiate() {
    return $("#login").show(), $("#enablemore").show(), $("#emailcheck_container, .resendotp").hide(), signinathmode = $("#password").is(":visible") ? $(".blueforgotpassword").is(":visible") ? "passwordauth" : "ldappasswordauth" : signinathmode, !1
}

function verifyEmailValid() {
    return generateOTPAuth(!1, "EMAIL"), !1
}

function enableEmailOTPDetails(resp) {
    var jsonStr = JSON.parse(resp);
    signinathmode = jsonStr.resource_name;
    var statusCode = jsonStr.status_code;
    if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
        if ("throttles_limit_exceeded" === jsonStr.cause) return showCommonError("emailcheck", jsonStr.localized_message), !1;
        var errorMessage = jsonStr.localized_message;
        return showCommonError("emailcheck", errorMessage), !1
    }
    var successCode = jsonStr.code;
    ("SI201" === successCode || "SI200" === successCode) && (mdigest = jsonStr[signinathmode].mdigest, $(".emailverify_head .backup_desc").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.VERIFY.EMAIL.OTP.TITLE"), rmobile)), $("#emailverify_container,.emailverify_head").show(), $("#emailcheck_container").hide(), isClientPortal || enableSplitField("emailverify", otp_length, I18N.get("IAM.VERIFY.CODE")), showTopNotification(formatMessage(I18N.get("IAM.NEW.SIGNIN.OTP.SENT"), rmobile)), $("#emailverify_container .showmoresigininoption").show(), $("#emailverify_container .signinwithjwt,#emailverify_container .signinwithsaml,#emailverify_container #signinwithpass").hide(), $(".resendotp").show(), resendotp_checking())
}

function verifyEmailOTP() {
    if (isClientPortal) var OTP_CODE = $("#emailverify").val();
    else var OTP_CODE = document.getElementById("emailverify").firstChild.value;
    if (!isClientPortal && !isWebAuthNSupported()) return showTopErrNotification(I18N.get("IAM.WEBAUTHN.ERROR.BrowserNotSupported")), changeButtonAction(I18N.get("IAM.NEW.SIGNIN.VERIFY"), !1), !1;
    if (!isValid(OTP_CODE)) return showCommonError("emailverify", I18N.get("IAM.NEW.SIGNIN.INVALID.OTP.MESSAGE.EMPTY")), !1;
    if (isNaN(OTP_CODE) || !isValidCode(OTP_CODE)) return showCommonError("emailverify", I18N.get("IAM.NEW.SIGNIN.INVALID.EMAIL.MESSAGE.NEW")), !1;
    if (/[^0-9\-\/]/.test(OTP_CODE)) return showCommonError("emailverify", I18N.get("IAM.SIGNIN.ERROR.INVALID.VERIFICATION.CODE")), !1;
    var loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/otp/" + emobile + "?";
    loginurl += "digest=" + digest + "&" + signinParams;
    var jsonData = {
        otpauth: {
            code: OTP_CODE,
            is_resend: !1
        }
    };
    return sendRequestWithCallback(loginurl, JSON.stringify(jsonData), !0, handlePasswordDetails, "PUT"), !1
}

function hideEmailOTPVerify() {
    return $("#emailverify_container").hide(), $("#emailcheck_container").show(), clearCommonError("emailverify"), !1
}

function getbackemailverify() {
    return $("#emailcheck_container,.emailverify_head").show(), clearCommonError("emailcheck"), $("#login").hide(), !1
}

function updateTrustDevice(trust) {
    trust ? $(".trustbtn .loadwithbtn").show() : $(".notnowbtn .loadwithbtn").show(), trust ? $(".trustbtn .waittext").addClass("loadbtntext") : $(".notnowbtn .waittext").addClass("loadbtntext"), $(".trustdevice").attr("disabled", !0);
    var loginurl = uriPrefix + "/signin/v2/secondary/" + zuid + "/trust?" + signinParams,
        jsonData = {
            trustmfa: {
                trust: trust
            }
        };
    return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleTrustDetails), !1
}

function handleTrustDetails(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            signinathmode = jsonStr.resource_name;
            var successCode = jsonStr.code;
            return "SI302" === successCode || "SI200" === successCode || "SI300" === successCode || "SI301" === successCode || "SI303" === successCode || "SI305" === successCode || "SI507" === successCode || "SI509" === successCode || "SI506" === successCode ? (switchto(jsonStr[signinathmode].redirect_uri), !1) : !1
        }
        return $(".trustdevice").attr("disabled", !1), $(".trustbtn .loadwithbtn,.notnowbtn .loadwithbtn").hide(), $(".trustbtn .waittext,.notnowbtn .waittext").removeClass("loadbtntext"), showTopErrNotification(jsonStr.localized_message), !1
    }
}

function getQueryParams(queryStrings) {
    var vars = {};
    queryStrings = queryStrings.substring(queryStrings.indexOf("?") + 1);
    for (var params = queryStrings.split("&"), i = 0; i < params.length; i++) {
        var pair = params[i].split("=");
        vars[pair[0]] = 2 == pair.length ? decodeURIComponent(pair[1]) : ""
    }
    return vars
}

function createandSubmitOpenIDForm(idpProvider) {
    if (isValid(idpProvider)) {
        var oldForm = document.getElementById(idpProvider + "form");
        oldForm && document.documentElement.removeChild(oldForm);
        var form = document.createElement("form"),
            idpurl = "/accounts/fsrequest";
        isClientPortal && (idpurl = "ZOHO" === idpProvider.toUpperCase() ? uriPrefix + "/clientidprequest" : IDPRequestURL), form.setAttribute("id", idpProvider + "form"), form.setAttribute("method", "POST"), form.setAttribute("action", idpurl), form.setAttribute("target", "_parent");
        var hiddenField = document.createElement("input");
        hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "provider"), hiddenField.setAttribute("value", idpProvider.toUpperCase()), form.appendChild(hiddenField), hiddenField = document.createElement("input"), hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", csrfParam), hiddenField.setAttribute("value", getCookie(csrfCookieName)), form.appendChild(hiddenField);
        var params = getQueryParams(location.search);
        for (var key in params) isValid(params[key]) && "recoveryurl" != key && (hiddenField = document.createElement("input"), hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", key), hiddenField.setAttribute("value", params[key]), form.appendChild(hiddenField));
        document.documentElement.appendChild(form), form.submit()
    }
}

function goToForgotPassword(isIP) {
    var tmpResetUrl = isIP ? getIPRecoveryURL() : getRecoveryURL(),
        LOGIN_ID = $(isIP ? ".resetIP_container .username" : ".username")[0].innerText;
    if (isValid(LOGIN_ID) && isEmailIdSignin(LOGIN_ID) ? "" : LOGIN_ID = de("login_id").value.trim(), isUserName(LOGIN_ID) && isEmailIdSignin(LOGIN_ID) && isPhoneNumber(LOGIN_ID.split("-")[1]) || isPhoneNumber(LOGIN_ID.split("-")[1]) && -1 != LOGIN_ID.split("-")[0].indexOf("+")) return showCommonError("login_id", I18N.get("IAM.NEW.SIGNIN.INVALID.LOOKUP.IDENTIFIER")), !1;
    var redirectedFrom = "lookup" == signinathmode ? "primary" : "secondary";
    if (de("login_id") && (isUserName(LOGIN_ID) || isEmailIdSignin(LOGIN_ID) || isPhoneNumber(LOGIN_ID.split("-")[1]))) {
        var oldForm = document.getElementById("recoveryredirection");
        oldForm && document.documentElement.removeChild(oldForm);
        var login_id = !emailOnlySignin && isPhoneNumber(LOGIN_ID) ? $("#country_code_select").val().split("+")[1] + "-" + LOGIN_ID : LOGIN_ID,
            form = document.createElement("form");
        form.setAttribute("id", "recoveryredirection"), form.setAttribute("method", "POST"), form.setAttribute("action", tmpResetUrl), isClientPortal ? form.setAttribute("target", "_self") : form.setAttribute("target", "_parent");
        var hiddenField = document.createElement("input");
        return hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "LOGIN_ID"), hiddenField.setAttribute("value", login_id), form.appendChild(hiddenField), isIP || (hiddenField = document.createElement("input"), hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "redirectedFrom"), hiddenField.setAttribute("value", redirectedFrom), form.appendChild(hiddenField)), document.documentElement.appendChild(form), form.submit(), !1
    }
    window.location.href = isIP ? tmpResetUrl + "?redirectedFrom=" + redirectedFrom : tmpResetUrl
}

function iamMovetoSignUp(signupUrl, login_id) {
    if (isDarkMode && -1 == signupUrl.indexOf("darkmode=true") && (signupUrl += "&darkmode=true"), !isValid(login_id)) return window.location.href = signupUrl, !1;
    var xhr = new XMLHttpRequest;
    xhr.open("POST", signupUrl, !0), xhr.setRequestHeader("Content-Type", "application/json"), xhr.setRequestHeader("X-ZCSRF-TOKEN", csrfParam + "=" + euc(getCookie(csrfCookieName))), xhr.onreadystatechange = function() {
        return 4 == xhr.readyState ? 200 === xhr.status ? (triggerPostRedirection(signupUrl, login_id), !1) : (window.location.href = signupUrl, !1) : void 0
    }, xhr.send()
}

function register() {
    return window.location.href = signup_url, !1
}

function showBackupVerificationCode() {
    return $("#login,.fed_2show,#recovery_container,#passphrase_container,#bcaptcha_container").hide(), hideBkCodeRedirection(), $("#backup_container,.backuphead,#backupcode_container").show(), $("#backupcode").focus(), $("#backup_title").html("<span class='icon-backarrow backoption backup_title_backop'></span>" + I18N.get("IAM.TFA.USE.BACKUP.CODE")), $(".backup_desc").html(I18N.get("IAM.NEW.SIGNIN.BACKUP.HEADER")), signinathmode = "recoverycodesecauth", -1 != allowedmodes.indexOf("passphrase") ? $("#recovery_passphrase").show() : $("#recovery_passphrase").hide(), $(".backup_title_backop").on("click", function() {
        hideCantAccessDevice()
    }), !1
}

function goBackToProblemSignin() {
    return $("#recovery_container").hide(), $(".fed_2show,#recovery_container,#backup_container").hide(), isSecondary && (isMobileonly ? $(".addaptivetfalist").removeClass("heightChange") : $(".addaptivetfalist").hide()), signinathmode = oldsigninathmode, $("#login").show(), isClientPortal && $(".alt_signin_head").show(), !1
}

function showCantAccessDevice() {
    return isTroubleSignin = !1, showHideEnforcePop(!1), $(".devices,.devicedetails").hide(), clearInterval(_time), clearTimeout(oneauthgrant), $(".signin_container").removeClass("mobile_signincontainer"), -1 === allowedmodes.indexOf("passphrase") ? $("#passphraseRecover").hide() : $("#passphraseRecover").show(), -1 === allowedmodes.indexOf("recoverycode") ? $("#recoverOption").hide() : $("#recoverOption").show(), window.setTimeout(function() {
        $(".blur").hide(), $(".blur").removeClass("dark_blur")
    }, 100), oldsigninathmode = signinathmode, $("#login,.fed_2show,#backup_container,.backuphead").hide(), isClientPortal && $(".alt_signin_head").hide(), $("#recovery_container,#recoverytitle,.recoveryhead").show(), !1
}

function hideCantAccessDevice(ele) {
    if (isRecovery && $(".contactSupport").show(), $("#recovery_container").show(), $("#backup_container").is(":visible")) return $("#backup_container").hide(), !1;
    if (void 0 != ele) {
        var ele = isValid(ele.parentElement.parentElement.id) ? ele.parentElement.parentElement.id : ele.parentElement.parentElement.parentElement.id;
        $("#" + ele).hide()
    }
    return !1
}

function verifyBackupCode() {
    var isBcaptchaNeeded = $("#bcaptcha_container").is(":visible");
    if (isBcaptchaNeeded) {
        var bcaptchavalue = de("bcaptcha").value.trim();
        if (!isValid(bcaptchavalue)) return showCommonError("bcaptcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.REQUIRED"), !0), !1;
        if (/[^a-zA-Z0-9\-\/]/.test(bcaptchavalue)) return changeHip("bcaptcha_img", "bcaptcha"), showCommonError("bcaptcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.INVALID")), !1
    }
    if ("passphrasesecauth" === signinathmode) {
        var passphrase = $("#passphrase").val().trim();
        if (!isValid(passphrase)) return showCommonError("passphrase", I18N.get("IAM.NEW.SIGNIN.ENTER.VALID.PASSPHRASE.CODE")), !1;
        var loginurl = uriPrefix + "/signin/v2/secondary/" + zuid + "/passphrase?" + signinParams;
        isBcaptchaNeeded && (loginurl += "&captcha=" + bcaptchavalue + "&cdigest=" + cdigest);
        var recsalt = deviceauthdetails[deviceauthdetails.resource_name].modes.passphrase && deviceauthdetails[deviceauthdetails.resource_name].modes.passphrase.rec_salt;
        if ("undefined" != typeof recsalt) var derivedKey = sjcl.codec.base64.fromBits(sjcl.misc.pbkdf2(passphrase, sjcl.codec.base64.toBits(recsalt), 1e5, 256)),
            jsonData = {
                passphrasesecauth: {
                    secret_key: derivedKey
                }
            };
        else var jsonData = {
            passphrasesecauth: {
                pass_phrase: passphrase
            }
        };
        return $("#backupVerifybtn span").addClass("zeroheight"), $("#backupVerifybtn").addClass("changeloadbtn"), $("#backupVerifybtn").attr("disabled", !0), sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handlePassphraseDetails), !1
    }
    var backupcode = $("#backupcode").val().trim();
    backupcode = backupcode.replace(/\s/g, "");
    var objRegExp = /^([a-zA-Z0-9]{12})$/;
    if (!isValid(backupcode)) return showCommonError("backupcode", I18N.get("IAM.EMPTY.BACKUPCODE.ERROR")), !1;
    if (!objRegExp.test(backupcode)) return showCommonError("backupcode", I18N.get("IAM.NEW.SIGNIN.ENTER.VALID.BACKUP.CODE")), !1;
    var loginurl = uriPrefix + "/signin/v2/secondary/" + zuid + "/recovery?" + signinParams;
    isBcaptchaNeeded && (loginurl += "&captcha=" + bcaptchavalue + "&cdigest=" + cdigest);
    var isAMFA = deviceauthdetails[deviceauthdetails.resource_name].isAMFA,
        jsonData = isAMFA ? {
            recoverycodesecauth: {
                code: backupcode,
                isAMFA: !0
            }
        } : {
            recoverycodesecauth: {
                code: backupcode
            }
        };
    return $("#backupVerifybtn span").addClass("zeroheight"), $("#backupVerifybtn").addClass("changeloadbtn"), $("#backupVerifybtn").attr("disabled", !0), sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleBackupVerificationDetails), !1
}

function handleBackupVerificationDetails(resp) {
    if (IsJsonString(resp)) {
        $("#backupVerifybtn span").removeClass("zeroheight"), $("#backupVerifybtn").removeClass("changeloadbtn"), $("#backupVerifybtn").attr("disabled", !1);
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        if (signinathmode = jsonStr.resource_name, !isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            var successCode = jsonStr.code,
                statusmsg = jsonStr.recoverycodesecauth.status;
            return "success" === statusmsg ? (updateTrustDevice(!1), !1) : "P500" === successCode || "P501" === successCode || "P506" === successCode ? (temptoken = jsonStr[signinathmode].token, showPasswordExpiry(jsonStr[signinathmode].pwdpolicy, successCode), !1) : (showCommonError("backupcode", jsonStr.localized_message), !1)
        }
        if ("throttles_limit_exceeded" === jsonStr.cause) return showCommonError("backupcode", jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors[0],
            errorCode = error_resp.code,
            errorMessage = jsonStr.localized_message;
        return "IN107" === errorCode || "IN108" === errorCode ? ($(".fed_2show,.line").hide(), $("#bcaptcha_container").show(), $("#bcaptcha").focus(), cdigest = jsonStr.cdigest, showHip(cdigest, "bcaptcha_img"), clearCommonError("bcaptcha"), changeButtonAction(I18N.get("IAM.NEW.SIGNIN.VERIFY"), !1), "IN107" === errorCode && showCommonError("bcaptcha", errorMessage), !1) : "R303" === errorCode ? (showRestrictsignin(), !1) : (showCommonError("backupcode", errorMessage), !1)
    }
}

function removeParamFromQueryString(param) {
    if (isValid(queryString)) {
        for (var prefix = encodeURIComponent(param), pars = queryString.split(/[&;]/g), i = pars.length; i-- > 0;) {
            var paramObj = pars[i].split(/[=;]/g);
            prefix === paramObj[0] && pars.splice(i, 1)
        }
        if (pars.length > 0) return pars.join("&")
    }
    return ""
}

function allowedModeChecking() {
    return 1 == secondarymodes.length || "recoverycode" == secondarymodes[1] && 2 == secondarymodes.length ? ("recoverycode" == secondarymodes[1] && $("#recoverOption").show(), $("#recoverybtn").show(), $("#problemsignin").hide()) : ($("#problemsignin").show(), $("#recoverybtn").hide()), isSecondary && ($("#problemsignin").show(), $("#recoverybtn").hide()), -1 != secondarymodes.indexOf("passphrase") && secondarymodes.length <= 3 && ($("#recoverybtn").show(), $("#problemsignin").hide()), !1
}

function showCurrentMode(pmode, index) {
    $(".contactSupport").hide(), mobposition = emailposition = mzadevicepos = void 0, $(".devices,.devicedetails").hide(), $("#mfa_totp_container,#mfa_otp_container,#mfa_email_container,#waitbtn,#nextbtn,#mfa_scanqr_container,#mfa_push_container,#openoneauth,#yubikey_container, #qrOneContent, #qrOrLine,#alternate_verification_info").hide(), clearInterval(_time), $(".tryanother").hide(), prev_showmode = "federated" === pmode ? prev_showmode : pmode, clearCommonError(pmode), "secondary" == callmode && clearCommonError("mfa_" + pmode);
    var authenticatemode = void 0 === deviceauthdetails.passwordauth ? "lookup" : "passwordauth";
    if ("otp" === pmode || "email" === pmode) {
        triggeredUser = !0, $(".loader,.blur, .resendotp").show();
        var jsonPack = deviceauthdetails[deviceauthdetails.resource_name];
        if (emobile = "otp" === pmode ? jsonPack.modes.otp.data[index].e_mobile : jsonPack.modes.email.data[index].e_email, rmobile = "otp" === pmode ? identifyEmailOrNum(jsonPack.modes.otp.data[index].r_mobile, !0) : jsonPack.modes.email.data[index].email, isPasswordless && deviceauthdetails.lookup.isUserName && "email" == pmode) return checkEmailOTPInitiate(!0), !1;
        if (isPasswordless ? showAndGenerateOtp(pmode) : generateOTP(!1, pmode), "email" === pmode ? emailposition = index : mobposition = index, isPrimaryDevice = !0, isPasswordless) {
            $(".service_name").html(formatMessage(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.OTP"), rmobile));
            var showingmodes = secondarymodes;
            1 == showingmodes ? "otp" == showingmodes[0] || "email" == showingmodes[0] ? $("#enableotpoption").show() : "" : $("#enablemore").show()
        }
    }
    if (goBackToProblemSignin(), "totp" === pmode) enableTOTPdevice(deviceauthdetails, !1, !1), signinathmode = "totpsecauth", isPasswordless && (signinathmode = "totpauth", fallBackForSingleMode(pmode, validateAllowedMode(pmode, "mzadevice").option));
    else if ("oadevice" === pmode) $(".secondary_devices").uvselect("destroy"), handleSecondaryDevices(pmode), $(".loader,.blur").show(), isResend = !1, signinathmode = authenticatemode, oadevicepos = index, enableOneauthDevice(deviceauthdetails, oadevicepos);
    else if ("yubikey" === pmode) $(".loader,.blur").show(), signinathmode = authenticatemode, enableYubikeyDevice(deviceauthdetails);
    else if ("mzadevice" === pmode) {
        if ($(".secondary_devices").uvselect("destroy"), handleSecondaryDevices(pmode), $(".loader,.blur").show(), isResend = !1, mzadevicepos = index, prefoption = deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[mzadevicepos].prefer_option, enableMyZohoDevice(deviceauthdetails, prefoption), "totp" === prefoption) return goBackToCurrentMode(!0), isRecovery && $("#problemsignin,#recoverybtn,.tryanother").hide(), !1
    } else if ("password" === pmode || "ldap" === pmode) showPasswordContainer("ldap" === pmode), $(".service_name").html(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.PASSWORD"));
    else {
        if ("federated" === pmode) {
            var idp = deviceauthdetails.lookup.modes.federated.data[0].idp.toLowerCase();
            return 1 === index ? createandSubmitOpenIDForm(idp) : showMoreFedOptions(), !1
        }
        if ("saml" === pmode) {
            $(".blur,.loader").show();
            var samlAuthDomain = deviceauthdetails[deviceauthdetails.resource_name].modes.saml.data[index].auth_domain;
            return enableSamlAuth(samlAuthDomain), $(".service_name").html(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.SAML")), $(".blur,.loader").hide(), !1
        }
        if ("jwt" === pmode) {
            var redirectURI = deviceauthdetails[deviceauthdetails.resource_name].modes.jwt.data[0].redirect_uri;
            $(".service_name").html(I18N.get("IAM.NEWSIGNIN.BACKUP.DESC.JWT")), switchto(redirectURI)
        }
    }
    return "mzadevice" != pmode && "oadevice" != pmode && $(".deviceparent").addClass("hide"), goBackToCurrentMode(), isPasswordless ? ($("#headtitle").html(I18N.get("IAM.NEWSIGNIN.VERIFY.FIRST.FACTOR")), $(".service_name").addClass("extramargin"), hideTryanotherWay(!0), $("#problemsignin,#recoverybtn,.tryanother,#enableoptionsoneauth").hide(), "mzadevice" != pmode ? $(".backupstep").show() : "") : isRecovery && ($("#headtitle .backoption").length < 1 && $("#headtitle").html("<span class='icon-backarrow backoption'></span>" + $("#headtitle").html()), $("#headtitle .backoption").on("click", function() {
        hideCantAccessDevice(this)
    })), isRecovery && $("#problemsignin,#recoverybtn,.tryanother").hide(), !1
}

function showPasswordContainer(isLdapPassword) {
    $("#nextbtn").attr("disabled", !1), $("#password").val(""), clearCommonError("password"), $("#password_container,#enableforgot").show(), $("#enablesaml,#enableotpoption,.textbox_actions,#otp_container").hide(), $("#password_container").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#headtitle").text(I18N.get("IAM.SIGN_IN")), $(".service_name").removeClass("extramargin"), $(".service_name").html(formatMessage(I18N.get("IAM.NEW.SIGNIN.SERVICE.NAME.TITLE"), displayname)), $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn span").text(I18N.get("IAM.SIGN_IN")), $(".username").text(identifyEmailOrNum()), isPasswordless && !isRecovery && allowedModeChecking(), $(".signin_head").css("margin-bottom", "30px"), $("#password").focus(), $("#enableotpoption,#enablesaml,#enablejwt,#enablemore, #enablepass, #enableldap").hide();
    var showingmodes = secondarymodes;
    3 == showingmodes.length ? (isLdapPassword ? -1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enableotpoption").show() : -1 != showingmodes.indexOf("password") ? $("#enablepass").show() : "" : -1 != showingmodes.indexOf("otp") || -1 != showingmodes.indexOf("email") ? $("#enableotpoption").show() : -1 != showingmodes.indexOf("ldap") ? $("#enableldap").show() : "", -1 != showingmodes.indexOf("otp") ? $("#signinwithotp").html(I18N.get("IAM.NEW.SIGNIN.USING.MOBILE.OTP")) : -1 != showingmodes.indexOf("email") && $("#signinwithotp").html(I18N.get("IAM.NEW.SIGNIN.USING.EMAIL.OTP"))) : showingmodes.length > 2 && $("#enablemore").show(), isLdapPassword ? (signinathmode = "ldappasswordauth", $(".blueforgotpassword").hide(), prev_showmode = "ldap", $("#password").attr("placeholder", I18N.get("IAM.LDAP.PASSWORD.PLACEHOLDER")), isLdapVisible = !0, $("#enableldap").hide(), 2 == btnAllowedModes() && (-1 == allowedmodes.indexOf("password") ? $("#enablepass").hide() : ($("#enablepass").show(), $("#enablemore").hide()), $("#signinwithldappass").hide())) : ($("#signinwithldappass").show(), signinathmode = "passwordauth", prev_showmode = "password", $("#password").attr("placeholder", I18N.get("IAM.NEW.SIGNIN.PASSWORD")), isLdapVisible = !1, 2 == btnAllowedModes() ? ($(".blueforgotpassword").show(), $("#enablepass").hide(), -1 == allowedmodes.indexOf("ldap") ? $("#enableldap").hide() : ($("#enableldap").show(), $("#enablemore").hide())) : 1 == btnAllowedModes() && -1 != allowedmodes.indexOf("password") && $("#enableforgot").show()), showSigninUsingFedOption(), isFormSubmited = !1
}

function showMoreFedOptions() {
    var idps = deviceauthdetails[deviceauthdetails.resource_name].modes.federated.data,
        problemsigninheader = "<div class='problemsignin_head'><span class='icon-backarrow backoption problemsigninbackoption'></span><span class='rec_head_text'>" + I18N.get("IAM.NEW.SIGNIN.FEDERATED.LOGIN.TITLE") + "</span></div>",
        idp_con = "";
    return idps.forEach(function(idps) {
        isValid(idps) && (idp = idps.idp.toLowerCase(), idp_con += "<div class='optionstry options_hover optionipds' id='secondary_" + idp + "' value=" + idp + ">							<div class='img_option_try img_option icon-federated'></div>							<div class='option_details_try'>								<div class='option_title_try'><span style='text-transform: capitalize;'>" + idp + "<span></div>								<div class='option_description'>" + formatMessage(I18N.get("IAM.NEW.SIGNIN.IDENTITY.PROVIDER.TITLE"), idp) + "</div>							</div>							</div>")
    }), $("#problemsigninui").html(problemsigninheader + "<div class='problemsignincon'>" + idp_con + "</div>"), $("#password_container,#nextbtn,.signin_head,#otp_container,#captcha_container,.fed_2show").hide(), $("#problemsigninui, #problemsignin_container").show(), $(".problemsigninbackoption").on("click", function() {
        isPrimaryMode ? showmoresigininoption() : showproblemsignin()
    }), $(".optionipds").on("click", function() {
        createandSubmitOpenIDForm($(this).attr("value"))
    }), !1
}

function enableQRCodeimg() {
    var prefoption = "scanqr",
        deviceid = deviceauthdetails[deviceauthdetails.resource_name].modes.mzadevice.data[mzadevicepos].device_id,
        loginurl = uriPrefix + "/signin/v2/" + callmode + "/" + zuid + "/device/" + deviceid + "?";
    loginurl += "digest=" + digest + "&" + signinParams;
    var jsonData = "primary" === callmode ? {
        deviceauth: {
            devicepref: prefoption
        }
    } : {
        devicesecauth: {
            devicepref: prefoption
        }
    };
    sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handleQRCodeImg), signinathmode = "primary" === callmode ? "deviceauth" : "devicesecauth"
}

function handleQRCodeImg(resp) {
    if (!IsJsonString(resp)) return showTopErrNotification(I18N.get("IAM.ERROR.GENERAL")), !1;
    var jsonStr = JSON.parse(resp);
    signinathmode = jsonStr.resource_name;
    var statusCode = jsonStr.status_code;
    if (!(!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode)) {
        if ("throttles_limit_exceeded" === jsonStr.cause) return showTopErrNotification(jsonStr.localized_message), !1;
        var error_resp = jsonStr.errors && jsonStr.errors[0],
            errorCode = error_resp && error_resp.code;
        return "R303" === errorCode ? (showRestrictsignin(), !1) : (showTopErrNotification(jsonStr.localized_message), !1)
    }
    var successCode = jsonStr.code;
    if ("SI202" === successCode || "MFA302" === successCode || "SI302" === successCode || "SI201" === successCode) {
        temptoken = jsonStr[signinathmode].token;
        var qrcodeurl = jsonStr[signinathmode].img;
        qrtempId = jsonStr[signinathmode].temptokenid, isValid(qrtempId) ? $("#verify_qr_container #openoneauth").show() : $("#verify_qr_container #openoneauth").hide();
        var wmsid = jsonStr[signinathmode].WmsId && jsonStr[signinathmode].WmsId.toString();
        isVerifiedFromDevice(prefoption, !0, wmsid), $("#verify_qrimg").attr("src", qrcodeurl), $(".verify_qr .loader,.verify_qr .blur").hide()
    }
    return !1
}

function showPassphraseContainer() {
    return signinathmode = "passphrasesecauth", "undefined" == typeof sjcl ? (includeScript(sjclFilePath, showPassphraseContainer, !0), !1) : ($("#login,.fed_2show,#backupcode_container,#recovery_container,#bcaptcha_container").hide(), $("#passphrase_container,#backup_container,.backuphead").show(), $("#backup_title").html("<span class='icon-backarrow backoption passback'></span>" + I18N.get("IAM.NEW.SIGNIN.PASS.PHRASE.TITLE")), $(".passback").on("click", function() {
        hideCantAccessDevice()
    }), $(".backup_desc").html(I18N.get("IAM.NEW.SIGNIN.PASS.PHRASE.DESC")), void(-1 != allowedmodes.indexOf("recoverycode") ? $("#recovery_backup").show() : $("#recovery_backup").hide()))
}

function hideSigninOptions() {
    var fedSigninOptionInnerHTML = document.getElementById("fed_signin_options") && document.getElementById("fed_signin_options").innerHTML;
    void 0 != fedSigninOptionInnerHTML && "" != fedSigninOptionInnerHTML ? $(".fed_2show").show() : showSigninUsingFedOption(), $("#enablemore").show(), $("#nextbtn,.signin_head").show();
    var show_mode = "email" === prev_showmode ? "otp" : "ldap" === prev_showmode ? "password" : prev_showmode;
    return ("password" === prev_showmode || "ldap" === prev_showmode) && (signinathmode = "ldap" === prev_showmode ? "ldap" : "passwordauth", $(".resendotp").hide()), "totp" == show_mode ? $("#mfa_totp_container").show() : $("#" + show_mode + "_container").show(), $("#problemsigninui, #problemsignin_container").hide(), !1
}

function QrOpenApp() {
    var qrCodeString = "code=" + qrtempId + "&zuid=" + zuid + "&url=" + iamurl;
    return document.location = UrlScheme + "://?" + qrCodeString, !1
}

function showRestrictsignin() {
    return $("#signin_div,.rightside_box,.banner_newtoold").hide(), $("#smartsigninbtn").addClass("hide"), $("#restict_signin").show(), $(".zoho_logo").addClass("applycenter"), $(".signin_container").addClass("mod_container"), !1
}

function setCookie(x) {
    var dt = new Date;
    dt.setDate(dt.getYear() * x);
    var cookieStr = "IAM_TEST_COOKIE=IAM_TEST_COOKIE;expires=" + dt.toGMTString() + ";path=/;";
    "null" != cookieDomain && (cookieStr += "domain=" + cookieDomain), document.cookie = cookieStr
}

function submitbackup(event) {
    13 === event.keyCode && verifyBackupCode()
}

function setPassword(event) {
    13 === event.keyCode && updatePassword()
}

function showTopNotification(msg, timeout) {
    $(".alert_message").html(msg), $(".Alert").css("top", "20px"), $(".topNotificationClose").length || ($(".Alert").append($("<span>").addClass("topNotificationClose")), $(".topNotificationClose").off().on("click", function() {
        $(".Alert").css("top", "-150px")
    })), window.setTimeout(function() {
        $(".Alert").css("top", "-150px")
    }, timeout ? timeout : 5e3)
}

function showTopErrNotification(msg, help, timer) {
    timer = timer ? timer : 5e3, $(".error_message").html(msg), $(".Errormsg").css("top", "20px"), window.setTimeout(function() {
        $(".Errormsg").css("top", "-150px")
    }, timer), void 0 != help && "" != help && ($(".error_help").css("display", "inline-block"), $(".error_help").html(help), $(".error_message").addClass("error_help_in"), window.setTimeout(function() {
        $(".error_message").removeClass("error_help_in"), $(".error_help").html("")
    }, 5500))
}

function showTopErrNotificationStatic(msg, help, timer) {
    timer = timer ? timer : 5e3, $(".error_message").html(msg), $(".Errormsg").css("top", "20px"), $(".topErrClose").removeClass("hide"), $(".error_icon").addClass("err-icon-help"), void 0 != help && "" != help && ($(".error_help").css("display", "inline-block"), $(".error_help").html(help), $(".error_message").addClass("error_help_in"))
}

function closeTopErrNotification() {
    $(".Errormsg").css("top", "-150px"), $("error_message").removeClass("error_help_in"), $(".error_message").removeClass("error_help_in"), $(".error_help").css("display", "none"), $(".error_help").html(""), $(".error_icon").removeClass("err-icon-help"), $(".topErrClose").is(":visible") && $(".topErrClose").addClass("hide")
}

function checkCookie() {
    isValid(getCookie(iam_reload_cookie_name)) && window.location.reload()
}

function check_pp() {
    ppValidator.validate("", "#npassword_container input")
}

function remove_error() {
    $(".field_error").remove(), clearCommonError("npassword")
}

function handleCrossDcLookup(loginID) {
    $(".blur,.loader").show(), isValid(CC) && $("#country_code_select").val($("#" + CC).val()), isValid(CC) && (loginID = -1 != loginID.indexOf("-") ? loginID : $("#" + CC).val().split("+")[1] + "-" + loginID), isEmailId(loginID) && (loginID = loginID.toLowerCase());
    var loginurl = uriPrefix + "/signin/v2/lookup/" + loginID,
        encryptionJson = {
            path: loginurl,
            value: loginID
        },
        params = "mode=primary&" + signinParams;
    return sendRequestWithCallback(loginurl, params, !0, handleLookupDetails, void 0, encryptionJson, loginID, !0), !1
}

function handleConnectionError() {
    return $("#nextbtn span").removeClass("zeroheight"), $("#nextbtn").removeClass("changeloadbtn"), $("#nextbtn").attr("disabled", !1), isFormSubmited = !1, showTopErrNotification(I18N.get("IAM.PLEASE.CONNECT.INTERNET")), !1
}

function hideBkCodeRedirection() {
    return $(".go_to_bk_code_container").removeClass("show_bk_pop"), $(".go_to_bk_code_container").hide(), !1
}

function showOABackupRedirection(deviceUninstalled) {
    if ($(".goto_oneauth_fallback_container").hasClass("show_bk_pop") || !$("#mfa_device_container").is(":visible") || isOauPopupClosed) return !1;
    $(".goto_oneauth_fallback_container").addClass("show_bk_pop"), $(".goto_oneauth_fallback_container").show();
    deviceauthdetails[deviceauthdetails.resource_name];
    if ($(".tryanother").text(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH.OTHER.OPTION")), $(".tryanother").off().on("click", function() {
            showproblemsignin(!0)
        }), deviceUninstalled) {
        clearTimeout(oneauthgrant);
        var devicedetails = deviceauthdetails[deviceauthdetails.resource_name].modes,
            devicename = devicedetails.mzadevice.data && devicedetails.mzadevice.data[parseInt(mzadevicepos)].device_name;
        $(".backup_info_header").text(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH")), $(".backup_info_content").html(formatMessage(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH.DESC"), devicename, oneAuthLearnmore))
    } else $(".backup_info_header").text(I18N.get("IAM.NEWSIGNIN.UNABLE.REACH.ONEAUTH")), $(".backup_info_content").html(formatMessage(I18N.get("IAM.NEWSIGNIN.BACKUP.LAST.DEVICE.DESC"), oneAuthLearnmore));
    return allowedmodes.length <= 1 ? ($(".backup_info_mode").text(I18N.get("IAM.NEW.SIGNIN.CONTACT.SUPPORT")), $(".backup_info_mode").on("click", function() {
        showContactSupport()
    }), $(".tryanother").text(I18N.get("IAM.NEW.SIGNIN.CONTACT.SUPPORT")), $(".tryanother").off().on("click", function() {
        showContactSupport()
    })) : isPasswordless ? $(".backup_info_mode").on("click", function() {
        showproblemsignin(!0)
    }) : ($(".backup_info_mode").on("click", function() {
        showMoreSigninOptions()
    }), $(".tryanother").off().on("click", function() {
        showMoreSigninOptions()
    }), $(".rec_head_text").html("<div class='problemsignin_head'><div class='oa_head_text'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY") + "</div><div class='oa_head_con'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY.DESC") + "</div></div>"), $("#recovery_container .signin_head").css("margin-bottom", "0px")), !1
}

function hideOABackupRedirection() {
    return $(".devices").css("pointer", "cursor"), $(".goto_oneauth_fallback_container").removeClass("show_bk_pop"), $(".goto_oneauth_fallback_container").hide(), !1
}

function showContactSupport(isBackNeeded, backmethod) {
    hideOABackupRedirection(), showCantAccessDevice(), $("#recovery_container").show(), $(".recoveryhead").html(""), $(".recoveryhead").append($(isBackNeeded ? "<span class='icon-backarrow backoption' id='contactBack'></span><span class=rec_head_text></span>" : "<span class=rec_head_text></span>")), $(".rec_head_text").html(I18N.get("IAM.NEW.SIGNIN.CONTACT.SUPPORT")), $(".recoveryhead").append($("<div class='contactSupportDesc'></div>")), $(".contactSupportDesc").html(I18N.get("IAM.CONTACT.SUPPORT.DESC")), $(".recoveryhead").append($("<div class='mailbox'><table class='mailtable'><tr><td class='icon-email'></td><td class='emailtitle'></td></tr><tr><td></td><td class='emailonly'></td></tr></table></div>")), isValid(adminEmail) || isValid(supportSLA) && ($(".recoveryhead").append($("<div class='supportSLA'></div>")), $(".supportSLA").html(formatMessage(I18N.get("IAM.CONTACT.SUPPORT.SLA"), supportSLA))), $(".emailtitle").html(I18N.get("IAM.CONTACT.EMAIL.US.ON")), $(".emailonly").html(adminEmail ? adminEmail : supportEmailAddress), $("#recoverymodeContainer,.contactSupport,.contact_support,#alternate_verification_info").hide(), isBackNeeded && ("undefined" != typeof backmethod && "backtoalterinfo" === backmethod ? $("#contactBack").on("click", function() {
        backtoalterinfo()
    }) : "undefined" != typeof backmethod && "backtocaptcha" === backmethod ? ($("#verifycaptcha_container").hide(), $("#contactBack").on("click", function() {
        backtocaptcha()
    })) : (allowedmodes && 1 == allowedmodes.length ? "otp" === prev_showmode || "totp" === prev_showmode ? $("#contactBack").on("click", function() {
        enableMfaField(prev_showmode)
    }) : "mzadevice" === prev_showmode && $("#contactBack").on("click", function() {
        goBackToProblemSignin()
    }) : $("#contactBack").on("click", function() {
        backtoContactSupport()
    }), allowedmodes.length <= 1 && "mzadevice" === prev_showmode && $("#contactBack").on("click", function() {
        goBackToProblemSignin()
    }), oaNotInstalled && !isPasswordless && $("#contactBack").on("click", function() {
        hidecontactsupport()
    })))
}

function backtocaptcha() {
    $("#verifycaptcha_container, #verifycaptcha_container .contactSupport").show(), $("#recovery_container").hide()
}

function backtoContactSupport() {
    isPrimaryMode || (mobposition = void 0), showproblemsignin(!0, !1, !0), hidecontactsupport(), isPasswordless && $(".rec_head_text").html("<div class='problemsignin_head'><div class='oa_head_text'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY") + "</div><div class='oa_head_con'>" + I18N.get("IAM.NEWSIGNIN.USE.ALTER.WAY.DESC") + "</div></div>"), $(".problemsignin_head .backoption").hide()
}

function hidecontactsupport() {
    return isPasswordless = !0, deviceauthdetails[deviceauthdetails.resource_name].isAMFA ? (isPasswordless = !1, !1) : ("passwordauth" == deviceauthdetails.resource_name && ("-1" != secondarymodes.indexOf("mzadevice") && (secondarymodes.splice(secondarymodes.indexOf("mzadevice"), 1), secondarymodes.unshift("mzadevice")), allowedmodes.length > 1 ? handlePasswordDetails(JSON.stringify(deviceauthdetails), secondarymodes) : goBackToProblemSignin()), $("<div class=backupstep></div>").insertBefore(".rec_head_text"), $(".backupstep").html(formatMessage(I18N.get("IAM.NEWSIGNIN.BACKUP.STEP"), "2", "2")), $(".rec_head_text").parent().find(".backupstep").show(), $("#recoverymodeContainer,.contactSupport").show(), void $(".contactSupportDesc,.mailbox,.supportSLA,#FAQ,#contactSupport").hide())
}

function openSmartSignInPage() {
    var smartsigninURL = "/signin?QRLogin=true&" + signinParams;
    switchto(smartsigninURL)
}

function enableSplitField(elemID, fieldLength, placeHolder) {
    splitField.createElement(elemID, {
        splitCount: isMobile ? 1 : fieldLength,
        charCountPerSplit: isMobile ? fieldLength : 1,
        isNumeric: !0,
        otpAutocomplete: !0,
        customClass: "customOtp",
        inputPlaceholder: "&#9679;",
        placeholder: placeHolder,
        showAsPlaceholders: isMobile ? !0 : !1
    })
}

function handleMultiDCData() {
    for (var infoURLs = Object.keys(signin_info_urls).map(function(objKeys) {
            return signin_info_urls[objKeys]
        }), i = 0; i < infoURLs.length; i++) {
        if (infoURLs.length - 1 == i) return includeScript(infoURLs[i] + signin_info_uri + "?callback=printUser&dc=" + current_dc, callbackforfailure, !0), !1;
        includeScript(infoURLs[i] + signin_info_uri + "?callback=printUser&dc=" + current_dc)
    }
    return !1
}

function callbackforfailure() {
    return $("#ip_desc").is(":visible") || fediconsChecking(), hideloader(), !1
}

function initiateLogin(signinurl, login_id) {
    var oldForm = document.getElementById("multiDCredirection");
    oldForm && document.documentElement.removeChild(oldForm);
    var form = document.createElement("form");
    form.setAttribute("id", "multiDCredirection"), form.setAttribute("method", "POST"), form.setAttribute("action", signinurl + multidc_origin_uri + "?state=" + state_param), form.setAttribute("target", "_parent");
    var hiddenField = document.createElement("input");
    hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", "LOGIN_ID"), hiddenField.setAttribute("value", login_id), form.appendChild(hiddenField);
    var params = getQueryParams(signinParams);
    for (var key in params) isValid(params[key]) && (hiddenField = document.createElement("input"), hiddenField.setAttribute("type", "hidden"), hiddenField.setAttribute("name", key), hiddenField.setAttribute("value", params[key]), form.appendChild(hiddenField));
    return document.documentElement.appendChild(form), form.submit(), !1
}

function goToUserLogin() {
    return $(".fieldcontainer,#nextbtn,#forgotpassword,.line,.fed_2show,#signuplink").show(), $("#multiDC_container,#createaccount").hide(), fediconsChecking(), $(".signin_head").css("margin-bottom", "30px"), !1
}

function loadTooltipPosition() {
    var element = document.getElementsByClassName("multiDC_info")[0],
        rect = element.getBoundingClientRect(),
        topposition = rect.top,
        leftpostion = rect.left;
    return $(".up-arrow").css("top", topposition + "px"), $(".up-arrow").css("left", leftpostion + "px"), !1
}

function printUser(respData) {
    var user_count = 0,
        elem = "";
    if (IsJsonString(respData) && (respData = JSON.parse(respData)), Object.keys(respData).length <= 0) return !1;
    elem += '<div class="profile_head initiateLogin" info-url=' + signin_info_urls[respData.DC_INFO] + " display-id=" + respData.DISPLAY_ID + '>								<div class="profile_dp" id="profile_img">								<span class="file_lab">									<img id="dp_pic" draggable="false" style="width: 100%; height: 100%;">								</span>							</div>							<div class="profile_info">								<div class="profile_name" id="profile_name">' + decodeHexString(respData.DISPLAY_NAME) + '</div>								<div class="profile_email" id="profile_email">' + respData.DISPLAY_ID + '</div>							</div>							<div class="DC_info"><span class="icon-datacenter"></span><span>' + respData.DC_INFO.toUpperCase() + "</span></div>						</div>", user_count++;
    var tooltip_elem = "<div class='dcInfoCon'><span class='DC_info DC_info-more'><span class='icon-datacenter'></span>" + respData.DC_INFO.toUpperCase() + "</span>						<span class='DC_name-details'>" + respData.DC_INFO.toUpperCase() + " " + I18N.get("IAM.FEDERATED.SIGNUP.CREATE.DATA.CENTER.TITLE") + "</span></div>";
    return user_count > 0 && ($("#account_details").html($("#account_details").html() + elem), multiDCTriggered++, $(".DC-details").html($(".DC-details").html() + tooltip_elem), $(".DC-details #dp_pic").attr("src", respData.LOGO_URL), $(".DC-details #dp_pic").on("error", function() {
        this.src = "/v2/components/images/user_2.png"
    }), $(".fieldcontainer,#nextbtn,#forgotpassword,.line,.fed_2show,#signuplink").hide(), $("#multiDC_container,#multiDC_container .line,#createaccount").show(), $(".signin_head").css("margin-bottom", "24px"), setFooterPosition(), $(".initiateLogin").on("click", function() {
        initiateLogin($(this).attr("info-url"), $(this).attr("display-id"))
    }), loadTooltipPosition()), !1
}

function hideloader() {
    return $(".signin_container").css("visibility", "visible"), isClientPortal || $(".load-bg").is(":visible") && setTimeout(function() {
        document.querySelector(".load-bg").classList.add("load-fade"), setTimeout(function() {
            document.querySelector(".load-bg").style.display = "none", isMobile || $("#login_id").focus()
        }, 50)
    }, 100), setFooterPosition(), !1
}

function isValidCode(code) {
    if (code = (code || "").trim(), 0 != code.length) {
        var codePattern = new RegExp("^([0-9]{" + otp_length + "})$");
        if (codePattern.test(code)) return !0
    }
    return !1
}

function decodeHexString(str) {
    return str = str.replace(/\\x([0-9A-Fa-f]{2})/g, function() {
        return String.fromCharCode(parseInt(arguments[1], 16))
    }), str = str.replace(/\\u([\d\w]{4})/gi, function() {
        return String.fromCharCode(parseInt(arguments[1], 16))
    })
}

function verifyCaptcha(frm) {
    frm.event && "function" == typeof frm.event.preventDefault ? frm.event.preventDefault() : void 0 != window.event && "function" == typeof window.event.preventDefault && window.event.preventDefault();
    var captchavalue = frm.verifycaptcha && frm.verifycaptcha.value.trim();
    return isValid(captchavalue) ? /^[a-zA-Z0-9]*$/.test(captchavalue) ? (isPasswordless ? showAndGenerateOtp("otp", captchavalue) : generateOTP(!1, "otp", captchavalue), !1) : (showCommonError("verifycaptcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.INVALID"), !0), !1) : (showCommonError("verifycaptcha", I18N.get("IAM.SIGNIN.ERROR.CAPTCHA.REQUIRED"), !0), !1)
}

function showCaptchaContainer(jsonStr) {
    var errorMessage = jsonStr.localized_message;
    cdigest = jsonStr.cdigest, showHip(cdigest, "verifycaptcha_img", "verifycaptcha"), $("#verifycaptcha").attr("tabindex", 1), $("#captcha").attr("tabindex", 2), $("#nextbtn").attr("tabindex", 3), "IN107" === jsonStr.errorCode && showCommonError("verifycaptcha", errorMessage), $("#login,.fed_2show,#signuplink").hide(), $("#verifycaptcha_container,#verifycaptcha_container #backup_title,.verifycaptcha_desc,.verifycaptcha_head,#verifycaptcha_container .contactSupport").show();
    var captchaTitle = isPasswordless ? "IAM.NEW.SIGNIN.SMS.HEADER.CAPTCHA.VERIFY.ONEAUTH" : "IAM.NEW.SIGNIN.SMS.HEADER.CAPTCHA.VERIFY",
        captchaDesc = isPasswordless ? "IAM.NEW.SIGNIN.SMS.DESC.CAPTCHA.VERIFY.ONEAUTH" : "IAM.NEW.SIGNIN.SMS.DESC.CAPTCHA.VERIFY";
    return $("#verifycaptcha_container #backup_title").html("<span class='icon-backarrow backoption verifycaptchabackop'></span><span>" + I18N.get(captchaTitle)) + "</span>", $(".verifycaptchabackop").on("click", function() {
        hideCaptchaContainer()
    }), $("#verifycaptcha_container #verifycaptcha_desc").html(formatMessage(I18N.get(captchaDesc), rmobile)), 1 != allowedmodes.length && isPrimaryMode || $(".backoption").hide(), !1
}

function hideCaptchaContainer() {
    return $("#verifycaptcha_container").hide(), $("#login").show(), "lookup" === signinathmode ? $(".fed_2show,#signuplink").show() : "", !1
}

function handleOpenRedirection(pageLoadRedirectionData, redirectionMode) {
    var openRedirectNowBtn = $("#openRedirectNowBtn"),
        openBackToHomeBtn = $("#openBackToHomeBtn"),
        data = IsJsonString(pageLoadRedirectionData) ? JSON.parse(pageLoadRedirectionData) : pageLoadRedirectionData,
        isSimpleRedirect = "undefined" == typeof data.allowed_modes,
        orgName = data.org_name || deviceauthdetails[deviceauthdetails.resource_name] && deviceauthdetails[deviceauthdetails.resource_name].org_name || "",
        domain = data.domain || data[data.allowed_modes[0]].data[0].domain || "";
    if (isSimpleRedirect) openRedirectNowBtn.off("click").on("click", function() {
        switchto(data.redirect_uri)
    }), openBackToHomeBtn.off("click").on("click", function() {
        switchto("/")
    });
    else {
        redirectionMode = "undefined" != typeof redirectionMode ? redirectionMode : data.allowed_modes[0];
        var lookupModes = data || deviceauthdetails[deviceauthdetails.resource_name] && deviceauthdetails[deviceauthdetails.resource_name].modes || {},
            modeEvents = {
                saml: {
                    fn: redirectToSaml,
                    arg: lookupModes.saml && lookupModes.saml.data[0]
                },
                jwt: {
                    fn: switchto,
                    arg: lookupModes.jwt && lookupModes.jwt.data[0] && lookupModes.jwt.data[0].redirect_uri
                },
                oidc: {
                    fn: enableOIDCAuth,
                    arg: lookupModes.oidc && lookupModes.oidc.data[0] && lookupModes.oidc.data[0].oidc_id
                }
            };
        openRedirectNowBtn.off("click").on("click", function() {
            var event = modeEvents[redirectionMode];
            event && "function" == typeof event.fn && event.fn(event.arg)
        }), openBackToHomeBtn.off("click").on("click", function() {
            resetForm()
        })
    }
    signinathmode = "openredirection", $("#open_redirection_desc").html(formatMessage(I18N.get("IAM.OPEN.REDIRECTION.DESC"), domain, orgName)), $(".fed_2show,.banner_newtoold,#signuplink,#forgotpassword,#login").hide(), $("#smartsigninbtn").addClass("hide"), $(".open_redirection_container").show()
}

function hideCountryCode() {
    $(".MobflagContainer, .select_container--country_implement, .select_country_code, #country_code_select, .select2").hide(), $("#login_id").removeClass("textindent62 textindent70"), removeUVindent(), hiddenCountrycode = !0, uvselect.isDropdownOpen("country_code_select") && uvselect.destroySelectDropdown("country_code_select")
}

function showCountryCode() {
    try {
        $(".select_container--country_implement").show(), checkTestIndent(), $(".selection").addClass("showcountry_code"), $(isMobile && !rendermovileUV ? ".MobflagContainer, .select_country_code, #country_code_select" : ".select2").show()
    } catch (err) {
        $(".select_country_code, #country_code_select").css("display", "block")
    }
    $("#login_id").addClass(hideUVFlag ? "textindent70" : "textindent62"), hiddenCountrycode = !1, $(".showCountryCode").slideUp(100), numericEditCounts = 0
}

function WmsliteImpl() {}

function wmsRegisterSuccess() {}

function wmsConnectionFailure() {}

function showPasswordExpiry(pwdpolicy, successCode) {
    $("#signin_div,.rightside_box").hide(), $(".password_expiry_container,.password_expiry_container .signin_head").show(), $(".signin_container").addClass("mod_container");
    var expiry_days = pwdpolicy.expiry_days && pwdpolicy.expiry_days.toString(),
        descMsg = {
            P500: formatMessage(I18N.get("IAM.NEW.PASSWORD.EXPIRY.DESC"), expiry_days),
            P501: I18N.get("IAM.NEW.PASSWORD.EXPIRY.ONE.TIME.DESC"),
            P506: I18N.get("IAM.NEW.PASSWORD.EXPIRY.POLICY.UPDATED.DESC")
        };
    if ($("#password_desc").html(descMsg[successCode]), void 0 != pwdpolicy) {
        $("#npassword_container").on("keyup", function() {
            check_pp()
        });
        var loginName = de("login_id").value;
        $("#changepassword").off("click").on("click", function() {
            updatePassword(pwdpolicy.min_length, pwdpolicy.max_length, loginName)
        })
    }
    if (void 0 == pwdpolicy) var mix_cases = !0,
        spl_char = 1,
        num = 1,
        minlen = 8,
        maxlen = 250;
    else var mix_cases = pwdpolicy.mixed_case,
        spl_char = pwdpolicy.min_spl_chars,
        num = pwdpolicy.min_numeric_chars,
        minlen = pwdpolicy.min_length,
        maxlen = pwdpolicy.max_length;
    return ppValidator = validatePasswordPolicy(pwdpolicy || {
        mixed_case: mix_cases,
        min_spl_chars: spl_char,
        min_numeric_chars: num,
        min_length: minlen,
        max_length: maxlen
    }), ppValidator.init("#npassword_container input"), !1
}

function checkboxEvent() {
    $("#terminate_session_form input[type=checkbox]").change(function() {
        $(this).is(":checked") ? ($("#terminate_session_submit").attr("disabled", !1), $("#terminate_session_submit").css("cursor", "pointer")) : $("#terminate_session_form input[type=checkbox]:visible").each(function() {
            return $(this).is(":checked") ? ($("#terminate_session_submit").attr("disabled", !1), !1) : ($("#terminate_session_submit").attr("disabled", !0), void $("#terminate_session_submit").css("cursor", "default"))
        })
    })
}

function updatePassword(min_Len, max_Len, login_name) {
    remove_error();
    var newpass = $("#new_password").val().trim(),
        confirmpass = $("#new_repeat_password").val().trim(),
        passwordErr = ppValidator.getErrorMsg(newpass);
    if (isEmpty(newpass)) return $("#npassword_container div").hasClass("fielderror") || $("#npassword_container").append('<div class="fielderror"></div>'), showCommonError("npassword", I18N.get("IAM.ERROR.ENTER.NEW.PASS")), $("#new_password").val(""), $("#new_repeat_password").val(""), $("#new_password").focus(), !1;
    if (passwordErr) return $("#new_password").focus(), !1;
    if (newpass == login_name) return $("#npassword_container div").hasClass("fielderror") || $("#npassword_container").append('<div class="fielderror"></div>'), showCommonError("npassword", I18N.get("IAM.PASSWORD.POLICY.LOGINNAME")), $("#new_password").focus(), !1;
    if (isEmpty(confirmpass)) return $("#rpassword_container div").hasClass("fielderror") || $("#rpassword_container").append('<div class="fielderror"></div>'), showCommonError("rpassword", I18N.get("IAM.PASSWORD.CONFIRM.PASSWORD")), $("#new_repeat_password").focus(), !1;
    if (newpass != confirmpass) return $("#rpassword_container div").hasClass("fielderror") || $("#rpassword_container").append('<div class="fielderror"></div>'), showCommonError("rpassword", I18N.get("IAM.NEW.PASSWORD.NOT.MATCHED.ERROR.MSG")), $("#new_repeat_password").focus(), !1;
    var loginurl = uriPrefix + "/signin/v2/password/" + zuid + "/expiry?" + signinParams,
        jsonData = {
            expiry: {
                newpwd: newpass
            }
        },
        encryptionJson = {
            path: "expiry.newpwd",
            value: newpass
        };
    return sendRequestWithTemptoken(loginurl, JSON.stringify(jsonData), !0, handlePasswordExpiry, void 0, encryptionJson, newpass), $("#changepassword span").addClass("zeroheight"), $("#changepassword").addClass("changeloadbtn"), $("#changepassword").attr("disabled", !0), !1
}

function handlePasswordExpiry(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        !isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode ? "success" === jsonStr.expiry.status && ($("#termin_mob").removeClass("show_oneauth"), $(".oneAuthLable").hide(), $(".NIC_contactus").hide(), void 0 != jsonStr.expiry.sess_term_tokens && jsonStr.expiry.sess_term_tokens.length > 0 ? (-1 == jsonStr.expiry.sess_term_tokens.indexOf("rmwebses") && $("#terminate_web_sess").hide(), -1 == jsonStr.expiry.sess_term_tokens.indexOf("rmappses") ? $("#terminate_mob_apps").hide() : -1 == jsonStr.expiry.sess_term_tokens.indexOf("inconeauth") ? $("#termin_mob").removeClass("show_oneauth") : $("#termin_mob").addClass("show_oneauth"), -1 == jsonStr.expiry.sess_term_tokens.indexOf("rmapitok") && $("#terminate_api_tok").hide(), $(".password_expiry_container").hide(), $(".terminate_session_container").show()) : send_terminate_session_request(document.terminate_session_container)) : ($("#npassword_container div").hasClass("fielderror") || $("#npassword_container").append('<div class="fielderror"></div>'), showCommonError("npassword", jsonStr.localized_message))
    } else showTopErrNotification(I18N.get("IAM.ERROR.GENERAL"));
    return $("#changepassword span").removeClass("zeroheight"), $("#changepassword").removeClass("changeloadbtn"), $("#changepassword").attr("disabled", !1), !1
}

function send_terminate_session_request(formElement) {
    var terminate_web = $("#" + formElement.id).find('input[name="signoutfromweb"]').is(":checked"),
        terminate_mob = $("#" + formElement.id).find('input[name="signoutfrommobile"]').is(":checked"),
        terminate_api = $("#" + formElement.id).find('input[name="signoutfromapiToken"]').is(":checked"),
        include_oneAuth = $("#" + formElement.id).find("#include_oneauth").is(":checked");
    if ((terminate_web || terminate_mob || terminate_api || include_oneAuth) && !$("#terminate_session_skip").hasClass("triggerSkip")) {
        var jsonData = {
                expirysessionterminate: {
                    rmwebses: terminate_web,
                    rmappses: terminate_mob,
                    inconeauth: include_oneAuth,
                    rmapitok: terminate_api
                }
            },
            terminate_session_url = uriPrefix + "/signin/v2/password/" + zuid + "/expiryclosesession";
        sendRequestWithTemptoken(terminate_session_url, JSON.stringify(jsonData), !0, handle_terminate_session, "PUT")
    } else showPasswordConfirmation(), $(".ppsuccess_head, .ppsuccess_desc").html(""), $(".ppsuccess_head").html(I18N.get("IAM.NEW.PASSWORD.EXPIRY.PASSWORD.CHANGED")), $(".ppsuccess_desc").html(formatMessage(I18N.get("IAM.NEW.PASSWORD.EXPIRY.PASSWORD.CHANGED.DESC"), deviceauthdetails.lookup.loginid));
    return $("#terminate_session_submit span").addClass("zeroheight"), $("#terminate_session_submit").addClass("changeloadbtn"), $("#terminate_session_submit").attr("disabled", !0), !1
}

function skipterminate() {
    $("#terminate_session_skip").addClass("triggerSkip")
}

function handle_terminate_session(resp) {
    if (IsJsonString(resp)) {
        var jsonStr = JSON.parse(resp),
            statusCode = jsonStr.status_code;
        if (!isNaN(statusCode) && statusCode >= 200 && 299 >= statusCode) {
            if ("SES200" == jsonStr.code) return showPasswordConfirmation(), !1;
            showTopErrNotification(jsonStr.message), $("#terminate_session_submit span").removeClass("zeroheight"), $("#terminate_session_submit").removeClass("changeloadbtn"), $("#terminate_session_submit").attr("disabled", !1)
        } else if ("throttles_limit_exceeded" === jsonStr.cause) showTopErrNotification(jsonStr.message);
        else {
            {
                var error_resp = jsonStr.errors[0];
                error_resp.code, jsonStr.message
            }
            showTopErrNotification(jsonStr.message)
        }
    } else showTopErrNotification(I18N.get("IAM.ERROR.GENERAL"));
    return $("#terminate_session_submit span").removeClass("zeroheight"), $("#terminate_session_submit").removeClass("changeloadbtn"), $("#terminate_session_submit").attr("disabled", !1), !1
}

function showOneAuthTerminate(ele) {
    $("#include_oneauth").attr("checked", !1), ele.checked && $("#termin_mob").hasClass("show_oneauth") ? ($(".oneAuthLable").slideDown(300).addClass("displayOneAuth"), $("#terminate_session_weband_mobile_desc").hide(), $(ele).parents(".checkbox_div").addClass("showOneAuthLable"), $(".showOneAuthLable").addClass("displayBorder")) : ($(".oneAuthLable").removeClass("displayOneAuth"), $(".showOneAuthLable").removeClass("displayBorder"), $("#terminate_session_weband_mobile_desc").show(), $(".oneAuthLable").slideUp(300, function() {
        $(ele).parents(".checkbox_div").removeClass("showOneAuthLable")
    }))
}

function showPasswordConfirmation() {
    $("#success_pcontainer").show(), $(".terminate_session_container,.password_expiry_container").hide(), $(".zoho_logo").css("background-position", "center"), setInterval(function() {
        return 0 >= redirectionTimer ? (window.location.reload(), !1) : ($(".ppsuccess_timer span").text(redirectionTimer), void redirectionTimer--)
    }, 1e3)
}

function validateCP() {
    $("#new_password").val() && $("#new_repeat_password").val() && $("#new_password").val().trim() === $("#new_repeat_password").val().trim() ? ($("#new_repeat_password ~ .show_hide_Confpassword").hide(), $("#new_repeat_password ~ .show_Success").show()) : $("#new_repeat_password ~ span").hasClass("icon-hide") && $("#new_repeat_password ~ span").hasClass("icon-show") || ($("#new_repeat_password ~ .show_hide_Confpassword").show(), $("#new_repeat_password ~ .show_Success").hide())
}

function validatePasswordPolicy(passwordPolicy) {
    passwordPolicy = passwordPolicy || PasswordPolicy.data;
    var initCallback = function(id, msg) {
            var li = document.createElement("li"),
                span = document.createElement("span"),
                p = document.createElement("p");
            return li.appendChild(span), li.appendChild(p), li.setAttribute("id", "pp_" + id), li.setAttribute("class", "pass_policy_rule"), p.textContent = msg, li
        },
        setErrCallback = function(id) {
            return $("#pp_" + id + " span").removeClass("success").removeClass("failure"), $("#pp_" + id + " span").addClass("failure"), id
        };
    return {
        getErrorMsg: function(value, callback) {
            if (passwordPolicy) {
                var isInit = value ? !1 : !0;
                value = value ? value.trim() : "", callback = callback || setErrCallback;
                var rules = ["MIN_MAX", "SPL", "NUM", "CASE"],
                    err_rules = [];
                isInit ? $(".pass_policy_rule span").removeClass("success").removeClass("failure") : ($(".pass_policy_rule span").removeClass("success").removeClass("failure"), $(".pass_policy_rule span").addClass("success"));
                for (var i = 0; i < rules.length; i++) switch (rules[i]) {
                    case "MIN_MAX":
                        (value.length < passwordPolicy.min_length || value.length > passwordPolicy.max_length) && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get("IAM.PASS_POLICY.MIN_MAX"), passwordPolicy.min_length.toString(), passwordPolicy.max_length.toString()) : void 0));
                        break;
                    case "SPL":
                        passwordPolicy.min_spl_chars > 0 && (value.match(new RegExp("[^a-zA-Z0-9]", "g")) || []).length < passwordPolicy.min_spl_chars && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get(1 === passwordPolicy.min_spl_chars ? "IAM.PASS_POLICY.SPL_SING" : "IAM.PASS_POLICY.SPL"), passwordPolicy.min_spl_chars.toString()) : void 0));
                        break;
                    case "NUM":
                        passwordPolicy.min_numeric_chars > 0 && (value.match(new RegExp("[0-9]", "g")) || []).length < passwordPolicy.min_numeric_chars && err_rules.push(callback(rules[i], isInit ? formatMessage(I18N.get(1 === passwordPolicy.min_numeric_chars ? "IAM.PASS_POLICY.NUM_SING" : "IAM.PASS_POLICY.NUM"), passwordPolicy.min_numeric_chars.toString()) : void 0));
                        break;
                    case "CASE":
                        !passwordPolicy.mixed_case || new RegExp("[A-Z]", "g").test(value) && new RegExp("[a-z]", "g").test(value) || err_rules.push(callback(rules[i], isInit ? I18N.get("IAM.PASS_POLICY.CASE") : void 0))
                }
                return isInit && $(".pass_policy_rule span").removeClass("success").removeClass("failure"), err_rules.length && err_rules
            }
        },
        init: function(passInputID) {
            $(".hover-tool-tip").remove();
            var tooltip = document.createElement("div");
            tooltip.setAttribute("class", isMobile ? "hover-tool-tip no-arrow" : "hover-tool-tip");
            var p = document.createElement("p");
            p.textContent = I18N.get("IAM.PASS_POLICY.HEADING");
            var ul = document.createElement("ul"),
                errList = this.getErrorMsg(void 0, initCallback);
            errList && (errList.forEach(function(eachLi) {
                ul.appendChild(eachLi)
            }), tooltip.appendChild(p), tooltip.appendChild(ul), document.querySelector("body").appendChild(tooltip), $(passInputID).on("focus blur", function(e) {
                if ("focus" === e.type) {
                    var offset = document.querySelector(passInputID).getBoundingClientRect();
                    $(".hover-tool-tip").css("rtl" === $("body").attr("dir") ? isMobile ? {
                        top: offset.bottom + $(window).scrollTop() + 8,
                        right: offset.x,
                        width: offset.width - 40
                    } : {
                        top: offset.y + $(window).scrollTop(),
                        right: offset.x + offset.width + 15
                    } : isMobile ? {
                        top: offset.bottom + $(window).scrollTop() + 8,
                        left: offset.x,
                        width: offset.width - 40
                    } : {
                        top: offset.y + $(window).scrollTop(),
                        left: offset.x + offset.width + 15
                    }), $(".hover-tool-tip").css("opacity", 1)
                } else {
                    $(".hover-tool-tip").css("opacity", 0);
                    var offset = document.querySelector(".hover-tool-tip").getBoundingClientRect();
                    $(".hover-tool-tip").css("rtl" === $("body").attr("dir") ? {
                        top: -offset.height,
                        right: -(offset.width + 15)
                    } : {
                        top: -offset.height,
                        left: -(offset.width + 15)
                    })
                }
            }))
        },
        validate: function(formID, passInputID) {
            var str = $(passInputID).val();
            this.getErrorMsg(str, setErrCallback) ? $(".hover-tool-tip").css("opacity", 1) : $(".hover-tool-tip").css("opacity", 0)
        }
    }
}

function initEventListeners() {
    $(".fed_div").click(function() {
        "undefined" != typeof $(this).attr("value") ? createandSubmitOpenIDForm($(this).attr("value").toString()) : ""
    }), $('.input[type="password"]').focus(function() {
        this.value = this.value
    }), $(".Notyou").click(function() {
        var isResetIP = $(this).hasClass("resetip_change");
        resetForm(isResetIP)
    }), $(".showproblemsignin").click(function() {
        showproblemsignin()
    }), $(".optionmod").click(function() {
        return $(this).hasClass("toggle_active") ? !1 : void tryAnotherway($("#verify_totp_container").is(":visible") ? "qr" : "totp")
    }), $("#totpverifybtn").on("click", function(e) {
        submitsignin($("#login"), e)
    }), $(".show_hide_password").click(function() {
        showHidePassword()
    }), $(".showBackupVerificationCode").click(function() {
        showBackupVerificationCode()
    }), $(".signinusepassword").click(function() {
        showPassword()
    }), $(".showmoresigininoption").click(function() {
        return $(this).hasClass("getbackemailverify") ? (showmoresigininoption("getbackemailverify"), !1) : void showmoresigininoption()
    }), $(".changeRecoverOption").click(function() {
        return $(this).hasClass("recovery_passphrase") ? (changeRecoverOption("passphrase"), !1) : void changeRecoverOption("recoverycode")
    }), $(".error_help,.topErrClose").click(function() {
        closeTopErrNotification()
    }), $("#smartsigninbtn").click(function() {
        openSmartSignInPage()
    }), $(".hideOABackupRedirection").click(function() {
        isOauPopupClosed = !0, hideOABackupRedirection()
    }), $("#verifycaptcha_container").submit(function() {
        verifyCaptcha(this)
    }), $("#login_id").on("input", function() {
        checking()
    }), $(".hideEmailOTPVerify").click(function() {
        hideEmailOTPVerify()
    }), $(".login_another").click(function() {
        goToUserLogin()
    }), $(".hideCaptchaContainer").click(function() {
        hideCaptchaContainer()
    }), $(".signinwithldap,.signinwithldappass,#signinwithldaponeauth").click(function() {
        showPassword(!0)
    }), $(".signinwithpassword").click(function() {
        showPassword(!1)
    }), $(".signinwithpassclass").click(function() {
        showPassword()
    }), $(".signinwithtotp").click(function() {
        enableTotpAsPrimary()
    }), $("#signinwithtotponeauth").click(function() {
        showPrimaryTotp()
    }), $(".doaminat").click(function() {
        enableDomain()
    }), $(".signinwithfedoneauth").click(function() {
        showMoreFedOptions()
    }), $("#signinwithotp").click(function() {
        showAndGenerateOtp()
    }), $(".blueforgotpassword").click(function() {
        $(this).hasClass("resetipreset");
        goToForgotPassword()
    }), $(".devices").click(function() {
        updateIcon()
    }), $(".hideEmailOTPInitiate").click(function() {
        hideEmailOTPInitiate()
    }), $(".tryanother").click(function() {
        showTryanotherWay()
    }), $("#createaccount").click(function() {
        register()
    }), $(".signupnowbtn").click(function() {
        register()
    }), $(".rnd_resend").click(function(event) {
        submitsignin($("#login"), event)
    }), $(".externaluser_container_submit").click(function() {
        handleLookupDetails(JSON.stringify(deviceauthdetails), !0)
    }), $("#resendforotp").click(function() {
        return generateOTP(!0), clearCommonError("otp"), clearFieldValue("otp"), !1
    }), $(".resendotpC").click(function() {
        generateOTP(!0)
    }), $(".reloadcaptcha").click(function() {
        return $(this).hasClass("bcaptchaelem") ? (changeHip("bcaptcha_img", "bcaptcha"), !1) : void changeHip()
    }), $("#openoneauth").click(function() {
        QrOpenApp()
    }), $("#signinwithotponeauth").click(function() {
        showAndGenerateOtp("otp")
    }), $(".contactSupport").click(function() {
        var backmethod = !1;
        $(this).hasClass("backtocaptcha") ? backmethod = "backtocaptcha" : $(this).hasClass("backtoalterinfo") && (backmethod = "backtoalterinfo"), showContactSupport(!0, backmethod)
    }), $("#passlessemailverify").click(function() {
        showAndGenerateOtp("email")
    }), $("#hideTryanotherWay").click(function() {
        hideTryanotherWay()
    }), $("#hideBackupOptions").click(function() {
        hideBackupOptions()
    }), $("#goBackToProblemSignin").click(function() {
        goBackToProblemSignin()
    }), $("#passphraseRecover").click(function() {
        showPassphraseContainer()
    }), $("#showIDPs").click(function() {
        showMoreIdps()
    }), $(".zohosignin").click(function() {
        showZohoSignin()
    }), $(".hideBkCodeRedirection").click(function() {
        hideBkCodeRedirection()
    }), $("#recoverybtn_mob,#recoverybtn").click(function() {
        return $(this.children).hasClass("hideEmailOTPInitiate") ? !1 : void showCantAccessDevice()
    }), $("#problemsignin_mob,#problemsignin").click(function() {
        showproblemsignin()
    }), $("#verify_qr_container #openoneauth").click(function() {
        QrOpenApp()
    }), $(".showproblemsigninparam").click(function() {
        showproblemsignin(!0, !1, !0)
    }), $(".verifyBackupCodebtn").click(function() {
        verifyBackupCode()
    }), $(".trustdevice").click(function() {
        var istrust = $(this).hasClass("trustbtn");
        updateTrustDevice(istrust)
    }), $("#restict_btn").click(function() {
        window.location.reload()
    }), $("input,.textbox_otp,.textbox").keydown(function() {
        clearCommonError($(this).attr("id").toLowerCase())
    }), $("#login").submit(function(event) {
        return submitsignin(this, event), !1
    }), $("#backup_container").submit(function(event) {
        return event.preventDefault(), verifyBackupCode(), !1
    }), $("#emailcheck_container").submit(function() {
        return verifyEmailValid(), !1
    }), $("#emailverify_container").submit(function() {
        return verifyEmailOTP(), !1
    }), $("#country_code_select").change(function() {
        changeCountryCode()
    }), $("#showOneAuthTerminate").change(function() {
        showOneAuthTerminate(this)
    }), $("#otp, .mobileonlyinput").on("input", function() {
        allownumonly(this)
    }), $(".service_language").change(function() {
        changeServiceLang("#top_lang")
    }), $("#domaincontainer").change(function() {
        handleDomainChange()
    }), $(".secondary_devices").change(function() {
        changeSecDevice(this)
    }), $(".navbar").click(function() {
        opennavigation()
    }), $(".NIC_close").click(function() {
        closenavigation()
    }), $(".navbarRedirection").click(function() {
        return $(this).attr("data-redirect") && "iamrecovery" == $(this).attr("data-redirect") ? (goToForgotPassword(), !1) : void navbarRedirection($(this).attr("data-val"))
    }), $(".NIC_raise_ticket").click(function() {
        $(".signin_container").hide(), window.showRaiseTicket(), isMobile && $(".CS_container").hide()
    }), $(".show_hide_Confpassword").click(function() {
        showHidePassword($(this).attr("data-id"))
    }), $(".checkbox_div, .oneAuthLable").click(function() {
        checkboxEvent()
    }), $("#terminate_session_skip").click(function() {
        skipterminate()
    }), $(".ppsuccess_button").click(function() {
        return window.location.reload(), !1
    }), $("#npassword_container input").click(function() {
        setPassword(event)
    }), $(".npassinput").on("input", function() {
        validateCP()
    }), $(".npassinput").on("keydown", function() {
        clearCommonError($(this).attr("data-val")), event.stopPropagation()
    }), $("#terminate_session_form").on("submit", function() {
        send_terminate_session_request(this)
    }), $("#goto_resetIP").on("click", function() {
        goToForgotPassword(!0)
    }), $("#changepassword").on("click", function() {
        updatePassword()
    }), $("#domain_verification_container").on("submit", function() {
        event.preventDefault(), verifyDomain(this)
    }), $(".showCountryCodeBtn").on("click", function() {
        showCountryCode()
    })
}
var uvselect = {
    search_text_placeholder: "undefined" != typeof iam_search_text ? iam_search_text : "Search...",
    no_result_text_placeholder: "undefined" != typeof iam_no_result_found_text ? iam_no_result_found_text : "No result found",
    windowClickBind: !1,
    windowResizeBind: !1,
    windowScrollBind: !1,
    windowKeyDownBind: !1,
    searchIconSVG: '<svg width="100%" height="100%" viewBox="0 0 1023.013 1023.013"><path id="search" d="M443.733,0C688.8,0,887.466,198.666,887.466,443.733A441.735,441.735,0,0,1,802.06,705.511l200.957,200.963a68.267,68.267,0,0,1-95.618,97.453l-.926-.909L705.51,802.061a441.735,441.735,0,0,1-261.778,85.406C198.665,887.467,0,688.8,0,443.734S198.665,0,443.732,0Zm0,136.533c-169.662,0-307.2,137.538-307.2,307.2s137.538,307.2,307.2,307.2,307.2-137.538,307.2-307.2-137.538-307.2-307.2-307.2Z" transform="translate(0.001)"/></svg>',
    initDefaultValues: function(id) {
        uvselect[id].realValue = "value", uvselect[id].cntyCodeAttr = "data-num", uvselect[id].flagCodeAttr = "value"
    },
    enableViewMode: function(ids) {
        for (var ids = ids.split(","), i = 0; i < ids.length; i++) {
            var id = ids[i].replace("#", "");
            uvselect.getSelectboxByID(id).addClass("selectbox--viewmode"), uvselect[id].ViewMode = !0
        }
    },
    disableViewMode: function(ids) {
        for (var ids = ids.split(","), i = 0; i < ids.length; i++) {
            var id = ids[i].replace("#", "");
            uvselect.getSelectboxByID(id).removeClass("selectbox--viewmode"), uvselect[id].ViewMode = !1
        }
    },
    idGenerator: function() {
        var S4 = function() {
            return (65536 * (1 + Math.random()) | 0).toString(16).substring(1)
        };
        return S4() + S4()
    },
    escapeHTML: function(value) {
        return value && (value = value.split("#").join("&#x23;"), value = value.split("<").join("&lt;"), value = value.split(">").join("&gt;"), value = value.split('"').join("&quot;"), value = value.split("'").join("&#x27;"), value = value.split("/").join("&#x2F;"), value = value.split("@").join("&#x40;"), value = value.split("+").join("&#x2b;")), value
    },
    decodeHTML: function(value) {
        return value && (value = value.split("&#x23;").join("#"), value = value.split("&lt;").join("<"), value = value.split("&gt;").join(">"), value = value.split("&quot;").join('"'), value = value.split("&#x27;").join("'"), value = value.split("&#x2F;").join("/"), value = value.split("&#x40;").join("@"), value = value.split("&#x2b;").join("+")), value
    },
    decodeHTMLDefault: function(t) {
        return "" != t ? $("<textarea />").html(t).text() : ""
    },
    getScrollParent: function(node) {
        return null == node ? null : node.scrollHeight > node.clientHeight ? node : uvselect.getScrollParent(node.parentNode)
    },
    isElementInViewport: function(el) {
        "function" == typeof jQuery && el instanceof jQuery && (el = el[0]);
        var scroll_parent = window,
            result = uvselect.getScrollParent(el.parentNode);
        null != result && (scroll_parent = result);
        var rect = el.getBoundingClientRect(),
            top_value = scroll_parent.getBoundingClientRect().top,
            left_value = scroll_parent.getBoundingClientRect().left;
        return rect.top >= Math.max(0, top_value) && rect.left >= Math.max(0, left_value) && rect.bottom <= Math.min(window.innerHeight, (0 > top_value ? 0 : top_value) + scroll_parent.clientHeight) && rect.right <= Math.min(window.innerWidth, (0 > left_value ? 0 : left_value) + scroll_parent.clientWidth)
    },
    stringDelimiter: function(sampleInput, delimiter) {
        for (var stringArray = [""], j = 0, i = 0; i < sampleInput.length; i++) sampleInput.charAt(i) == delimiter ? (j++, stringArray.push(""), stringArray[j] += sampleInput.charAt(i)) : stringArray[j] += sampleInput.charAt(i);
        return stringArray
    },
    copyAttributes: function(attribute) {
        "class" === attribute.nodeName ? this.option.className += " " + attribute.nodeValue : this.option.setAttribute("id" === attribute.nodeName ? "data-id" : attribute.nodeName, attribute.nodeValue)
    },
    escapeQuotes: function(input) {
        return input.replace(/['"]/g, function(match) {
            return "'" === match ? "\\'" : '"' === match ? '\\"' : void 0
        })
    },
    setIntentForCntyCode: function(id) {
        var length_ele = uvselect[id].select.siblings("input:first").attr("jsid") ? uvselect[id].select.siblings("input:first") : uvselect[id].select.parent().siblings("input:first");
        if (length_ele.removeClass("uvtextindent0 uvtextindent2 uvtextindent3 uvtextindent4"), $(".uvselect[jsid=" + id + "]").is(":visible")) {
            var value_len = uvselect.getSelectInputByID(id).val().length;
            "undefined" != typeof hideUVFlag && hideUVFlag && length_ele.addClass("hideuvflag"), "2" == value_len ? length_ele.addClass("uvtextindent2") : "3" == value_len ? length_ele.addClass("uvtextindent3") : "4" == value_len && length_ele.addClass("uvtextindent4"), length_ele.focus()
        } else length_ele.addClass("uvtextindent0")
    },
    initialize: function(ele, obj) {
        $(ele).attr("id") || $(ele).attr("id", uvselect.idGenerator());
        var id = $(ele).attr("id");
        if (uvselect[id] || (uvselect[id] = {}), obj)
            if ("object" == typeof obj) uvselect[id] = obj, uvselect.initDefaultValues(id);
            else {
                if (uvselect[id][obj] = !0, uvselect.initDefaultValues(id), "open" == obj && !window.isMobile) return uvselect.destroySelectDropdown(id), uvselect.openDropDown(id), id;
                if ("close" == obj && !window.isMobile) return uvselect.destroySelectDropdown(id), id;
                if ("destroy" == obj) return uvselect.destroySelectDropdown(id), uvselect.destroySelectContainer(id), void(uvselect[id] = {})
            }
        else uvselect.initDefaultValues(id);
        return uvselect[id].select = ele, uvselect.checkForMobileScreen($(ele), obj), obj && ("ViewMode" == obj || obj.ViewMode ? uvselect.enableViewMode(id) : "disableViewMode" == obj && uvselect.disableViewMode(id)), uvselect.final_handlings(id), id
    },
    checkForMobileScreen: function(ele, obj) {
        !window.isMobile || obj && obj.prevent_mobile_style && void 0 != obj.prevent_mobile_style ? uvselect.createSelectContainer(ele) : uvselect.create_mobile_select(ele)
    },
    create_mobile_select: function(t) {
        var id = t.attr("id");
        if (!($(".mobile_select_container[jsid=" + id + "]").length > 0)) {
            var mobile_select_container = document.createElement("div");
            if (mobile_select_container.classList.add("mobile_select_container", id), mobile_select_container.setAttribute("jsid", id), t[0].replaceWith(mobile_select_container), t.attr("label")) {
                var select_label = document.createElement("div");
                select_label.classList.add("select_label"), select_label.setAttribute("jsid", id);
                var label = document.createTextNode(t.attr("label"));
                select_label.appendChild(label), mobile_select_container.appendChild(select_label)
            }
            var mobile_arrow_container = document.createElement("div");
            mobile_arrow_container.classList.add("mobile_arrow_container"), mobile_arrow_container.setAttribute("jsid", id), mobile_select_container.appendChild(mobile_arrow_container), t.addClass("selectbox"), t.addClass("mobile_selectbox"), uvselect[id] && uvselect[id].ViewMode && t.addClass("selectbox--viewmode"), t.attr("jsid", id), mobile_arrow_container.appendChild(t[0]);
            var selectbox_arrow = document.createElement("div");
            selectbox_arrow.classList.add("mobile_uvselect_arrow"), selectbox_arrow.setAttribute("jsid", id), mobile_arrow_container.appendChild(selectbox_arrow);
            var arrow = document.createElement("b");
            selectbox_arrow.appendChild(arrow)
        }
    },
    createSelectContainer: function(t) {
        t.attr("placeholder") || t.attr("placeholder", "");
        var id = t.attr("id");
        uvselect[id].ajax && uvselect.make_ajax_call(id, "");
        var sel_con = document.getElementsByClassName("select_container " + id);
        sel_con.length > 0 && sel_con[0].remove();
        var sel_op_con = document.getElementsByClassName("selectbox_options_container " + id);
        sel_op_con.length > 0 && sel_op_con[0].remove();
        var select_container = document.createElement("div");
        select_container.classList.add("uvselect", "select_container", id), uvselect[id] && uvselect[id].theme && select_container.classList.add("select_container--" + uvselect[id].theme), (t.attr("country-code") || uvselect[id]["country-code"]) && select_container.classList.add("select_container_cntry_code", id);
        var widthVal = "width";
        if ((t.attr("country-code") || uvselect[id]["country-code"]) && (widthVal = "min-width", select_container.style.width = "100%", select_container.style.width = "-moz-fit-content", select_container.style.width = "fit-content"), uvselect[id] && uvselect[id].width ? select_container.style[widthVal] = uvselect[id].width : t.attr("size") && "medium" == t.attr("size") ? select_container.classList.add("select_container_medium") : t.attr("width") ? select_container.style[widthVal] = t.attr("width") : "" != t[0].style.width && "0px" != t[0].style.width && (select_container.style[widthVal] = t[0].style.width), uvselect[id] && uvselect[id]["mobile-width"] && window.isMobile && (select_container.style[widthVal] = uvselect[id]["mobile-width"]), select_container.setAttribute("jsid", id), t.after(select_container), t.attr("label")) {
            var select_label = document.createElement("div");
            select_label.classList.add("select_label");
            var label = document.createTextNode(t.attr("label"));
            select_label.appendChild(label), select_container.appendChild(select_label)
        }
        var selectbox = document.createElement("div");
        if (selectbox.classList.add("selectbox", "basic_selectbox"), (t.attr("multiple") || uvselect[id].multiple) && selectbox.classList.add("multi_selectbox"), uvselect[id] && uvselect[id].theme && selectbox.classList.add("selectbox--" + uvselect[id].theme), uvselect[id] && uvselect[id].ViewMode && selectbox.classList.add("selectbox--viewmode"), (t.attr("country-code") || uvselect[id]["country-code"]) && (selectbox.classList.add("selectbox_cntry_code"), t.siblings().is("input") ? t.siblings("input:first").attr("jsid", id) : $("#" + id).parent().siblings("input:first").attr("jsid", id)), (t.attr("inline-select") || uvselect[id]["inline-select"]) && selectbox.classList.add("inline_selectbox"), (t.attr("button-select") || uvselect[id]["button-select"]) && (selectbox.classList.remove("basic_selectbox"), selectbox.classList.add("button_selectbox")), selectbox.setAttribute("jsid", id), t.attr("tabindex") || uvselect[id].tabindex ? selectbox.setAttribute("tabindex", t.attr("tabindex") || uvselect[id].tabindex) : selectbox.setAttribute("tabindex", 0), select_container.appendChild(selectbox), !t.attr("multiple") && !uvselect[id].multiple) {
            var selectbox_overlay = document.createElement("span");
            selectbox_overlay.classList.add("selectbox_overlay"), selectbox.appendChild(selectbox_overlay)
        }
        if (t.attr("embed-icon-class") || uvselect[id]["embed-icon-class"]) {
            t.attr("embed-icon-class", t.attr("embed-icon-class") || uvselect[id]["embed-icon-class"]);
            var leading_icon = document.createElement("i");
            leading_icon.classList.add("leading_icon", "select_icon"), uvselect[id] && uvselect[id].theme && leading_icon.classList.add("select_icon--" + uvselect[id].theme);
            for (var classes = t.attr("embed-icon-class").split(","), i = 0; i < classes.length; i++) leading_icon.classList.add(classes[i]);
            selectbox.appendChild(leading_icon)
        }
        if (t.attr("multiple") || uvselect[id].multiple) {
            t.attr("multiple", t.attr("multiple") || uvselect[id].multiple);
            var multi_select_input = document.createElement("div");
            multi_select_input.classList.add("select_input", "multiselect_input"), uvselect[id] && uvselect[id].theme && multi_select_input.classList.add("multiselect_input--" + uvselect[id].theme), multi_select_input.setAttribute("jsid", id), multi_select_input.setAttribute("placeholder", t.attr("placeholder")), multi_select_input.setAttribute("multiple", t.attr("multiple") || uvselect[id].multiple), multi_select_input.setAttribute("data-selected", ""), selectbox.appendChild(multi_select_input);
            var selected_cards_container = document.createElement("div");
            selected_cards_container.classList.add("selected_cards_container"), multi_select_input.appendChild(selected_cards_container);
            var select_search_icon = document.createElement("div");
            select_search_icon.classList.add("icon-search", "select_search_icon", "inline_search_icon"), uvselect[id] && uvselect[id].theme && select_search_icon.classList.add("select_search_icon--" + uvselect[id].theme), multi_select_input.appendChild(select_search_icon);
            var select_search_input = document.createElement("input");
            select_search_input.classList.add("select_search_input", "inline_search_input", "multiselect_search_input"), uvselect[id] && uvselect[id].theme && select_search_input.classList.add("select_search_input--" + uvselect[id].theme), select_search_input.setAttribute("jsid", id), select_search_input.setAttribute("placeholder", uvselect.search_text_placeholder), multi_select_input.appendChild(select_search_input)
        } else if (t.attr("button-select") || uvselect[id]["button-select"]) {
            var select_span = document.createElement("span");
            select_span.classList.add("select_span"), uvselect[id] && uvselect[id].theme && select_span.classList.add("select_span--" + uvselect[id].theme), select_span.setAttribute("jsid", id), selectbox.appendChild(select_span)
        } else {
            var select_input = document.createElement("input");
            if (t.attr("zoho-services") || uvselect[id]["zoho-services"]) {
                select_input = document.createElement("div");
                var serviceName = document.createElement("div");
                serviceName.classList.add("uv_service_name");
                var orgName = document.createElement("div");
                orgName.classList.add("uv_org_name"), select_input.appendChild(serviceName), select_input.appendChild(orgName), select_input.setAttribute("zoho-services", t.attr("zoho-services") || uvselect[id]["zoho-services"])
            }
            select_input.classList.add("select_input"), uvselect[id] && uvselect[id].theme && select_input.classList.add("select_input--" + uvselect[id].theme), select_input.setAttribute("jsid", id), select_input.setAttribute("selected-value", ""), select_input.setAttribute("placeholder", t.attr("placeholder")), t.attr("validation") && select_input.setAttribute("validation", t.attr("validation")), (t.attr("country-flag") || uvselect[id]["country-flag"]) && select_input.setAttribute("country-flag", t.attr("country-flag") || uvselect[id]["country-flag"]), (t.attr("country-code") || uvselect[id]["country-code"]) && select_input.classList.add("select_input_cntry_code"), select_input.setAttribute("disabled", "true"), selectbox.appendChild(select_input)
        }
        var selectbox_arrow = document.createElement("span");
        selectbox_arrow.classList.add("selectbox_arrow"), uvselect[id] && uvselect[id].theme && selectbox_arrow.classList.add("selectbox_arrow--" + uvselect[id].theme), selectbox.appendChild(selectbox_arrow);
        var arrow = document.createElement("b");
        selectbox_arrow.appendChild(arrow);
        var input_error = document.createElement("div");
        input_error.classList.add("input_error"), uvselect[id] && uvselect[id].theme && input_error.classList.add("input_error--" + uvselect[id].theme), uvselect[id] && (uvselect[id]["use-attr-as-value"] && "" != uvselect[id]["use-attr-as-value"] && (uvselect[id].realValue = uvselect[id]["use-attr-as-value"]), uvselect[id]["flag-code-attr"] && "" != uvselect[id]["flag-code-attr"] && (uvselect[id].flagCodeAttr = uvselect[id]["flag-code-attr"]), uvselect[id]["country-code-attr"] && "" != uvselect[id]["country-code-attr"] && (uvselect[id].cntyCodeAttr = uvselect[id]["country-code-attr"])), select_container.appendChild(input_error), t.css({
            visibility: "hidden",
            height: "0px",
            width: "0px",
            border: "none",
            "float": "left",
            padding: "0px",
            display: "none"
        }), t.attr("tabindex", -1), uvselect.loadSelectData(t), uvselect.selectbox_handlers(), (t.attr("inline-select") || uvselect[id]["inline-select"] || t.attr("country-code") || uvselect[id]["country-code"]) && uvselect.enable_responsive_input(id), t.unbind("change").on("change", function(e, isLocal) {
            isLocal || uvselect.loadSelectData(t)
        })
    },
    loadSelectData: function(t) {
        var id = t.attr("id");
        if (t.attr("button-select") || uvselect[id]["button-select"]) {
            var select_span = $(".select_span[jsid=" + id + "]")[0];
            return void(select_span.innerText = t.find("option:first").text())
        }
        var select_input = uvselect.getSelectInputByID(id),
            native_sel_option = t.find(":selected");
        if (native_sel_option.length > 0) select_input.val(native_sel_option.text().trim()), select_input.attr("selected-value", native_sel_option.attr(uvselect[id].realValue));
        else if (null != t.val() && void 0 != t.val() && "" != t.val()) {
            for (var value = t.val(), options = uvselect.getAllOptions(id), i = 0; i < options.length; i++) {
                var option_child = options[i];
                if ($(option_child).attr("value") && $(option_child).attr("value") == value) {
                    var selected_option = $(option_child).children("p").text();
                    select_input.val(selected_option).change();
                    break
                }
                select_input.val(value).change()
            }
            select_input.attr("selected-value", t.val())
        }
        if (native_sel_option.length > 0 && getArrayFromObj(native_sel_option[0].attributes).forEach(function(attribute) {
                "id" != attribute.nodeName && "jsid" != attribute.nodeName && "class" != attribute.nodeName && "value" != attribute.nodeName && select_input.attr(attribute.nodeName, attribute.nodeValue)
            }), (t.attr("country-flag") || uvselect[id]["country-flag"]) && uvselect.selectFlag(id), t.attr("zoho-services") || uvselect[id]["zoho-services"]) {
            uvselect.selectServiceIcon(id);
            var select_obj = $(select_input),
                service_name = uvselect.escapeHTML(select_obj.attr("data-service")),
                org_name = uvselect.escapeHTML(select_obj.attr("data-org_name"));
            select_obj.find(".uv_service_name").text(service_name).show(), select_obj.find(".uv_org_name").text(org_name).show(), service_name == org_name ? select_obj.find(".uv_service_name").hide() : "" == org_name && (select_obj.find(".uv_service_name").hide(), select_obj.find(".uv_org_name").text(service_name))
        }
        if ((t.attr("country-code") || uvselect[id]["country-code"]) && select_input.val(native_sel_option.attr(uvselect[id].cntyCodeAttr)), uvselect[id].editSelectionText) {
            var edited_selection_Text = uvselect[id].editSelectionText.call(this, select_input.val());
            select_input.val(edited_selection_Text)
        }
        select_input.change();
        var selectbox = uvselect.getSelectboxByID(id)[0];
        if (uvselect[id].editSelectionMarkup) {
            var edited_selection_template = uvselect[id].editSelectionMarkup.call(this, selectbox);
            edited_selection_template && (selectbox.innerHTML = edited_selection_template)
        }
        if (uvselect[id].templateSelection) {
            var custom_selection_template = uvselect[id].templateSelection.call(this, selectbox);
            custom_selection_template && (selectbox.innerHTML = custom_selection_template)
        }
        if ((t.attr("multiple") || uvselect[id].multiple) && 0 != t.val().length) {
            var input_element = uvselect.getSelectInputByID(id);
            input_element.find(".option_card").remove(), input_element.children("span").addClass("uv_hide");
            var selected = t.children("option:selected"),
                attr_value = [];
            selected.each(function(ind, ele) {
                if (attr_value.push(ele.value), uvselect[id].templateSelection) {
                    if (uvselect[id]["custom-ajax-result"]) var options = uvselect[id]["custom-ajax-result"].results,
                        obj = options.find(function(obj) {
                            return uvselect.decodeHTMLDefault(obj.id) === ele.value ? obj : void 0
                        }),
                        custom_option = uvselect[id].templateSelection.call(this, obj);
                    else var custom_option = uvselect[id].templateSelection.call(this, option);
                    uvselect.addCustomCardToMultiSelect(input_element, ele.value, custom_option)
                } else uvselect.addCardToMultiSelect(input_element, ele.value, ele.innerText)
            }), uvselect.placeSelectOptionContainer(id), input_element.attr("data-selected", attr_value)
        }
    },
    createSelectDropdown: function(id) {
        uvselect.destroySelectDropdown(uvselect.getCurrentDropdown().attr("jsid"));
        var t = uvselect[id].select,
            select_container = uvselect.getSelectContainerByID(id),
            selectbox_options_container = ($(".select_input[jsid=" + id + "]").attr("selected-value"), document.createElement("div"));
        selectbox_options_container.classList.add("selectbox_options_container", id), uvselect[id] && uvselect[id].theme && selectbox_options_container.classList.add("selectbox_options_container--" + uvselect[id].theme), t.attr("dropdown-width") || uvselect[id]["dropdown-width"] ? $(selectbox_options_container).css("width", t.attr("dropdown-width") || uvselect[id]["dropdown-width"]) : $(selectbox_options_container).css("min-width", $(select_container).css("width")), selectbox_options_container.setAttribute("jsid", id), t.attr("immediate-options") && "true" == t.attr("immediate-options") ? select_container[0].appendChild(selectbox_options_container) : document.body.appendChild(selectbox_options_container);
        var dropdown_header = document.createElement("div");
        if (dropdown_header.classList.add("dropdown_header"), uvselect[id] && uvselect[id].theme && dropdown_header.classList.add("dropdown_header--" + uvselect[id].theme), dropdown_header.setAttribute("jsid", id), selectbox_options_container.appendChild(dropdown_header), t.attr("searchable") && "true" == t.attr("searchable") || uvselect[id].searchable) {
            var selectbox_search_container = document.createElement("div");
            selectbox_search_container.classList.add("selectbox_search_container"), uvselect[id] && uvselect[id].theme && selectbox_search_container.classList.add("selectbox_search_container--" + uvselect[id].theme), selectbox_search_container.setAttribute("jsid", id), dropdown_header.appendChild(selectbox_search_container);
            var selectbox_search = document.createElement("div");
            selectbox_search.classList.add("selectbox_search"), uvselect[id] && uvselect[id].theme && selectbox_search.classList.add("selectbox_search--" + uvselect[id].theme), selectbox_search.setAttribute("jsid", id), selectbox_search_container.appendChild(selectbox_search);
            var select_search_icon = document.createElement("div");
            select_search_icon.classList.add("select_search_icon"), uvselect[id] && uvselect[id].theme && select_search_icon.classList.add("select_search_icon--" + uvselect[id].theme), select_search_icon.innerHTML = uvselect.searchIconSVG, selectbox_search.appendChild(select_search_icon);
            var select_search_input = document.createElement("input");
            select_search_input.classList.add("select_search_input"), uvselect[id] && uvselect[id].theme && select_search_input.classList.add("select_search_input--" + uvselect[id].theme), select_search_input.setAttribute("jsid", id), select_search_input.setAttribute("placeholder", uvselect.search_text_placeholder), selectbox_search.appendChild(select_search_input)
        }
        var selectbox_options = document.createElement("ul");
        selectbox_options.classList.add("selectbox_options"), uvselect[id] && uvselect[id].theme && selectbox_options.classList.add("selectbox_options--" + uvselect[id].theme), selectbox_options.setAttribute("jsid", id), selectbox_options_container.appendChild(selectbox_options), uvselect.placeSelectOptionContainer(id), uvselect.createDropdownOptions(id, selectbox_options, !0)
    },
    createDropdownOptions: function(id, selectbox_options, isResultLoading) {
        if (selectbox_options.innerHTML = "", uvselect[id]["custom-ajax-result"]) var children = uvselect[id]["custom-ajax-result"].results;
        else if (uvselect[id].ajax && isResultLoading) {
            var option = document.createElement("li");
            option.classList.add("loading_result"), selectbox_options.appendChild(option);
            var p = document.createElement("p");
            option.appendChild(p), p.appendChild(document.createTextNode("Loading..."))
        } else var t = uvselect[id].select,
            children = t.children();
        for (var value = $(".select_input[jsid=" + id + "]").attr("selected-value"), i = 0; i < children.length; i++) {
            var option_child = children[i],
                option = document.createElement("li");
            if (option.classList.add("option"), selectbox_options.appendChild(option), $(option_child).attr(uvselect[id].realValue) && (value == $(option_child).attr(uvselect[id].realValue) && option.classList.add("selected_option"), t.attr("multiple"))) {
                var multi_selected_options = [],
                    multi_selected_options = uvselect.getMultipleSelectedOptions(id); - 1 != multi_selected_options.indexOf($(option_child).attr(uvselect[id].realValue)) && option.classList.add("uv_hide")
            }
            if (uvselect[id].templateResult) {
                var custom_option_template = uvselect[id].templateResult.call(this, option_child);
                option.innerHTML = custom_option_template, option.setAttribute("value", $(option).children().first().attr("value"));
                var selected_options = uvselect.getMultipleSelectedOptions(id); - 1 != selected_options.indexOf(uvselect.decodeHTML(option_child.id)) && option.classList.add("uv_hide")
            } else {
                if ((t.attr("button-select") || uvselect[id]["button-select"]) && 0 == i) {
                    $(option).remove();
                    continue
                }
                if (0 == i && option_child.getAttribute("id") && -1 != option_child.getAttribute("id").indexOf("default") && (option.classList.remove("option"), option.classList.add("default_option")), getArrayFromObj(option_child.attributes).forEach(uvselect.copyAttributes, {
                        option: option
                    }), t.attr("embed-icon-class")) {
                    var leading_icon_option = document.createElement("i");
                    leading_icon_option.classList.add("leading_icon", "select_icon_option");
                    for (var classes = t.attr("embed-icon-class").split(","), k = 0; k < classes.length; k++) leading_icon_option.classList.add(classes[k]);
                    if ($(option_child).attr("icon-src") && $(leading_icon_option).css("background-image", $(option_child).attr("icon-src")), t.attr("zoho-services") || uvselect[id]["zoho-services"]) {
                        var service_code = "product-icon-" + $(option_child).attr("data-service").toLowerCase();
                        leading_icon_option.classList.add(service_code.replace(/\s/g, ""));
                        for (var icon_path, count = 1; 10 >= count; count++) icon_path = document.createElement("span"), icon_path.classList.value = "path" + count, leading_icon_option.appendChild(icon_path)
                    }(t.attr("country-flag") || uvselect[id]["country-flag"]) && ((t.attr("country-code") || uvselect[id]["country-code"]) && (option_child.text = option_child.text.split("(")[0].trim()), ("undefined" == typeof hideFlag || "number" == typeof hideFlag && !hideFlag) && addFlagIcon($(leading_icon_option), $(option_child).attr(uvselect[id].flagCodeAttr))), option.appendChild(leading_icon_option)
                }
                var p = document.createElement("p");
                if (option.appendChild(p), uvselect[id] && uvselect[id]["break-option-text"])
                    for (var text_nodes = uvselect.stringDelimiter(option_child.text, 1 == uvselect[id]["break-option-text"] ? " " : uvselect[id]["break-option-text"]), j = 0; j < text_nodes.length; j++) {
                        var option_text_span = document.createElement("span");
                        option_text_span.classList.add("option_text_span", "option_text_span_" + (j + 1)), option_text_span.appendChild(document.createTextNode(text_nodes[j])), p.appendChild(option_text_span)
                    } else p.appendChild(document.createTextNode(option_child.text));
                if (uvselect[id].editResultText) {
                    var edited_option_text = uvselect[id].editResultText.call(this, $(p).text());
                    $(p).text(edited_option_text)
                }
                if (t.attr("country-code") || uvselect[id]["country-code"]) {
                    option_child.text = option_child.text.split("(")[0];
                    var country_code = document.createElement("div");
                    country_code.classList.add("country_code"), option.appendChild(country_code), country_code.appendChild(document.createTextNode($(option_child).attr(uvselect[id].cntyCodeAttr)))
                }
                if ((t.attr("zoho-services") || uvselect[id]["zoho-services"]) && (p.innerText = "", p.appendChild($(option_child).attr("data-service") == $(option_child).attr("data-org_name") ? document.createTextNode(uvselect.escapeHTML(option_child.text)) : "" == $(option_child).attr("data-org_name") || void 0 == $(option_child).attr("data-org_name") ? document.createTextNode($(option_child).attr("data-service")) : document.createTextNode(uvselect.escapeHTML($(option_child).attr("data-org_name"))))), uvselect[id].editResultMarkup) {
                    var edited_option_template = uvselect[id].editResultMarkup.call(this, option_child);
                    option.innerHTML = edited_option_template
                }
            }
        }
        uvselect[id]["option-height"] && $(".selectbox_options_container .selectbox_options .option").css({
            height: uvselect[id]["option-height"]
        });
        var option = document.createElement("li");
        option.classList.add("no_result", "uv_hide"), 0 == children.length && option.classList.remove("uv_hide"), selectbox_options.appendChild(option);
        var p = document.createElement("p");
        option.appendChild(p), p.appendChild(document.createTextNode(uvselect.no_result_text_placeholder)), uvselect[id] && uvselect[id].theme && ($(".selectbox_options_container .selectbox_options .option").addClass("option--" + uvselect[id].theme), $(".selectbox_options_container .selectbox_options .loading_result").addClass("loading_result--" + uvselect[id].theme), $(".selectbox_options_container .selectbox_options .option .select_icon_option").addClass("select_icon_option--" + uvselect[id].theme), $(".selectbox_options_container .selectbox_options .option .country_code").addClass("country_code--" + uvselect[id].theme), $(".selectbox_options_container .selectbox_options .no_result").addClass("no_result--" + uvselect[id].theme)), uvselect.dropdown_handlers()
    },
    destroySelectContainer: function(id) {
        var sel_con = document.getElementsByClassName("select_container " + id);
        sel_con.length > 0 && sel_con[0].remove()
    },
    destroySelectDropdown: function(id) {
        uvselect[id] && uvselect[id]["onDropdown:close"] && uvselect[id]["onDropdown:close"].call(this);
        var t = uvselect.getSelectboxByID(id).removeClass("selectbox--open selectbox--open-reverse");
        uvselect[id] && uvselect[id]["country-code"] && (t.parent().siblings().is("input") ? t.parent().siblings("input[jsid=" + id + "]").removeClass("selectbox--open selectbox--open-reverse") : $("#" + id).parent().siblings("input[jsid=" + id + "]").removeClass("selectbox--open selectbox--open-reverse")), (t.attr("place-options-after") || uvselect[id] && uvselect[id]["place-options-after"]) && $("#" + uvselect[id]["place-options-after"]).removeClass("selectbox--open selectbox--open-reverse");
        var sel_op_con = document.getElementsByClassName("selectbox_options_container " + id);
        sel_op_con.length > 0 && sel_op_con[0].remove(), uvselect[id] && uvselect[id]["country-code"] ? uvselect[id].select.siblings("input:first").focus() : uvselect[id] && uvselect[id]["focus-element-on-change"] ? (uvselect.blurAllSelectbox(), $(uvselect[id]["focus-element-on-change"]).focus()) : uvselect.getSelectboxByID(id).focus(), document.removeEventListener("click", uvselect.click_listener, !0), document.removeEventListener("scroll", uvselect.scroll_listener, !0), window.removeEventListener("resize", uvselect.window_resize_listener, !0)
    },
    getSelectContainerByID: function(id) {
        return $(".select_container[jsid=" + id + "]")
    },
    getSelectboxByID: function(id) {
        return $(".selectbox[jsid=" + id + "]")
    },
    getSelectInputByID: function(id) {
        return $(".select_input[jsid=" + id + "]")
    },
    getOptionsContainerByID: function(id) {
        return $(".selectbox_options_container[jsid=" + id + "]")
    },
    isDropdownOpen: function(id) {
        return $(".selectbox_options_container[jsid=" + id + "]").length > 0 ? !0 : !1
    },
    getCurrentDropdown: function() {
        return $(".selectbox_options_container")
    },
    openDropDown: function(id) {
        uvselect.createSelectDropdown(id), uvselect[id] && uvselect[id]["onDropdown:open"] && uvselect[id]["onDropdown:open"].call(this, uvselect.getCurrentDropdown()[0]), uvselect.placeSelectOptionContainer(id), $(".option.selected_option").length > 0 && ($(".option.selected_option")[0].classList.add("option__highlighted"), uvselect.check_if_overflowing(uvselect.getOptionsContainerByID(id).children(".selectbox_options")[0]) && $(".option.selected_option")[0].scrollIntoView({
            block: "nearest",
            inline: "nearest"
        })), uvselect.focusSelectbox(id), $(".select_search_input[jsid=" + id + "]").length > 0 && $(".select_search_input[jsid=" + id + "]").focus(), document.addEventListener("click", uvselect.click_listener, !0), document.addEventListener("scroll", uvselect.scroll_listener, !0), window.addEventListener("resize", uvselect.window_resize_listener, !0), uvselect.dropdown_final_handlings(id)
    },
    closeCurrentDropdown: function() {
        var t = uvselect.getCurrentDropdown(),
            id = t.attr("jsid"),
            q = uvselect.getSelectContainerByID(id),
            r = q.children(".selectbox").children(".select_input");
        r.blur(), uvselect.blurAllSelectbox(), uvselect.destroySelectDropdown(id)
    },
    focusSelectbox: function(id) {
        uvselect.blurAllSelectbox(), uvselect[id]["country-code"] ? uvselect.getSelectContainerByID(id).siblings("input:first").addClass("selectbox--focus") : uvselect.getSelectboxByID(id).addClass("selectbox--focus")
    },
    blurAllSelectbox: function() {
        $(".selectbox").removeClass("selectbox--focus"), $(".selectbox").parent().siblings("input:first").removeClass("selectbox--focus")
    },
    getSelectInput: function(select_container) {
        var t = select_container;
        return !select_container instanceof jQuery && (t = $(select_container)), t.children(".selectbox").children(".select_input")
    },
    getAllOptions: function(id) {
        return $(".selectbox_options[jsid=" + id + "]").children(".option")
    },
    getAllNativeSelectOptions: function(id) {
        return $(uvselect[id].select).children("option")
    },
    embedSelectedIcon: function(option_icon, select_icon) {
        select_icon.css({
            background: option_icon.css("background")
        })
    },
    selectFlag: function(id) {
        var select_icon = uvselect.getSelectboxByID(id).children(".leading_icon");
        if (uvselect[id].select) {
            var flag_code = uvselect[id].select.find(":selected").attr(uvselect[id].flagCodeAttr);
            select_icon[0].innerHTML = "", (flag_code && "undefined" == typeof hideFlag || "number" == typeof hideFlag && !hideFlag) && addFlagIcon(select_icon, flag_code)
        }
    },
    selectServiceIcon: function(id) {
        var servicepos = "product-icon-" + $(".select_input[jsid=" + id + "]").attr("data-service").toLowerCase(),
            select_icon = uvselect.getSelectboxByID(id).children(".leading_icon");
        if (select_icon.removeClass(function(index, className) {
                return (className.match(/\bproduct-icon-\S+/g) || []).join(" ")
            }), 0 == select_icon.children().length)
            for (var icon_path, count = 1; 10 >= count; count++) icon_path = document.createElement("span"), icon_path.classList.value = "path" + count, select_icon.append(icon_path);
        select_icon.addClass(servicepos)
    },
    addCardToMultiSelect: function(ele, value, text) {
        var t = ele;
        !ele instanceof jQuery && (t = $(ele));
        var option_card = document.createElement("div");
        option_card.classList.add("option_card", "default_card"), option_card.setAttribute("value", value), t[0].appendChild(option_card), option_card.appendChild(document.createTextNode(text));
        var icon_minus = document.createElement("div");
        icon_minus.classList.add("remove_option_card", "icon-Minus"), option_card.appendChild(icon_minus)
    },
    addCustomCardToMultiSelect: function(ele, value, custom_template) {
        var t = ele;
        !ele instanceof jQuery && (t = $(ele));
        var option_card = document.createElement("div");
        option_card.classList.add("option_card"), option_card.setAttribute("value", value), t.children(".selected_cards_container")[0].appendChild(option_card), option_card.innerHTML = custom_template;
        var multiselect_remove = document.createElement("b");
        multiselect_remove.classList.add("multiselect_remove"), multiselect_remove.setAttribute("role", "presentation"), $(option_card).prepend(multiselect_remove);
        var isOverflow = uvselect.check_if_overflowing(t.parent()[0]);
        isOverflow ? t.siblings(".selectbox_arrow").addClass("uv_hide") : t.siblings(".selectbox_arrow").removeClass("uv_hide")
    },
    removeCardFromMultiSelect: function(ele, parentele) {
        if (parentele.length > 0) {
            var t = ele,
                q = parentele;
            ele instanceof jQuery && (t = ele[0]), parentele instanceof jQuery && (q = parentele[0]), q.removeChild(t)
        }
    },
    deSelectFromMultiSelect: function(id, val_to_remove) {
        for (var options = uvselect.getAllOptions(id), input_element = uvselect.getSelectInputByID(id), i = 0; i < options.length; i++) {
            var option_child = options[i];
            $(option_child).attr("value") && $(option_child).attr("value") == val_to_remove && $(option_child).removeClass("uv_hide")
        }
        var selected = uvselect.getMultipleSelectedOptions(id);
        selected.splice(selected.indexOf(val_to_remove), 1), input_element.attr("data-selected", selected), uvselect[id].select.val(selected).trigger("change", [!0]), 0 == input_element.children(".option_card").length && input_element.children("span").removeClass("uv_hide")
    },
    getMultipleSelectedOptions: function(id) {
        var t = uvselect.getSelectContainerByID(id),
            input_element = uvselect.getSelectInput(t);
        return input_element.attr("data-selected").split(",")
    },
    placeSelectOptionContainer: function(id) {
        var t = uvselect.getSelectboxByID(id);
        uvselect[id]["country-code"] && (t = t.parent().siblings().is("input") ? t.parent().siblings("input[jsid=" + id + "]") : $("#" + id).parent().siblings("input[jsid=" + id + "]")), (t.attr("place-options-after") || uvselect[id]["place-options-after"]) && (t = $("#" + uvselect[id]["place-options-after"]));
        var u = uvselect.getOptionsContainerByID(id);
        if (0 != u.length) {
            var rect = t[0].getBoundingClientRect(),
                selectbox_pos = rect.top + t.outerHeight();
            if (window.innerHeight - selectbox_pos < u.outerHeight() && rect.top > u.outerHeight()) {
                var bottom_px = window.innerHeight - rect.top;
                u.css("top", ""), u.css("bottom", bottom_px + "px"), u[0].getBoundingClientRect().bottom != bottom_px && (bottom_px += u[0].getBoundingClientRect().bottom - rect.top, u.css("bottom", bottom_px + "px")), u.css("flex-direction", "column-reverse"), t.attr("inline-select") || uvselect[id]["inline-select"] || (u.removeClass("selectbox_options_container--open"), u.addClass("selectbox_options_container--open-reverse"), t.removeClass("selectbox--open"), t.addClass("selectbox--open-reverse"))
            } else {
                var top_px = rect.top + t.outerHeight();
                u.css("top", top_px + "px"), u.css("bottom", ""), u[0].getBoundingClientRect().top != top_px && (top_px = top_px + (rect.top - u[0].getBoundingClientRect().top) + t.outerHeight(), u.css("top", top_px + "px")), u.css("flex-direction", "column"), t.attr("inline-select") || uvselect[id]["inline-select"] || (u.removeClass("selectbox_options_container--open-reverse"), u.addClass("selectbox_options_container--open"), t.removeClass("selectbox--open-reverse"), t.addClass("selectbox--open"))
            }
            if (rect = t[0].getBoundingClientRect(), uvselect[id]["dropdown-align"] && "right" == uvselect[id]["dropdown-align"]) {
                var right_px = rect.right;
                if (u.css("right", right_px), u[0].getBoundingClientRect().right != right_px) {
                    var right_px = right_px + (u[0].getBoundingClientRect().right - rect.right);
                    u.css("right", right_px)
                }
            } else {
                var left_px = rect.left;
                if (u.css("left", left_px), u[0].getBoundingClientRect().left != left_px) {
                    var left_px = left_px + (rect.left - u[0].getBoundingClientRect().left);
                    u.css("left", left_px)
                }
            }
            0 == u.height() && u.addClass("uv_hide")
        }
    },
    check_if_overflowing: function(element) {
        return element.offsetHeight < element.scrollHeight || element.offsetWidth < element.scrollWidth ? !0 : !1
    },
    selectbox_handlers: function() {
        function onRemoveOptionCardClick(e) {
            var t = $(e.target).parent(),
                val_to_remove = t.attr("value"),
                input_element = t.parent().parent(),
                id = input_element.attr("jsid");
            uvselect.deSelectFromMultiSelect(id, val_to_remove), uvselect.removeCardFromMultiSelect(t, t.parent());
            var q = uvselect.getOptionsContainerByID(id);
            q.removeClass("uv_hide"), uvselect.placeSelectOptionContainer(id), uvselect[id] && uvselect[id]["onDropdown:remove"] && uvselect[id]["onDropdown:remove"].call(this, uvselect[id].select.find(":selected")[0], this), e.preventDefault(), e.stopPropagation()
        }
        $(".selectbox").unbind("click").click(function(e) {
            if (e.target.classList.contains("remove_option_card") || e.target.classList.contains("multiselect_remove")) return void onRemoveOptionCardClick(e);
            if (!e.target.classList.contains("mobile_selectbox")) {
                var t = $(this),
                    id = t.attr("jsid");
                uvselect.isDropdownOpen(id) ? uvselect.destroySelectDropdown(id) : uvselect.openDropDown(id)
            }
        }), $(".select_input").unbind("blur").blur(function() {
            var t = $(this),
                q = t.parent();
            if (t.attr("validation")) {
                var l = q.siblings(".select_label").text(),
                    str = t.val(),
                    validation = t.attr("validation");
                validation = validation.split(","), -1 != validation.indexOf("special-characters") && 0 == /^[a-zA-Z0-9- ]*$/.test(str) ? (this.setCustomValidity("special characters"), q.children(".input_error").text(l + " does not support special characters"), q.addClass("inValid")) : -1 != validation.indexOf("mandatory") && null == str | "" == str ? (this.setCustomValidity("mandatory"), q.siblings(".input_error").text(l + " cannot be empty"), q.addClass("inValid")) : (this.setCustomValidity(""), q.siblings(".input_error").html(""), q.removeClass("inValid"))
            }
        }), $(".select_input").on("invalid", function() {}), uvselect.windowKeyDownBind || ($(document).on("keydown", function(event) {
            var focused_ele = document.activeElement;
            if ($(".selectbox_options_container").not(".uv_hide").length > 0) {
                var t = $(".selectbox_options_container").not(".uv_hide"),
                    scrollable = !1;
                uvselect.check_if_overflowing(t.children(".selectbox_options")[0]) && (scrollable = !0);
                var id = t.attr("jsid"),
                    option_list = t.children(".selectbox_options").children(".option").not(".uv_hide"),
                    current_option = option_list.index(option_list.filter(".option__highlighted"));
                switch (event.keyCode) {
                    case 38:
                        uvselect.getAllOptions(id).removeClass("option__highlighted"), 0 > current_option ? (option_list[0].classList.add("option__highlighted"), scrollable && option_list[0].scrollIntoView({
                            block: "nearest",
                            inline: "nearest"
                        })) : (current_option = current_option > 0 ? --current_option : 0, option_list[current_option].classList.add("option__highlighted"), scrollable && option_list[current_option].scrollIntoView({
                            block: "nearest",
                            inline: "nearest"
                        })), event.preventDefault();
                        break;
                    case 40:
                        uvselect.getAllOptions(id).removeClass("option__highlighted"), 0 > current_option ? (option_list[0].classList.add("option__highlighted"), scrollable && option_list[0].scrollIntoView({
                            block: "nearest",
                            inline: "nearest"
                        })) : (current_option = current_option < option_list.length - 1 ? ++current_option : option_list.length - 1, option_list[current_option].classList.add("option__highlighted"), scrollable && option_list[current_option].scrollIntoView({
                            block: "nearest",
                            inline: "nearest"
                        })), event.preventDefault();
                        break;
                    case 13:
                        option_list[current_option] && (option_list[current_option].click(), event.preventDefault());
                        break;
                    case 27:
                        uvselect.closeCurrentDropdown(), event.preventDefault()
                }
            } else if (focused_ele.classList.contains("selectbox") && focused_ele.parentElement.classList.contains("uvselect") && !focused_ele.classList.contains("selectbox--viewmode")) switch (event.keyCode) {
                case 13:
                    uvselect.openDropDown(focused_ele.getAttribute("jsid")), event.preventDefault()
            }
        }), uvselect.windowKeyDownBind = !0)
    },
    dropdown_handlers: function() {
        $(".selectbox_options .option").unbind("click").click(function() {
            var t = $(this),
                q = t.parent(),
                id = q.attr("jsid"),
                selected_option = t.children("p").text(),
                value = t.attr("id" == uvselect[id].realValue ? "data-id" : uvselect[id].realValue);
            if ("undefined" != value) {
                if (uvselect[id] && uvselect[id]["onDropdown:selecting"] && uvselect[id]["onDropdown:selecting"].call(this, uvselect[id].select.find(":selected")[0], this), uvselect[id].select.find("option[" + uvselect[id].realValue + "='" + uvselect.escapeQuotes(value) + "']").length < 1) {
                    var option = document.createElement("option");
                    option.setAttribute(uvselect[id].realValue, value), uvselect[id].select[0].appendChild(option)
                }
                if ("true" == t.attr("unselectable")) return void(uvselect[id] && uvselect[id]["onDropdown:select"] && uvselect[id]["onDropdown:select"].call(this, this));
                var p = uvselect.getSelectContainerByID(id),
                    selectbox = uvselect.getSelectboxByID(id),
                    input_element = uvselect.getSelectInput(p);
                if (p.children(".input_error").html(""), p.children(".selectbox").removeClass("inValid"), (t.attr("zoho-services") || uvselect[id]["zoho-services"]) && (input_element.attr("data-service", ""), input_element.attr("data-org_name", "")), getArrayFromObj(t[0].attributes).forEach(function(attribute) {
                        "id" != attribute.nodeName && "jsid" != attribute.nodeName && "class" != attribute.nodeName && "value" != attribute.nodeName && "style" != attribute.nodeName && input_element.attr(attribute.nodeName, attribute.nodeValue)
                    }), input_element.attr("multiple")) {
                    input_element.children("span").addClass("uv_hide");
                    var selected = [];
                    if ("" != input_element.attr("data-selected") && input_element.attr("data-selected").split(",").forEach(function(option) {
                            selected.push(option)
                        }), -1 == selected.indexOf(value)) {
                        if (selected.push(value), uvselect[id].templateSelection) {
                            if (uvselect[id]["custom-ajax-result"]) var options = uvselect[id]["custom-ajax-result"].results,
                                obj = options.find(function(o) {
                                    return uvselect.decodeHTMLDefault(o.id) === value ? o : void 0
                                }),
                                custom_option = uvselect[id].templateSelection.call(this, obj);
                            else var custom_option = uvselect[id].templateSelection.call(this, option);
                            uvselect.addCustomCardToMultiSelect(input_element, value, custom_option)
                        } else uvselect.addCardToMultiSelect(input_element, value, selected_option);
                        t.addClass("uv_hide"), uvselect.placeSelectOptionContainer(id)
                    }
                    if (input_element.attr("data-selected", selected), value) {
                        var sel_val = uvselect[id].select.val(); - 1 == sel_val.indexOf(value) && sel_val.push(value), uvselect[id].select.val(sel_val).trigger("change", [!0])
                    }
                    $(".multiselect_search_input[jsid=" + id + "]").val(""), uvselect[id] && uvselect[id]["onDropdown:select"] && uvselect[id]["onDropdown:select"].call(this, uvselect[id].select.find(":selected")[0], this)
                } else {
                    if (uvselect[id].templateSelection) {
                        var custom_selection_template = uvselect[id].templateSelection.call(this, option);
                        selectbox.innerHTML = custom_selection_template
                    }
                    if (t.attr("country-code") || uvselect[id]["country-code"]) input_element.val(t.attr(uvselect[id].cntyCodeAttr)).change();
                    else if (uvselect[id].editSelectionText) {
                        var edited_selection_Text = uvselect[id].editSelectionText.call(this, selected_option, value);
                        input_element.val(edited_selection_Text).change()
                    } else input_element.val(selected_option).change();
                    if (input_element.attr("selected-value", value), t.attr("zoho-services") || uvselect[id]["zoho-services"]) {
                        var service_name = uvselect.escapeHTML(input_element.attr("data-service")),
                            org_name = uvselect.escapeHTML(input_element.attr("data-org_name"));
                        input_element.find(".uv_service_name").text(service_name).show(), input_element.find(".uv_org_name").text(org_name).show(), service_name == org_name ? input_element.find(".uv_service_name").hide() : "" == org_name && (input_element.find(".uv_service_name").hide(), input_element.find(".uv_org_name").text(service_name))
                    }
                    if (value && "value" == uvselect[id].realValue) uvselect[id].select.val(value).trigger("change", [!0]);
                    else if (value) {
                        for (var native_options = uvselect[id].select[0].options, i = 0; i < native_options.length; i++) {
                            var n_option = native_options[i];
                            if (n_option.getAttribute(uvselect[id].realValue) === value) {
                                n_option.selected = !0;
                                break
                            }
                        }
                        uvselect[id].select.trigger("change", [!0])
                    } else uvselect[id].select.val(selected_option).trigger("change", [!0]);
                    if (t.children(".leading_icon").length > 0 && (input_element.attr("country-flag") || uvselect[id]["country-flag"] ? uvselect.selectFlag(id) : input_element.attr("zoho-services") || uvselect[id]["zoho-services"] ? uvselect.selectServiceIcon(id) : uvselect.embedSelectedIcon(t.children(".leading_icon"), input_element.siblings(".leading_icon"))), uvselect[id].editSelectionMarkup) {
                        var edited_selection_template = uvselect[id].editSelectionMarkup.call(this, selectbox);
                        selectbox.innerHTML = edited_selection_template
                    }
                    uvselect[id] && uvselect[id]["onDropdown:select"] && uvselect[id]["onDropdown:select"].call(this, uvselect[id].select.find(":selected")[0], this), q.siblings(".selectbox_search").children(".select_search_input").val(""), q.children(".option").removeClass("uv_hide"), uvselect.destroySelectDropdown(id)
                }
            }
        }), $(".select_search_input").unbind("keyup").on("keyup", function(event) {
            if (38 != event.keyCode && 40 != event.keyCode && 13 != event.keyCode && 27 != event.keyCode) {
                var t = $(this),
                    q = t.parent(),
                    id = t.attr("jsid"),
                    g = t.val().toLowerCase().replace(/\s/g, "");
                if (q.parent().removeClass("uv_hide"), uvselect[id] && uvselect[id].ajax) return void uvselect.make_ajax_call(id, g);
                var multi_selected_options = [],
                    input_element = $(".select_input[jsid=" + id + "]");
                if (input_element.attr("multiple")) var multi_selected_options = uvselect.getMultipleSelectedOptions(id);
                var options = uvselect.getAllOptions(id),
                    arr = getArrayFromObj(options),
                    highlighted = !1;
                arr.forEach(function(item) {
                    for (var s = "", children = $(item).children(), i = 0; i < children.length; i++) s += children[i].textContent.toLowerCase().replace(/\s/g, ""); - 1 != s.indexOf(g) ? (-1 == multi_selected_options.indexOf($(item).attr("value")) && $(item).removeClass("uv_hide"), $(".no_result").addClass("uv_hide"), highlighted || (item.classList.add("option__highlighted"), item.scrollIntoView({
                        block: "nearest",
                        inline: "nearest"
                    })), highlighted = !0) : ($(item).addClass("uv_hide"), item.classList.remove("option__highlighted"), 0 == $(".selectbox_options .option").not(".uv_hide").length && $(".no_result").removeClass("uv_hide"))
                })
            }
        }), $(".multiselect_search_input").unbind("keydown").on("keydown", function(event) {
            if (38 != event.keyCode && 40 != event.keyCode && 27 != event.keyCode) {
                var t = $(this),
                    id = t.attr("jsid");
                if (13 == event.keyCode) {
                    if (!uvselect[id]["custom-option-handler"]) return;
                    uvselect.default_custom_option_handler(this, $(this).val().toLowerCase()) && (t.val(""), event.preventDefault())
                }
                switch (event.keyCode) {
                    case 8:
                        if ("" == t.val()) {
                            var last_child = t.siblings(".selected_cards_container").children().last(),
                                value = last_child.attr("value");
                            uvselect.deSelectFromMultiSelect(id, value), last_child.remove(), uvselect.placeSelectOptionContainer(id), t.focus(), event.preventDefault()
                        }
                }
            }
        })
    },
    click_listener: function(event) {
        !event || $(event.target).closest(".select_container").length || $(event.target).closest(".selectbox_options_container").length || uvselect.closeCurrentDropdown()
    },
    scroll_listener: function(event) {
        if (event && !$(event.target).closest(".selectbox_options").length && uvselect.getCurrentDropdown().length) {
            var id = uvselect.getCurrentDropdown().attr("jsid");
            uvselect.isElementInViewport(uvselect.getSelectboxByID(id)) && uvselect.placeSelectOptionContainer(id)
        }
    },
    window_resize_listener: function() {
        var u = uvselect.getCurrentDropdown(),
            id = u.attr("jsid");
        u.length > 0 && uvselect.placeSelectOptionContainer(id)
    },
    native_select_onchange_listener: function(event) {
        var native_select = $(event.target);
        uvselect.loadSelectData(native_select)
    },
    enable_responsive_input: function(id) {
        var t = uvselect.getSelectInputByID(id);
        t[0].style.width = t[0].value.length + 1 + "ch", uvselect.setIntentForCntyCode(id), t.unbind("change").on("change", function() {
            this.style.width = this.value.length + 1 + "ch", uvselect.setIntentForCntyCode(id)
        })
    },
    final_handlings: function(id) {
        var handle_container = !1;
        if (de("zcontiner") && "none" == de("zcontiner").style.display) {
            handle_container = !0;
            var visibility = de("zcontiner").style.visibility,
                display = de("zcontiner").style.display;
            de("zcontiner").style.visibility = "hidden", de("zcontiner").style.display = "block"
        }
        uvselect.getSelectboxByID(id).outerHeight(!0) > 45 && uvselect.getSelectboxByID(id).children(".selectbox_arrow").children("b").css({
            "border-width": "4px"
        }), handle_container && (de("zcontiner").style.display = display, de("zcontiner").style.visibility = visibility)
    },
    dropdown_final_handlings: function(id) {
        uvselect.getOptionsContainerByID(id).outerWidth(!0) && uvselect.getOptionsContainerByID(id).css({
            width: uvselect.getOptionsContainerByID(id).outerWidth(!0)
        });
        var dropdown_header = uvselect.getOptionsContainerByID(id).children(".dropdown_header");
        (0 == dropdown_header.children().length || "" == dropdown_header[0].innerHTML) && dropdown_header.css("all", "unset")
    },
    make_ajax_call: function(id, query) {
        var aj = uvselect[id].ajax;
        if ("" != query) {
            var data_pre_obj = {};
            data_pre_obj.term = query
        }
        $.ajax({
            url: aj.url,
            type: aj.type,
            dataType: aj.dataType,
            data: data_pre_obj ? aj.data.call(this, data_pre_obj) : "",
            success: function(data, params) {
                uvselect[id]["ajax-result-data"] = data, uvselect[id]["ajax-result-params"] = params, uvselect[id]["custom-ajax-result"] = aj.processResults.call(this, data, params), uvselect.isDropdownOpen(id) && uvselect.createDropdownOptions(id, $(".selectbox_options[jsid=" + id + "]")[0], !1)
            },
            error: function(error) {
                aj.error.call(this, error)
            }
        })
    },
    default_custom_option_handler: function(element, value) {
        var id = $(element).attr("jsid");
        if (uvselect[id]["custom-option-handler"] && (value = uvselect[id]["custom-option-handler"].call(this, element, value)), "" != value) {
            var input_element = uvselect.getSelectInputByID(id);
            if (input_element.attr("multiple")) {
                input_element.children("span").addClass("uv_hide");
                var selected = [];
                if ("" != input_element.attr("data-selected") && input_element.attr("data-selected").split(",").forEach(function(option) {
                        selected.push(option)
                    }), -1 == selected.indexOf(value)) {
                    if (selected.push(value), uvselect[id]["custom-option-templateSelection"]) {
                        var custom_option = uvselect[id]["custom-option-templateSelection"].call(this, value);
                        uvselect.addCustomCardToMultiSelect(input_element, value, custom_option)
                    } else uvselect.addCardToMultiSelect(input_element, value, value);
                    uvselect.placeSelectOptionContainer(id)
                }
                if (input_element.attr("data-selected", selected), uvselect[id].select.find("option[value='" + value + "']").length < 1) {
                    var option = document.createElement("option");
                    option.setAttribute("value", value), uvselect[id].select[0].appendChild(option)
                }
                if (value) {
                    var sel_val = uvselect[id].select.val(); - 1 == sel_val.indexOf(value) && sel_val.push(value), uvselect[id].select.val(sel_val).trigger("change", [!0])
                }
                return !0
            }
        }
        return !1
    }
};
$.fn.uvselect = function(obj) {
    return select_ele = this, select_ele.each(function(ind) {
        uvselect.initialize($(select_ele[ind.toString()]), obj)
    }), this
};
var I18N = {
        data: {},
        load: function(arr) {
            return $.extend(this.data, arr), this
        },
        get: function(key, args) {
            if ("object" == typeof key) {
                for (var i in key) key[i] = I18N.get(key[i]);
                return key
            }
            var msg = this.data[key] || key;
            return args ? (arguments[0] = msg, Util.format.apply(this, arguments)) : msg
        }
    },
    Util = {
        euc: function(value) {
            return encodeURIComponent(value)
        },
        duc: function(value) {
            return decodeURIComponent(value)
        },
        format: function(msg) {
            if (msg)
                for (var i = 1; i < arguments.length; i++) msg = msg.replace(new RegExp("\\{" + (i - 1) + "\\}", "g"), arguments[i]);
            return msg
        }
    };
PasswordPolicy = {
    data: {},
    load: function(arr) {
        return $.extend(this.data, arr), this
    },
    isHaveMinLength: function(password) {
        return password.length >= this.data.min_length
    },
    isHavingSpecialChars: function(password) {
        return (password.match(new RegExp("[^a-zA-Z0-9]", "g")) || []).length >= this.data.min_spl_chars
    },
    isHavingNumber: function(password) {
        return (password.match(new RegExp("[0-9]", "g")) || []).length >= this.data.min_numeric_chars
    },
    isHavingUpperCase: function(password) {
        return new RegExp("[A-Z]", "g").test(password)
    },
    isHavingLowerCase: function(password) {
        return new RegExp("[a-z]", "g").test(password)
    }
}, window.jquery && $ === jquery && $(window).resize(function() {
    setFooterPosition()
}), window.jquery && $ === jquery && $("document").ready(function() {
    setFooterPosition(), $.fn.focus = function() {
        return this.length && $(this)[0].focus(), $(this)
    }
}), window.jquery && $ === jquery && $(function() {
    $("input").keyup(function() {
        $(".error_notif").remove()
    })
});
var signinathmode = "lookup",
    reload_page = "",
    isFormSubmited = isPasswordless = isSecondary = isPrimaryDevice = isTroubleSignin = isRecovery = isCountrySelected = isFaceId = isPrimaryMode = isEmailVerifyReqiured = triggeredUser = isShowEnableMore = isLdapVisible = oaNotInstalled = mfaBanner = isOauPopupClosed = domainverification = hiddenCountrycode = !1,
    allowedmodes, digest, rmobile, zuid, temptoken, mdigest, deviceid, prefoption, devicename, emobile, deviceauthdetails, cdigest, isResend, redirectUri, secondarymodes, prev_showmode, qrtempId, mobposition, bioType, restrictTrustMfa, resendTimer, trustMfaDays, bannerTimer, oldsigninathmode, emailposition, recoverymodes, oneauthgrant, isSignupCaptcha, balanceBannerTime, bannerCount, resumeBannerIn, isBannerOnHold, isBannerHardPaused, bannerPosition, listofdomain, AMFA_edomain_resp, AMFA_rdomain_resp, callmode = "primary",
    oadevicepos = multiDCTriggered = numericEditCounts = 0,
    mzadevicepos = void 0,
    adminEmail, contactAdminHelpdoc = "",
    AMFAotpThreshold, MFAotpThresholdmob, resendcheck, prevoption, ppValidator, wmscount = 0,
    _time, verifyCount = 0,
    totalCount = 0,
    isWmsRegistered = !1,
    wmscallmode, wmscallapp, wmscallid, PriotpThreshold = 3;
WmsliteImpl.skipWMSRedirection = !1, WmsliteImpl.serverdown = function() {
    wmsConnectionFailure()
}, WmsliteImpl.serverup = function() {
    wmsRegisterSuccess()
}, WmsliteImpl.handleLogout = function() {
    $(window).unbind("beforeunload"), sendRequestWithCallback(contextpath + "/u/clearusercache", "nocache=" + (new Date).getTime(), !0, function() {
        WmsliteImpl.skipWMSRedirection || (window.location.href = "/")
    })
}, WmsliteImpl.handleMessage = function(mtype, msgObj) {
    mtype && "37" === mtype ? sendRequestWithCallback(contextpath + "/u/clearusercache", "nocache=" + (new Date).getTime(), !0, function() {}) : mtype && "2" == mtype && ("checkStatus" == msgObj ? isVerifiedFromDevice() : "OAInstall" == msgObj ? wmsMessageCallBack(msgObj) : "CodeGen" == msgObj ? wmsMessageCallBack(msgObj) : "mfaConfig" == msgObj && wmsMessageCallBack(msgObj))
}, WmsliteImpl.handleAccountDisabled = function() {}, WmsliteImpl.handleServiceMessage = function() {};
var splitField = {
        option: {
            splitCount: 6,
            charCountPerSplit: 1,
            separator: "",
            separateBetween: 0,
            isIpAddress: !1,
            isNumeric: !1,
            otpAutocomplete: !1,
            customClass: "",
            inputPlaceholder: "",
            placeholder: "",
            showAsPlaceholders: ""
        },
        isBackSpace: !1,
        arrowKeyCode: 0,
        createElement: function(ele, option) {
            (void 0 == option || "" == option || 0 == Object.keys(option).length) && (option = splitField.option), option.splitCount = void 0 == option.splitCount ? splitField.option.splitCount : option.splitCount, option.otpAutocomplete = void 0 == option.otpAutocomplete ? splitField.option.otpAutocomplete : option.otpAutocomplete, option.separateBetween = void 0 == option.separateBetween ? splitField.option.separateBetween : option.separateBetween, option.charCountPerSplit = void 0 == option.charCountPerSplit ? splitField.option.charCountPerSplit : option.charCountPerSplit, option.customClass = void 0 == option.customClass ? splitField.option.customClass : option.customClass, option.isIpAddress = void 0 == option.isIpAddress ? splitField.option.isIpAddress : option.isIpAddress, option.separator = void 0 == option.separator ? splitField.option.separator : option.separator, option.inputPlaceholder = void 0 == option.inputPlaceholder ? splitField.option.inputPlaceholder : option.inputPlaceholder, option.placeholder = void 0 == option.placeholder ? splitField.option.placeholder : option.placeholder, option.isIpAddress && (option.splitCount = 4, option.charCountPerSplit = 3, option.isNumeric = !0), document.getElementById(ele).innerHTML = "";
            var full_value = document.createElement("input");
            if (full_value.setAttribute("type", "hidden"), full_value.setAttribute("class", ele + "_full_value"), full_value.setAttribute("id", ele + "_full_value"), document.getElementById(ele).appendChild(full_value), option.placeholder.length > 0 && (document.getElementById(ele).setAttribute("placeholder", option.placeholder), option.isIpAddress)) {
                var backgroundColor = window.getComputedStyle(document.getElementById(ele)).backgroundColor;
                "rgba(0, 0, 0, 0)" == backgroundColor && (backgroundColor = "#FFFFFF");
                var placeholder_overlay = document.createElement("div");
                placeholder_overlay.classList.add("placeholder_overlay"), placeholder_overlay.style["background-color"] = backgroundColor, placeholder_overlay.appendChild(document.createTextNode(option.placeholder)), placeholder_overlay.addEventListener("click", function() {
                    placeholder_overlay.style.display = "none"
                }), document.getElementById(ele).addEventListener("focusout", function() {
                    option.isIpAddress && "none" == placeholder_overlay.style.display && 4 == document.querySelectorAll("#" + ele + " .empty_field").length && (placeholder_overlay.style.display = "block")
                }), document.getElementById(ele).style.position = "relative", document.getElementById(ele).appendChild(placeholder_overlay)
            }
            for (var i = 0; i < option.splitCount; i++) {
                var input = document.createElement("input");
                if (input.setAttribute("type", "tel"), input.setAttribute("tabindex", 0), option.inputPlaceholder.length > 0) {
                    var placeholder_text = document.createElement("span");
                    if (placeholder_text.innerHTML = option.inputPlaceholder, option.showAsPlaceholders)
                        for (var j = 0; j < option.charCountPerSplit; j++) input.placeholder += placeholder_text.textContent;
                    else input.placeholder = placeholder_text.textContent
                }
                if (input.classList.add("splitedText"), input.classList.add("empty_field"), input.classList.add(ele + "_otp"), input.classList.add("limit_" + option.charCountPerSplit), option.showAsPlaceholders && input.classList.add("showAsPlaceholdersInput"), "" != option.customClass && input.classList.add(option.customClass), option.isIpAddress && !option.showAsPlaceholders && input.classList.add("ip_field"), option.isNumeric && input.classList.add("isNumeric"), option.otpAutocomplete && input.setAttribute("autocomplete", "one-time-code"), option.placeholder.length > 0 && (input.style.opacity = "0"), document.getElementById(ele).appendChild(input), option.showAsPlaceholders && document.getElementById(ele).classList.add("showAsPlaceholders"), (i + 1) % option.separateBetween == 0 && i != option.splitCount - 1) {
                    var hyphen = document.createElement("span");
                    hyphen.classList.add("separator_symbol"), hyphen.classList.add(ele + "_split_symbol"), hyphen.innerHTML = option.separator, document.getElementById(ele).appendChild(hyphen)
                }
            }
            document.querySelector("#" + ele + " .splitedText").removeEventListener("focus", splitField.focus_listener, !0), document.querySelector("#" + ele + " .splitedText").addEventListener("focus", splitField.focus_listener, !0), document.querySelector("#" + ele).removeEventListener("click", function() {}, !0), document.querySelector("#" + ele).addEventListener("click", function() {
                null != document.querySelector("#" + ele + " .empty_field") ? document.querySelector("#" + ele + " .empty_field").click() : document.querySelectorAll("#" + ele + " .valid_otp")[option.splitCount - 1].click()
            });
            for (var i = 0; i < document.querySelectorAll("#" + ele + " ." + ele + "_otp").length; i++) {
                var otpEl = document.querySelectorAll("#" + ele + " ." + ele + "_otp")[i];
                otpEl.addEventListener("keydown", splitField.keyPressAnalysing), otpEl.addEventListener("keydown", splitField.backSpControl), otpEl.addEventListener("click", splitField.input_selecter), otpEl.addEventListener("click", function() {
                    splitField.focusField(this, ele, option)
                }), otpEl.addEventListener("input", splitField.OTP_count_Analysing), otpEl.addEventListener("focus", function(ele) {
                    ele.target.parentNode.classList.add("focused_input")
                }), otpEl.addEventListener("focusout", function(ele) {
                    splitField.checkFieldValue(), ele.target.parentNode.classList.remove("focused_input")
                }), otpEl.addEventListener("paste", splitField.pasteHandling), option.placeholder.length > 0 && (otpEl.addEventListener("focus", function(ele) {
                    ele.target.parentNode.classList.add("hidePlaceHolder");
                    for (var i = 0; i < ele.target.parentNode.childNodes.length; i++) ele.target.parentNode.childNodes[i].style.opacity = "1"
                }), otpEl.addEventListener("focusout", function(ele) {
                    if (0 == ele.target.parentNode.querySelector("input").value.length) {
                        ele.target.parentNode.classList.remove("hidePlaceHolder");
                        for (var i = 0; i < ele.target.parentNode.childNodes.length; i++) "INPUT" == ele.target.parentNode.childNodes[i].tagName && (ele.target.parentNode.childNodes[i].style.opacity = "0")
                    }
                }))
            }
        },
        getParent: function(el, tagName) {
            for (tagName = tagName.toLowerCase(); el && el.parentNode;)
                if (el = el.parentNode, el.tagName && el.tagName.toLowerCase() == tagName) return el;
            return null
        },
        focusField: function(curEle, ele, option) {
            return curEle.classList && curEle.classList.contains("valid_otp") ? (curEle.focus(), !1) : document.querySelectorAll("#" + ele + " .valid_otp").length >= option.splitCount && 0 != document.querySelectorAll("#" + ele + " .valid_otp").length ? (document.querySelectorAll("#" + ele + " input[type=tel]")[option.splitCount - 1].focus(), !1) : (document.querySelectorAll("#" + ele + " .empty_field")[0].focus(), void(document.querySelector("#" + ele + " .placeholder_overlay") && (document.querySelector("#" + ele + " .placeholder_overlay").style.display = "none")))
        },
        checkFieldValue: function() {
            for (var i = 0; i < document.querySelectorAll(".splitedText").length; i++) {
                var ele = document.querySelectorAll(".splitedText")[i];
                "" != ele.value ? ele.classList.add("valid_otp") : ele.classList.remove("valid_otp"), "" == ele.value ? ele.classList.add("empty_field") : ele.classList.remove("empty_field")
            }
        },
        setFullValue: function(ele) {
            var full_value_array = [];
            ele = null != ele.parentNode ? ele : ele.target;
            for (var childinputs = ele.parentNode.querySelectorAll("input"), splitCount = childinputs.length, j = 0; splitCount > j; j++)
                if (childinputs[j].classList.contains("ip_field")) {
                    if (full_value_array.push(childinputs[j].value), childinputs[j] != childinputs[childinputs.length - 1]) {
                        if ("" == childinputs[j].value) break;
                        full_value_array.push(".")
                    }
                } else void 0 != childinputs[j].value && childinputs[0] != childinputs[j] && full_value_array.push(childinputs[j].value);
            full_value_array = full_value_array.join(""), document.querySelector("#" + ele.parentNode.id + "_full_value").value = full_value_array
        },
        autoFillOtp: function(otp_data, eve) {
            var valueTarget = eve.target ? eve.target : eve;
            if (splitField.isBackSpace) return !1;
            otp_data = otp_data.split(""), splitCount = valueTarget.parentNode.querySelectorAll("input").length - 1, charCountPerSplit = parseInt(valueTarget.className.split("limit_")[1].match(/(\d+)/)[0]);
            var ele_length = otp_data.length < splitCount ? otp_data.length : splitCount;
            ele_length = charCountPerSplit > 1 ? otp_data.length : ele_length, cur_ele = valueTarget, cur_ele.value = "";
            for (var i = 0; ele_length > i && null != cur_ele; i++)
                if (charCountPerSplit > 1) {
                    if (0 != i && i % charCountPerSplit == 0) {
                        if (cur_ele.value = cur_ele.value.slice(0, charCountPerSplit), cur_ele = cur_ele.nextElementSibling, null == cur_ele) break;
                        cur_ele.value = ""
                    }
                    cur_ele.value = cur_ele.value + otp_data[i]
                } else cur_ele.value = otp_data[i], cur_ele = cur_ele.nextElementSibling, null != cur_ele && cur_ele.classList.contains("separator_symbol") && (cur_ele = cur_ele.nextElementSibling);
            null == cur_ele ? valueTarget.classList.contains("ip_field") ? valueTarget.focus() : document.querySelectorAll("#" + valueTarget.parentNode.id + " .splitedText")[splitCount - 1].focus() : cur_ele.focus(), splitField.setFullValue(valueTarget), splitField.checkFieldValue()
        },
        backSpControl: function(event) {
            if (splitField.isBackSpace) {
                if (0 != splitField.arrowKeyCode) return !1;
                var prev = this.previousElementSibling;
                if (charCountPerSplit = parseInt(this.className.split("limit_")[1].match(/(\d+)/)[0]), null == prev) return !1;
                prev.classList.contains("separator_symbol") && (prev = prev.previousElementSibling), splitField.checkFieldValue(), "" != this.value && 1 >= charCountPerSplit ? (this.value = "", this.focus(), event.preventDefault()) : charCountPerSplit > 1 ? "" == this.value && (this.previousElementSibling.classList.contains("separator_symbol") ? prev.focus() : this.focus(), event.preventDefault()) : (prev.value = "", prev.focus(), event.preventDefault()), splitField.setFullValue(this)
            }
        },
        pasteHandling: function(event, otpvalue) {
            var paste = "undefined" == typeof otpvalue ? (event.clipboardData || window.clipboardData).getData("text").split(/ /gi).join("") : otpvalue,
                allowToPaste = !0;
            if (splitField.isBackSpace = !1, this.classList.contains("ip_field")) {
                if (-1 != paste.indexOf(".")) {
                    paste = paste.split(".");
                    for (var x in paste)
                        if (paste[x].length > 3 || 0 == paste[x].length) {
                            allowToPaste = !1;
                            break
                        }
                } else allowToPaste = !1;
                if (!allowToPaste) return event && event.preventDefault(), this.focus(), !1;
                paste_ele = this;
                for (var i = 0; i < paste.length && (paste_ele.value = paste[i], paste_ele.focus(), paste_ele = paste_ele.nextElementSibling, null != paste_ele); i++) paste_ele = paste_ele.classList.contains("separator_symbol") ? paste_ele.nextElementSibling : paste_ele;
                splitField.setFullValue(this)
            } else {
                if (this.classList.contains("isNumeric") && (paste = paste.split(/[^0-9]/gi).join("")), null == paste) return event && event.target.focus(), event && event.preventDefault(), !1;
                event ? splitField.autoFillOtp(paste, event) : ""
            }
            event && event.preventDefault(), splitField.getParent(event.target, "div").querySelector(".placeholder_overlay") && (splitField.getParent(event.target, "div").querySelector(".placeholder_overlay").style.display = "none")
        },
        OTP_count_Analysing: function(event) {
            if (splitField.setFullValue(this), splitField.isBackSpace) return !1;
            charCountPerSplit = parseInt(this.className.split("limit_")[1].match(/(\d+)/)[0]);
            var valid_otp = this.classList.contains("isNumeric") ? this.value.split(/[^0-9]/gi).join("") : this.value,
                nexEl = this.nextElementSibling;
            if (null != nexEl && nexEl.classList.contains("separator_symbol") && (nexEl = nexEl.nextElementSibling), valid_otp.length < 2)
                if (nexEl && "" != valid_otp) {
                    if (this.value = valid_otp[0], splitField.checkFieldValue(), this.classList.contains("change_otp_ele")) {
                        for (var i = 0; i < this.parentNode.querySelectorAll("input").length - (1 + document.querySelectorAll("#" + this.parentElement.id + " .separator_symbol").length); i++) document.getElementsByClassName("splitedText")[i].classList.remove("change_otp_ele");
                        nexEl.classList.add("change_otp_ele")
                    }
                    this.value.length > charCountPerSplit - 1 && (nexEl.focus(), nexEl.select(), 1 >= charCountPerSplit ? nexEl.select() : "")
                } else this.value = valid_otp.slice(0, charCountPerSplit);
            else event.target.parentNode.classList.contains("showAsPlaceholders") ? this.value = valid_otp.slice(0, charCountPerSplit) : splitField.isBackSpace || splitField.autoFillOtp(valid_otp, event);
            splitField.setFullValue(this)
        },
        input_selecter: function(e) {
            if (e.stopPropagation(), splitField.isBackSpace) return !1;
            if (void 0 == this.value) return !1;
            if (e.target.parentNode.classList.contains("showAsPlaceholders")) return document.getElementsByClassName("splitedText")[0].classList.remove("change_otp_ele"), "" != this.value && this.classList.add("change_otp_ele"), !1;
            this.select();
            for (var i = 0; i < this.parentNode.querySelectorAll("input").length - 1; i++) document.getElementsByClassName("splitedText")[i].classList.remove("change_otp_ele");
            "" != this.value && this.classList.add("change_otp_ele")
        },
        keyPressAnalysing: function(event) {
            if (13 == event.keyCode && null != splitField.getParent(event.target, "for")) return splitField.isBackSpace = !1, event.stopPropagation(), event.preventDefault(), splitField.getParent(event.target, "form").requestSubmit(), !1;
            splitField.arrowKeyCode = 39 == event.keyCode || 37 == event.keyCode ? event.keyCode : 0, splitField.isBackSpace = 8 == event.keyCode || 46 == event.keyCode ? !0 : !1;
            var escapeNum = this.classList.contains("isNumeric") && !(48 <= event.keyCode && event.keyCode <= 57 || 37 == event.keyCode || 39 == event.keyCode);
            if (escapeNum) return !1;
            if (splitField.isBackSpace && 0 == splitField.arrowKeyCode) return !1;
            var sibs = splitField.getNextSiblings(this),
                nexEl = this.nextElementSibling && "INPUT" === this.nextElementSibling.nodeName ? this.nextElementSibling : sibs[0] ? sibs[0] : this.nextElementSibling;
            nexEl && null != this.value && !this.classList.contains("change_otp_ele") && (splitField.checkFieldValue(), charCountPerSplit = parseInt(this.className.split("limit_")[1].match(/(\d+)/)[0]), null != document.activeElement && (3 == this.value.length || this.classList.contains("ip_field") || this.value == document.activeElement.value && document.activeElement === this && (nexEl = this)), charCountPerSplit > 1 ? this.value.length > charCountPerSplit - 1 && 9 != event.keyCode && (nexEl.focus(), nexEl.select()) : 9 != event.keyCode && (nexEl.focus(), nexEl.select())), 37 == splitField.arrowKeyCode && this.previousElementSibling && this.previousElementSibling.classList.contains("splitedText") && !this.parentNode.classList.contains("showAsPlaceholders") ? (event.preventDefault(), this.previousElementSibling.focus(), this.previousElementSibling.select()) : 39 == splitField.arrowKeyCode && this.nextElementSibling && this.nextElementSibling.classList.contains("splitedText") && !this.parentNode.classList.contains("showAsPlaceholders") ? (event.preventDefault(), this.nextElementSibling.focus(), this.nextElementSibling.select()) : 37 != splitField.arrowKeyCode && 39 != splitField.arrowKeyCode || this.parentNode.classList.contains("showAsPlaceholders") ? this.parentNode.classList.contains("showAsPlaceholders") && (37 == splitField.arrowKeyCode ? (event.preventDefault(), this.selectionStart = this.selectionStart - 1, this.selectionEnd = this.selectionEnd - 1, this.focus()) : 39 == splitField.arrowKeyCode && (event.preventDefault(), this.selectionEnd = this.selectionEnd + 1, this.selectionStart = this.selectionStart + 1, this.focus())) : (this.focus(), this.select()), splitField.getParent(event.target, "div").querySelector(".placeholder_overlay") && (splitField.getParent(event.target, "div").querySelector(".placeholder_overlay").style.display = "none")
        },
        getNextSiblings: function(elem) {
            for (var sibs = []; elem = elem.nextElementSibling;) "INPUT" === elem.nodeName && sibs.push(elem);
            return sibs
        },
        getValue: function(ele) {
            return document.getElementById(ele + "_full_value").value
        },
        setValue: function(id, val, childIndex) {
            childIndex || (childIndex = 1);
            var ele = document.getElementById(id).children[childIndex];
            if ("" != val) {
                if (ele.classList.contains("ip_field")) {
                    if (-1 != val.indexOf(".")) {
                        val = val.split(".");
                        for (var x in val)
                            if (val[x].length > 3 || 0 == val[x].length) break
                    }
                    paste_ele = ele;
                    for (var i = 0; i < val.length && (paste_ele.value = val[i], paste_ele.focus(), paste_ele = paste_ele.nextElementSibling, null != paste_ele); i++) paste_ele = paste_ele.classList.contains("separator_symbol") ? paste_ele.nextElementSibling : paste_ele;
                    splitField.setFullValue(ele)
                } else ele.classList.contains("isNumeric") && (val = val.split(/[^0-9]/gi).join("")), splitField.autoFillOtp(val, ele);
                document.querySelectorAll("#" + id + " .placeholder_overlay")[0] && (document.querySelectorAll("#" + id + " .placeholder_overlay")[0].style.display = "none")
            } else document.querySelectorAll("#" + id + " input").forEach(function(eEle) {
                eEle.value = ""
            })
        },
        disableSplitField: function(ele) {
            $(ele).find("input").attr("disabled", "disabled"), $(ele).find("input").css({
                opacity: "0.6",
                background: "transparent"
            }), $(ele).css({
                "pointer-events": "none",
                cursor: "not-allowed"
            })
        },
        focus_listener: function(event) {
            splitField.getParent(event.target, "div").querySelector(".placeholder_overlay") && (splitField.getParent(event.target, "div").querySelector(".placeholder_overlay").style.display = "none")
        }
    },
    ppValidator, redirectionTimer = 10;